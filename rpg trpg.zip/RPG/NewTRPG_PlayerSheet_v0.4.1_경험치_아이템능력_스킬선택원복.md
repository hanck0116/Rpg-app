---
시트버전: NewTRPG_PlayerSheet_v0.4.1_item_ability_xp
이름: NewTRPG_PlayerSheet_v0.4.1_경험치_아이템능력_스킬선택원복
구분: 플레이어
시트지속성: 플레이어
시나리오: 임시 시나리오
턴: 1
레벨: 1
경험치: 0
누적경험치: 0
모험가등급: F
경험치결과: 경험치 처리 대기
최근임무경험치계산: 임무 기준 레벨 1 / 임무 등급 F / 위험도 1(안전 의뢰) → 경험치 100 / 목표 성장 약 1레벨
스탯코인: 6
코인: 0
종족: 인간
직접종족보정스탯: 힘
직업: 검사
만트라: ""
만트라설명: ""
직업패시브2배: false
만다라종류: 없음
만다라명: ""
만다라발동중: false
현재HP: 10
수동제거스탯: []
최대HP보정: 0
물리공격보정: 0
정신공격보정: 0
피해감소보정: 0
판정난이도보정: 0
용린사용중: false
최근결과: 아이템 목록 0개를 frontmatter 캐시에 저장했습니다.
스킬결과: 스킬 결과 대기
다이스표시: 대기
다이스상세: 판정 전
다이스결과타입: 대기
상대다이스내표시: 대기
상대다이스상대표시: 대기
상대다이스상세: 상대 판정 전
상대다이스결과타입: 대기
스탯코인대기스탯: ""
스탯코인대기굴림: 0
스탯코인다이스표시: 대기
스탯코인다이스상세: 스탯 코인 굴림 전
스탯코인다이스결과타입: 대기
보유스킬: []
상태이상: []
지속효과: []
효과로그: []
장비목록: []
아이템목록: []
축복사용턴: 0
성장기록: []
로그: []
메모: ""
시나리오목록캐시: []
시나리오목록캐시갱신일시: ""
NPC목록캐시: []
NPC목록캐시시나리오: ""
NPC목록캐시갱신일시: ""
아이템목록캐시: []
아이템목록캐시시나리오: 임시 시나리오
아이템목록캐시갱신일시: 2026. 6. 25. 12시 33분 49초
힘: 1
힘아이템: 0
힘스킬: 0
힘임시: 0
민첩: 1
민첩아이템: 0
민첩스킬: 0
민첩임시: 0
체력: 1
체력아이템: 0
체력스킬: 0
체력임시: 0
지능: 1
지능아이템: 0
지능스킬: 0
지능임시: 0
지혜: 1
지혜아이템: 0
지혜스킬: 0
지혜임시: 0
외모: 1
외모아이템: 0
외모스킬: 0
외모임시: 0
축복스택: 0
---

```js-engine
// NewTRPG v0.4.0 JS Engine 통합형 초저렉 편의판 · 경험치/모험가등급/아이템능력 적용
// 기존 DataviewJS 카드형 UI를 JS Engine 렌더러에서 실행하도록 호환 레이어를 둡니다.
// 무거운 전체 노트 검색은 NPC/아이템/시나리오 "목록 불러오기" 버튼을 누를 때만 실행됩니다.
container.empty();

const __activeFile = app.workspace.getActiveFile();
if (!__activeFile) {
  container.createEl("div", { text: "현재 활성 노트를 찾지 못했습니다." });
  return;
}
function __frontmatterOf(fileObj) {
  return app.metadataCache.getFileCache(fileObj)?.frontmatter ?? {};
}
function __pageOf(fileObj) {
  const fm = __frontmatterOf(fileObj);
  return { ...fm, file: { path: fileObj.path, name: fileObj.basename } };
}
function __wrapPages(list) {
  return {
    array: () => list,
    first: () => list[0],
    where: (fn) => __wrapPages(list.filter(fn)),
    sort: (fn, order = "asc") => {
      const next = [...list].sort((a, b) => {
        const av = typeof fn === "function" ? fn(a) : a?.[fn];
        const bv = typeof fn === "function" ? fn(b) : b?.[fn];
        return String(av ?? "").localeCompare(String(bv ?? ""), "ko");
      });
      if (String(order).toLowerCase() === "desc") next.reverse();
      return __wrapPages(next);
    },
  };
}
const dv = {
  current: () => __pageOf(__activeFile),
  el: (tag, text = "", opts = {}) => {
    const el = container.createEl(tag, { cls: opts?.cls ?? "" });
    if (text !== undefined && text !== null && String(text).length) el.textContent = String(text);
    return el;
  },
  pages: () => __wrapPages(app.vault.getMarkdownFiles().map(__pageOf)),
};

const file = app.vault.getAbstractFileByPath(dv.current().file.path);
const cur = dv.current();
const root = dv.el("div", "", { cls: "nrpg-root" });


// v0.3.1 JS Engine 통합형 초저렉 편의판
// 핵심: NPC/아이템/시나리오처럼 다른 노트 전체 검색이 필요한 목록은
// 화면을 열 때 자동 검색하지 않고, "목록 불러오기" 버튼을 눌렀을 때만 검색합니다.
// 검색 결과는 현재 시트의 frontmatter 캐시 필드에 저장하고, 이후 렌더에서는 캐시만 사용합니다.
// 로그/효과로그는 더 이상 frontmatter에 누적 저장하지 않습니다.
const NRPG_DICE_ANIMATION = false;
const NRPG_LAZY_VERSION = "v0.4.0_item_ability_xp";
let __nrpgCache = {};
function resetNrpgCalcCache() { __nrpgCache = {}; }
function cacheKey(value) {
  try { return JSON.stringify(value ?? null); } catch { return String(value ?? ""); }
}
function sortByName(a, b) {
  return String(a?.file?.name ?? a?.name ?? "").localeCompare(String(b?.file?.name ?? b?.name ?? ""), "ko");
}
function cacheFieldByKind(kind) {
  if (kind === "scenario") return "시나리오목록캐시";
  if (kind === "npc") return "NPC목록캐시";
  if (kind === "item") return "아이템목록캐시";
  return `${kind}목록캐시`;
}
function cacheScenarioFieldByKind(kind) {
  if (kind === "npc") return "NPC목록캐시시나리오";
  if (kind === "item") return "아이템목록캐시시나리오";
  return `${kind}목록캐시시나리오`;
}
function readStoredList(kind, scenario = state?.시나리오) {
  try {
    const field = cacheFieldByKind(kind);
    const list = arr(state?.[field]);
    if (!Array.isArray(list)) return [];
    if ((kind === "npc" || kind === "item") && String(state?.[cacheScenarioFieldByKind(kind)] ?? "") && String(state?.[cacheScenarioFieldByKind(kind)] ?? "") !== String(scenario ?? state?.시나리오 ?? "")) return [];
    return list;
  } catch (e) { return []; }
}
function writeStoredList(kind, records, scenario = state?.시나리오) {
  const field = cacheFieldByKind(kind);
  state[field] = arr(records);
  if (kind === "npc" || kind === "item") state[cacheScenarioFieldByKind(kind)] = String(scenario ?? state?.시나리오 ?? "");
  state[`${field}갱신일시`] = nowText();
}
function clearStoredList(kind, scenario = state?.시나리오) {
  const field = cacheFieldByKind(kind);
  state[field] = [];
  if (kind === "npc" || kind === "item") state[cacheScenarioFieldByKind(kind)] = String(scenario ?? state?.시나리오 ?? "");
  state[`${field}갱신일시`] = nowText();
}
function pageRecord(p) {
  const path = String(p?.file?.path ?? "");
  const name = String(p?.이름 ?? p?.file?.name ?? path.split("/").pop()?.replace(/\.md$/, "") ?? "");
  return { path, name, fileName: String(p?.file?.name ?? name), scenario: String(p?.시나리오 ?? "") };
}
function recordToPage(r) {
  if (!r?.path) return null;
  const fileObj = app.vault.getAbstractFileByPath(r.path);
  const fm = fileObj ? (app.metadataCache.getFileCache(fileObj)?.frontmatter ?? {}) : {};
  const fileName = fileObj?.basename ?? r.fileName ?? r.name ?? String(r.path).split("/").pop()?.replace(/\.md$/, "");
  return { ...r, ...fm, file: { path: r.path, name: fileName } };
}
function allPagesSearchNow() {
  try { return dv.pages().array(); }
  catch (e) { console.warn("NRPG dv.pages search failed", e); return []; }
}
function lazyStatus(kind, label) {
  const count = readStoredList(kind).length;
  const field = cacheFieldByKind(kind);
  const updated = state?.[`${field}갱신일시`] ? ` / ${state[`${field}갱신일시`]}` : "";
  return count ? `${label} ${count}개 불러옴${updated}` : `${label} 목록 미불러옴`;
}
function lazyOptionMessage(text) {
  return `<option value="">${esc(text)}</option>`;
}

const STAT_KEYS = ["힘", "민첩", "체력", "지능", "지혜", "외모"];
const CORE_STAT_KEYS = ["힘", "민첩", "체력", "지능", "지혜"];
const SKILL_TYPES = ["고유", "종족", "직업", "만다라", "기타"];
const MANDALA_TYPES = ["없음", "진화", "영역", "변신"];
const DIRECT_RACES = ["수인", "어인", "곤충 인간"];
const SHEET_ATTRS = ["플레이어", "NPC", "적", "기타"];
const EFFECT_KINDS = ["공격", "회복", "버프", "디버프", "특수", "패시브"];

const DIFFICULTIES = [
  { name: "쉬움", value: 20 },
  { name: "쉬움+", value: 30 },
  { name: "일상적", value: 40 },
  { name: "보통-", value: 50 },
  { name: "보통", value: 60 },
  { name: "보통+", value: 70 },
  { name: "어려움-", value: 80 },
  { name: "어려움", value: 90 },
  { name: "매우 어려움", value: 100 },
  { name: "영웅적-", value: 110 },
  { name: "영웅적", value: 120 },
  { name: "영웅적+", value: 130 },
  { name: "초월적-", value: 140 },
  { name: "초월적", value: 150 },
  { name: "초월적+", value: 160 },
  { name: "전설적-", value: 170 },
  { name: "전설적", value: 180 },
  { name: "신화적-", value: 190 },
  { name: "신화적인", value: 200 }
];


const ADVENTURER_GRADES = [
  { 등급: "F", 최소레벨: 1, 최대레벨: 9, 설명: "마을 잡무와 기초 의뢰" },
  { 등급: "E", 최소레벨: 10, 최대레벨: 19, 설명: "초급 전투와 소규모 탐색" },
  { 등급: "D", 최소레벨: 20, 최대레벨: 29, 설명: "위험 지역 정찰과 하급 던전" },
  { 등급: "C", 최소레벨: 30, 최대레벨: 39, 설명: "지역 위협 해결" },
  { 등급: "B", 최소레벨: 40, 최대레벨: 49, 설명: "도시급 사건과 강적 토벌" },
  { 등급: "A", 최소레벨: 50, 최대레벨: 59, 설명: "국가 단위 중요 의뢰" },
  { 등급: "S", 최소레벨: 60, 최대레벨: 69, 설명: "재난급 위협 대응" },
  { 등급: "SS", 최소레벨: 70, 최대레벨: 79, 설명: "대륙급 사건" },
  { 등급: "SSS", 최소레벨: 80, 최대레벨: 89, 설명: "역사에 남을 영웅 의뢰" },
  { 등급: "EX", 최소레벨: 90, 최대레벨: 99, 설명: "세계 법칙을 흔드는 의뢰" },
];
const MISSION_RISKS = [
  { 위험도: 1, 이름: "안전 의뢰", 목표상승: 1, 설명: "기준 레벨에서 약 1레벨 상승" },
  { 위험도: 2, 이름: "낮은 위험", 목표상승: 2, 설명: "기준 레벨에서 약 2레벨 상승" },
  { 위험도: 3, 이름: "보통 위험", 목표상승: 3, 설명: "기준 레벨에서 약 3레벨 상승" },
  { 위험도: 4, 이름: "높은 위험", 목표상승: 4, 설명: "기준 레벨에서 약 4레벨 상승" },
  { 위험도: 5, 이름: "극위험 의뢰", 목표상승: 5, 설명: "기준 레벨에서 약 5레벨 상승" },
];
const ITEM_ABILITY_TYPES = ["차징공격", "이동공격", "소유자동효과", "방어반응", "회복", "소환", "제작", "탐색", "봉인해제", "상태이상", "세계반응", "기타"];

const EQUIPMENT_GRADES = [
  { 등급: "일반", 기준가격: "3골드", 설명: "아무 효과 없는 기본 무기·방어구" },
  { 등급: "레어", 기준가격: "GM 산정", 설명: "작은 보정이나 제한적 특수 기능을 가진 장비" },
  { 등급: "유니크", 기준가격: "GM 산정", 설명: "고유 효과나 캐릭터 운용을 바꾸는 장비" },
  { 등급: "전설", 기준가격: "GM 산정", 설명: "시나리오급 영향을 주는 강력한 장비" },
  { 등급: "신화", 기준가격: "GM 산정", 설명: "세계관급 가치와 특수성을 가진 장비" },
];

function statMap(entries = {}) {
  const out = Object.fromEntries(STAT_KEYS.map(s => [s, 0]));
  for (const [k, v] of Object.entries(entries)) out[k] = v;
  return out;
}
function skill(name, effect, type = "종족", level = "") {
  return { 이름: name, 종류: type, 레벨: level, 효과: effect };
}

const RACES = {
  "인간": {
    stats: statMap(),
    desc: "모든 판정 난이도 -20. 종족스킬 없음. 70레벨에 스킬 비율과 관계없이 강제로 진화 만다라.",
    difficultyBonus: -20,
    forceMandala: "진화",
    noRaceSkill: true,
    skills: [],
    evolution: "만류귀종",
  },
  "엘프": {
    stats: statMap({ 외모: 5 }),
    desc: "외모 +5. 정령 마법에 특화.",
    skills: [
      skill("하급 정령 마법", "위력 = 정신 공격력"),
      skill("중급 정령 마법", "위력 = 정신 공격력 × 3"),
      skill("상급 정령 마법", "위력 = 정신 공격력 × 7"),
      skill("정령 교감", "지혜 판정. 자연이나 정령과 대화하고 정보를 얻는다."),
    ],
    evolution: "하이엘프",
  },
  "드워프": {
    stats: statMap({ 힘: 10 }),
    desc: "힘 +10. 직업이 대장장이라면 모든 종족스킬 판정 확정 성공.",
    skills: [
      skill("제작", "힘 판정. 제작이 어려울수록 난이도 상승."),
      skill("재료 탐색", "지능 판정 1d(10+레벨). 제작 재료를 찾는다."),
      skill("룬어", "지혜 판정 1d(지혜+20). 제작품에 룬어를 부여해 강화."),
      skill("장인의 감정", "지능 판정. 무기, 방어구, 광물, 유물의 구조와 가치를 파악."),
    ],
    evolution: "듀에르가",
  },
  "몽마": {
    stats: statMap({ 외모: 15 }),
    desc: "외모 +15. 매혹과 정신 간섭에 특화.",
    skills: [
      skill("매혹", "외모 상대판정."),
      skill("변신", "상대의 이상형으로 변한다. 매혹 판정 +5."),
      skill("드레인", "체력 상대판정. 상대의 체력을 강탈한다."),
      skill("꿈 침식", "외모 상대판정. 성공 시 대상은 다음 판정 -10."),
    ],
    evolution: "몽마의 여제 아마릴리스",
  },
  "수인": {
    stats: statMap(),
    directStat: true,
    desc: "선택한 수인 종류에 따른 스탯 +10. 숲에서 민첩 +4. 종족스킬은 플레이어가 직접 제작.",
    skills: [],
    evolution: "완전 야수화",
  },
  "어인": {
    stats: statMap(),
    directStat: true,
    desc: "선택한 어인 종류에 따른 스탯 +10. 종족스킬은 플레이어가 직접 제작.",
    skills: [],
    evolution: "완전 야수화",
  },
  "천사": {
    stats: statMap({ 외모: -20 }),
    desc: "외모 -20. 축복, 비행, 광명구 사용.",
    skills: [
      skill("신의 축복", "축복 스택을 쌓는다. 스택당 모든 스탯 +1. 피해를 받으면 초기화."),
      skill("비행", "힘 판정 1d(힘+20)."),
      skill("광명구", "헤일로로 무기를 만들거나 강화한다."),
      skill("심판의 빛", "위력 = 정신 공격력 × 2. 악마, 언데드, 저주 대상에게 위력 2배."),
    ],
    evolution: "대천사",
  },
  "악마": {
    stats: statMap({ 외모: 5 }),
    desc: "외모 +5. 마기, 저주, 계약에 특화.",
    skills: [
      skill("마기 부여", "무기에 마기를 부여한다. 1턴 유지. 신성 관련 대상에게 강하고 피해 2배."),
      skill("저주", "지혜 상대판정. 성공 시 상대 랜덤 스탯 3턴 동안 -10."),
      skill("비행", "힘 판정 1d(힘+20)."),
      skill("악마의 계약", "지혜 상대판정. 대상에게 실제 제공 가능한 보상을 주고 계약 조건을 설정한다."),
    ],
    evolution: "대악마",
  },
  "곤충 인간": {
    stats: statMap(),
    directStat: true,
    desc: "선택한 곤충에 따른 스탯 +10. 종족스킬은 플레이어가 직접 제작.",
    skills: [],
    evolution: "완전 곤충화",
  },
  "뱀파이어": {
    stats: statMap({ 힘: 2, 민첩: 2, 체력: 2, 지능: 2, 지혜: 2, 외모: 2 }),
    desc: "올스탯 +2. 입힌 피해량만큼 체력 회복. 블러드 인챈트 사용 가능.",
    skills: [
      skill("흡혈", "입힌 피해만큼 체력을 회복한다."),
      skill("박쥐화", "박쥐로 변신한다."),
      skill("혈액 응결", "체력을 소모해 피로 무언가를 만든다. 지능 판정."),
      skill("피의 안개", "체력 1d6 소모. 1턴 동안 자신 대상 공격 판정 -10."),
    ],
    evolution: "진조",
  },
  "슬라임": {
    stats: statMap(),
    remove: ["외모"],
    slimeTransfer: true,
    desc: "외모 스탯 제거. 기본 외모 수치가 민첩에 더해진다. 물리 피해 1/4배, 마법 피해 4배.",
    physicalTakenMul: 0.25,
    magicTakenMul: 4,
    skills: [
      skill("분열", "최대 4개로 분열한다. 체력도 나뉜다."),
      skill("포식", "무언가를 삼켜 분해한다. 물질에 따라 체력 회복."),
      skill("점액 분배", "점액을 분비해 닿은 상대를 접착시킨다."),
      skill("형태 변형", "민첩 판정. 좁은 틈 통과, 의태, 임시 도구 형태 변형."),
    ],
    evolution: "킹 슬라임",
  },
  "용인족": {
    stats: statMap({ 힘: 15, 민첩: 15, 체력: 15, 지능: 15, 지혜: 15, 외모: 15 }),
    desc: "모든 스탯 +15. 첫 스킬은 반드시 강제 용족화. 강력하지만 대가가 큰 종족.",
    forcedSkill: skill("강제 용족화", "1턴 동안 모든 스탯 +1d30. 이후 영구적으로 모든 스탯 -3d5.", "종족", "시작"),
    skills: [
      skill("강제 용족화", "1턴 동안 모든 스탯 +1d30. 이후 영구적으로 모든 스탯 -3d5."),
      skill("브레스", "마법 공격력 위력을 가진 브레스를 내뿜는다. 세부 판정과 범위는 GM이 정한다."),
      skill("비행", "힘 판정 1d(힘+20)."),
      skill("용린", "사용 중 받는 물리/마법 피해를 절반으로 줄인다. 사용 중 민첩 유효값이 절반."),
    ],
    evolution: "완전 용족화",
  },
  "요정족": {
    stats: statMap({ 체력: -10, 외모: 20 }),
    desc: "체력 -10, 외모 +20. 비행, 축복, 저주에 특화.",
    skills: [
      skill("요정의 축복", "대상의 다음 판정에 +1d6을 적용한다."),
      skill("비행", "힘 판정 1d(힘+20)."),
      skill("요정의 가루", "상대에게 일시적 비행을 부여한다."),
      skill("요정의 저주", "대상의 다음 판정에 -1d6을 적용한다."),
    ],
    evolution: "요정왕",
  },
  "사이보그": {
    stats: statMap(),
    remove: ["외모"],
    cyborgSplit: true,
    desc: "외모 스탯 제거. 기본 외모 수치를 5개 핵심 스탯에 균등 분배. 스캔과 개조에 특화.",
    skills: [
      skill("오버클럭", "힘, 민첩을 일시적으로 최대치로 올린다."),
      skill("개조", "신체를 변형한다. 지능 판정 1d(지능+20)."),
      skill("복구", "물건을 섭취해 재료로 삼아 체력을 회복한다."),
      skill("데이터 스캔", "대상의 구조, 약점, 행동 패턴, 상태를 스캔한다. 추가 판정 보정 없음."),
    ],
    evolution: "사이버트론",
  },
  "고블린": {
    stats: statMap({ 체력: -15, 외모: -10, 민첩: 15 }),
    desc: "체력 -15, 외모 -10, 민첩 +15. 고유 화폐 골드와 상점 사용.",
    skills: [
      skill("판매", "물건을 판매해 골드를 얻는다."),
      skill("스틸", "민첩 상대판정. 상대의 물건을 훔친다."),
      skill("구매", "고블린 상점을 연다. 본 것의 1회용 모조품을 골드로 구매."),
      skill("흥정", "지능 또는 외모 상대판정. 가격 변화량은 1d6 코인 고정."),
    ],
    evolution: "홉 고블린",
  },
  "오크": {
    stats: statMap({ 체력: 15, 힘: 15, 민첩: -10, 지능: -10 }),
    desc: "체력 +15, 힘 +15, 민첩 -10, 지능 -10. 육체의 대화 사용.",
    skills: [
      skill("육체의 대화", "대화를 중단하고 전투. 체력 1 남으면 패배, 승자의 말에 한 번 복종."),
      skill("오크의 재생력", "체력을 5% 회복한다."),
      skill("오크의 육체", "일시적으로 힘 +20. 체력이 풀피가 되면 재사용 가능."),
      skill("전장의 포효", "체력 상대판정. 적 공격 판정 -10, 아군 물리 공격력 +5."),
    ],
    evolution: "오크 로드",
  },
  "구미호": {
    stats: statMap({ 힘: -35, 민첩: -35, 체력: -35, 외모: 50, 지능: 10, 지혜: 10 }),
    desc: "힘/민첩/체력 -35, 외모 +50, 지능 +10, 지혜 +10. 기적과 둔갑에 특화.",
    skills: [
      skill("여우구슬", "스토리당 3번 기적을 발생시킨다. 예: 성공을 실패로 바꿈."),
      skill("둔갑", "다른 모습으로 둔갑한다. 지능 판정 1d(지능+20)."),
      skill("여우불", "푸른 불을 발생시키고 원하는 대로 조종한다. 지능 판정 1d(지능+20)."),
      skill("미혹의 눈빛", "외모 상대판정. 대상은 1턴 동안 공격, 이동, 스킬 사용 중 하나를 선택하지 못한다."),
    ],
    evolution: "천호",
  },
  "식물족": {
    stats: statMap({ 민첩: -35, 체력: 25, 힘: 20 }),
    desc: "민첩 -35, 체력 +25, 힘 +20. 뿌리, 생장, 치료 계열. 뿌리내리기에는 체력 회복 없음.",
    skills: [
      skill("생장", "체력 판정. 자신의 신체를 성장시킨다."),
      skill("씨뿌리기", "HP 10의 분체를 만들어 심는다."),
      skill("치료", "물을 흡수해 자신을 치료한다. HP 5d2% 회복."),
      skill("뿌리 내리기", "체력 판정. 밀려나거나 넘어지지 않는다. 이동하면 해제. 체력 회복 없음."),
    ],
    evolution: "워그드라실",
  },
};

const EVOLUTIONS = {
  "인간": {
    name: "만류귀종",
    desc: "모든 기본 스탯이 자신의 기본 스탯 중 최고치로 동일화된다. 기존 인간 패시브도 유지된다.",
    equalizeBase: true,
    stats: statMap(),
    skills70: [skill("만류귀종", "모든 기본 스탯을 최고 기본 스탯으로 동일화한다. 아이템·종족·직업·임시 보정은 기준에서 제외.", "만다라", 70)],
    skills80: [],
    skills90: [],
  },
  "엘프": {
    name: "하이엘프",
    desc: "지능 +5, 지혜 +5, 외모 +5. 기존 엘프 패시브 유지.",
    stats: statMap({ 지능: 5, 지혜: 5, 외모: 5 }),
    skills70: [skill("하이엘프 진화", "하이엘프로 진화한다. 지능·지혜·외모 +5.", "만다라", 70)],
    skills80: [skill("정령왕 마법", "위력 = 마법 공격력(정신 공격력) × 20.", "만다라", 80)],
    skills90: [skill("자연의 도움", "외모 판정 1d(외모+20). 자연의 도움을 받을 수 있다.", "만다라", 90)],
  },
  "드워프": {
    name: "듀에르가",
    desc: "지능 +15, 지혜 +15. 기존 드워프 패시브 유지.",
    stats: statMap({ 지능: 15, 지혜: 15 }),
    skills70: [skill("듀에르가 진화", "듀에르가로 진화한다. 지능·지혜 +15.", "만다라", 70)],
    skills80: [skill("마도구 제작", "지혜 판정 1d(지혜+20). 룬어와 마법을 사용해 마도구를 제작한다.", "만다라", 80)],
    skills90: [],
  },
  "몽마": {
    name: "몽마의 여제 아마릴리스",
    desc: "외모 +20. 기존 몽마 패시브 유지.",
    stats: statMap({ 외모: 20 }),
    skills70: [skill("몽마의 여제", "몽마의 여제 아마릴리스로 진화한다. 외모 +20.", "만다라", 70)],
    skills80: [skill("환상향", "외모 상대판정. 주변 모든 인물을 매혹한다. 무성애자에게도 적용 가능.", "만다라", 80)],
    skills90: [],
  },
  "수인": {
    name: "완전 야수화",
    desc: "올스탯 +5. 기존 수인 패시브 유지. 80/90레벨 스킬은 선택 수인에 맞춰 GM과 제작.",
    stats: statMap({ 힘: 5, 민첩: 5, 체력: 5, 지능: 5, 지혜: 5, 외모: 5 }),
    skills70: [skill("완전 야수화", "완전 야수화한다. 올스탯 +5.", "만다라", 70)],
    skills80: [skill("야수화 80레벨 스킬", "선택한 수인에 맞춰 GM과 제작한다.", "만다라", 80)],
    skills90: [skill("야수화 90레벨 스킬", "선택한 수인에 맞춰 GM과 제작한다.", "만다라", 90)],
  },
  "어인": {
    name: "완전 어류화",
    desc: "선택한 어인 특성에 맞춰 진화한다. 기존 어인 패시브 유지.",
    stats: statMap(),
    skills70: [skill("완전 어류화", "선택한 어인에 맞춰 완전 진화한다.", "만다라", 70)],
    skills80: [skill("어류화 80레벨 스킬", "선택한 어인에 맞춰 GM과 제작한다.", "만다라", 80)],
    skills90: [skill("어류화 90레벨 스킬", "선택한 어인에 맞춰 GM과 제작한다.", "만다라", 90)],
  },
  "천사": {
    name: "대천사",
    desc: "외모 -100. 기존 천사 패시브와 축복 스택 유지.",
    stats: statMap({ 외모: -100 }),
    skills70: [skill("대천사 진화", "대천사로 진화한다. 외모 -100.", "만다라", 70)],
    skills80: [skill("두려워하라", "외모 상대판정. 실패한 상대는 공포로 행동이 저지된다.", "만다라", 80)],
    skills90: [],
  },
  "악마": {
    name: "대악마",
    desc: "올스탯 +5. 기존 악마 패시브 유지. 대악마 스킬은 플레이어가 제작.",
    stats: statMap({ 힘: 5, 민첩: 5, 체력: 5, 지능: 5, 지혜: 5, 외모: 5 }),
    skills70: [skill("대악마 진화", "대악마로 진화한다. 올스탯 +5.", "만다라", 70)],
    skills80: [skill("대악마 80레벨 스킬", "대악마에 맞게 플레이어가 제작한다.", "만다라", 80)],
    skills90: [skill("대악마 90레벨 스킬", "대악마에 맞게 플레이어가 제작한다.", "만다라", 90)],
  },
  "곤충 인간": {
    name: "완전 곤충화",
    desc: "선택한 곤충에 따른 스탯 +10. 기존 곤충 인간 패시브 유지.",
    stats: statMap(),
    directStat: true,
    skills70: [skill("완전 곤충화", "완전 곤충화한다. 선택한 곤충 보정 스탯 +10.", "만다라", 70)],
    skills80: [skill("곤충화 80레벨 스킬", "선택한 곤충에 맞춰 GM과 제작한다.", "만다라", 80)],
    skills90: [skill("곤충화 90레벨 스킬", "선택한 곤충에 맞춰 GM과 제작한다.", "만다라", 90)],
  },
  "뱀파이어": {
    name: "진조",
    desc: "턴이 돌아오면 최대 HP의 10% 회복. 기존 뱀파이어 패시브 유지.",
    stats: statMap(),
    turnHealPercent: 10,
    skills70: [skill("진조 진화", "진조로 진화한다. 턴 시작 시 최대 HP의 10% 회복.", "만다라", 70)],
    skills80: [skill("혈귀화", "NPC를 물어 혈귀를 제작한다. 지혜 상대판정.", "만다라", 80)],
    skills90: [],
  },
  "슬라임": {
    name: "킹 슬라임",
    desc: "체력 스탯 2배, 분열 최대치 25. 기존 슬라임 패시브 유지.",
    stats: statMap(),
    doubleBaseCon: true,
    skills70: [skill("킹 슬라임 진화", "킹 슬라임으로 진화한다. 체력 스탯 2배, 분열 최대치 25.", "만다라", 70)],
    skills80: [skill("분해", "포식으로 얻은 체력이 최대체력 이상으로 늘어날 수 있다.", "만다라", 80)],
    skills90: [],
  },
  "용인족": {
    name: "완전 용족화",
    desc: "특수진화. 올스탯 +40. 기존 용인족 패시브 유지.",
    stats: statMap({ 힘: 40, 민첩: 40, 체력: 40, 지능: 40, 지혜: 40, 외모: 40 }),
    specialOnly: true,
    skills70: [skill("완전 용족화", "강제 용족화의 대가 끝에 완전 용족화한다. 올스탯 +40.", "만다라", 70)],
    skills80: [skill("드래곤 피어", "지능 상대판정. 공포로 상대 행동을 저지한다.", "만다라", 80)],
    skills90: [skill("성장", "사용 시 영구히 올스탯 +1d8.", "만다라", 90)],
  },
  "요정족": {
    name: "요정왕",
    desc: "상시 비행. 기존 요정족 패시브 유지.",
    stats: statMap(),
    constantFlight: true,
    skills70: [skill("요정왕 진화", "요정왕으로 진화한다. 상시 비행.", "만다라", 70)],
    skills80: [skill("요정 호출", "요정 5명을 소환해 요정의 축복을 사용한다.", "만다라", 80)],
    skills90: [skill("요정의 키스", "5명의 요정에게 키스를 받아 원하는 5개 스탯에 각기 +1d6.", "만다라", 90)],
  },
  "사이보그": {
    name: "사이버트론",
    desc: "고통과 상태이상 무효. 기존 사이보그 패시브 유지.",
    stats: statMap(),
    immuneStatus: true,
    skills70: [skill("사이버트론 진화", "사이버트론으로 진화한다. 고통과 상태이상 무효.", "만다라", 70)],
    skills80: [skill("회로 부여", "물건에 회로를 부여해 자신의 몸에 붙이고 강화한다.", "만다라", 80)],
    skills90: [skill("모조 사이버트론 분열", "재료를 사용해 1턴 동안 행동 가능한 모조 사이버트론을 생성한다.", "만다라", 90)],
  },
  "고블린": {
    name: "홉 고블린",
    desc: "체력 +20, 외모 -5, 민첩 +5, 지능 +5. 기존 고블린 패시브 유지.",
    stats: statMap({ 체력: 20, 외모: -5, 민첩: 5, 지능: 5 }),
    skills70: [skill("홉 고블린 진화", "홉 고블린으로 진화한다.", "만다라", 70)],
    skills80: [skill("공격 마법", "지능 판정. 성공 시 마법 발동, 실패 시 뒤틀린 마법 발동.", "만다라", 80)],
    skills90: [skill("저주마법", "지능 판정. 성공 시 저주마법 발동, 실패 시 뒤틀린 마법 발동.", "만다라", 90)],
  },
  "오크": {
    name: "오크 로드",
    desc: "힘 +5, 체력 +5, 지능 +5. 기존 오크 패시브 유지.",
    stats: statMap({ 힘: 5, 체력: 5, 지능: 5 }),
    skills70: [skill("오크 로드 진화", "오크 로드로 진화한다.", "만다라", 70)],
    skills80: [skill("포식", "포식한 것에 따라 다른 영구 스탯을 획득한다.", "만다라", 80)],
    skills90: [skill("귀속", "육체의 대화로 복종시킨 대상을 휘하의 기사로 귀속한다. 지능 상대판정.", "만다라", 90)],
  },
  "구미호": {
    name: "천호",
    desc: "지능 +20, 지혜 +20. 기존 구미호 패시브 유지.",
    stats: statMap({ 지능: 20, 지혜: 20 }),
    skills70: [skill("천호 진화", "천호로 진화한다. 지능·지혜 +20.", "만다라", 70)],
    skills80: [skill("정기흡수", "대상마다 1번. 지혜 판정 1d(지혜+20). 성공 시 자신의 지능 +3, 대상 지능 -3.", "만다라", 80)],
    skills90: [],
  },
  "식물족": {
    name: "워그드라실",
    desc: "지능 +15, 지혜 +15. 기존 식물족 패시브 유지.",
    stats: statMap({ 지능: 15, 지혜: 15 }),
    skills70: [skill("워그드라실 진화", "워그드라실로 진화한다. 지능·지혜 +15.", "만다라", 70)],
    skills80: [skill("자연 조종", "주변의 자연을 조종한다.", "만다라", 80)],
    skills90: [skill("세계수의 사과", "사과를 맺는다. 섭취 시 체력 20% 회복. 풀피일 때만 사용 가능.", "만다라", 90)],
  },
};

const JOBS = {
  "검사": {
    stats: statMap(),
    physicalBonus: 10,
    desc: "물리 공격력 +10.",
    skills: [
      skill("일도양단", "물리 공격력 2배의 베기", "직업"),
      skill("연속베기", "민첩/10번 연속으로 벤다", "직업"),
      skill("흘려내기", "민첩 상대판정", "직업"),
      skill("검기", "검에 기운을 실어 원거리까지 베어낸다. 위력 = 물리 공격력", "직업"),
    ],
  },
  "탱커": {
    stats: statMap(),
    tankReduction: true,
    desc: "물리 공격력만큼 피해 감소.",
    skills: [
      skill("도발", "상대의 공격 대상을 바꾼다", "직업"),
      skill("보호", "자신의 뒤에 있는 존재를 보호한다", "직업"),
      skill("튕기기", "방패로 무언가를 튕겨낸다", "직업"),
      skill("철벽 자세", "이동 불가 대신 받는 피해 절반. 보호 대상 피해도 대신 받을 수 있음", "직업"),
    ],
  },
  "궁수/총술사": {
    stats: statMap({ 힘: 2, 민첩: 2 }),
    desc: "무한한 화살/총알. 민첩 +2, 힘 +2.",
    skills: [
      skill("조준", "공격 관찰 판정 +10", "직업"),
      skill("연사", "동시에 여러 화살/총알 발사", "직업"),
      skill("도탄", "총알이 튕긴다", "직업"),
      skill("약점 사격", "관찰 또는 민첩 판정. 성공 시 이번 공격 피해 2배", "직업"),
    ],
  },
  "마법사": {
    stats: statMap({ 지능: 5, 지혜: 5 }),
    desc: "지능 +5, 지혜 +5.",
    skills: [
      skill("공격 마법", "지능 판정. 성공 시 마법 발동, 실패 시 뒤틀린 마법 발동", "직업"),
      skill("방어 마법", "지능 판정. 성공 시 마법 발동, 실패 시 뒤틀린 마법 발동", "직업"),
      skill("보조 마법", "지능 판정. 성공 시 마법 발동, 실패 시 뒤틀린 마법 발동", "직업"),
      skill("마력 증폭", "다음 마법 위력 2배. 대신 마법 판정 난이도 +20", "직업"),
    ],
  },
  "암살자": {
    stats: statMap({ 민첩: 10 }),
    desc: "민첩 +10.",
    skills: [
      skill("은신", "민첩 판정 1d(민첩+20)", "직업"),
      skill("암살", "민첩 판정 1d(민첩+20). 성공 시 피해 2배", "직업"),
      skill("덫 설치", "민첩 판정 1d(민첩+20)", "직업"),
      skill("그림자 이동", "민첩 판정. 그림자나 사각지대를 이용해 짧은 거리 이동", "직업"),
    ],
  },
  "음악가": {
    stats: statMap({ 힘: 1, 민첩: 1, 체력: 1, 지능: 1, 지혜: 1, 외모: 1 }),
    desc: "올스탯 +1.",
    skills: [
      skill("화음", "아군 공격력 일시적 2배", "직업"),
      skill("불협화음", "적 공격력 일시적 1/2배", "직업"),
      skill("회복의 노래", "아군 체력 10% 회복", "직업"),
      skill("전장의 행진곡", "아군 전체의 다음 행동 판정 +10. 전투 중 1회", "직업"),
    ],
  },
  "대장장이": {
    stats: statMap({ 힘: 10 }),
    desc: "힘 +10.",
    skills: [
      skill("제작", "힘 판정. 제작이 어려울수록 난이도 상승", "직업"),
      skill("설계", "제작 판정에 1d지혜 보정", "직업"),
      skill("강화", "제작품 강화. 데미지 2배, 힘 판정 1d(힘+20)", "직업"),
      skill("즉석 수리", "전투 중 손상 장비를 임시 수리. 힘 또는 지능 판정", "직업"),
    ],
  },
  "랜서": {
    stats: statMap({ 힘: 3, 민첩: 3, 지혜: 3 }),
    desc: "힘 +3, 민첩 +3, 지혜 +3.",
    skills: [
      skill("란", "공격을 튕겨낸다", "직업"),
      skill("나", "공격을 끌어들인다", "직업"),
      skill("찰", "찌르기", "직업"),
      skill("관통", "창으로 일직선상의 적을 꿰뚫는다. 위력 = 물리 공격력 × 2", "직업"),
    ],
  },
  "격투가": {
    stats: statMap({ 힘: 3, 민첩: 3, 체력: 3 }),
    desc: "힘 +3, 민첩 +3, 체력 +3. 격투 기술은 플레이어가 제작.",
    skills: [skill("연격", "맨손 공격을 민첩/10회 가한다. 각 공격 위력은 물리 공격력의 절반", "직업")],
  },
  "광전사": {
    stats: statMap({ 체력: 2 }),
    berserker: true,
    desc: "체력 +2. HP 감소치/10 만큼 힘 증가.",
    skills: [
      skill("옹골참", "즉사급 피해를 HP 1로 1회 버틴다. HP가 가득 차면 재사용 가능", "직업"),
      skill("광폭화", "아군과 적군 구분 없이 공격. 기본 공격력 4배", "직업"),
      skill("피의 분노", "체력을 사용해 물리 공격력을 사용한 체력/5 만큼 강화", "직업"),
      skill("광기의 돌진", "이번 공격의 물리 공격력 2배. 다음 턴까지 받는 피해도 2배", "직업"),
    ],
  },
  "연금술사": {
    stats: statMap({ 지능: 1, 지혜: 1 }),
    desc: "지능 +1, 지혜 +1. 연금술 도구 소환 가능.",
    skills: [
      skill("약제술", "재료로 물약 제작. 지능 판정", "직업"),
      skill("연단술", "재료로 단약 제작. 지혜 판정", "직업"),
      skill("연금술", "재료를 다른 물질로 등가교환", "직업"),
      skill("촉매 제작", "지능 판정. 성공 시 다음 제작 판정 +10", "직업"),
    ],
  },
  "점성술사": {
    stats: statMap({ 지혜: 5 }),
    desc: "지혜 +5.",
    skills: [
      skill("운명 저장", "원하는 스탯 판정을 저장해 원할 때 교체. 저장 1개", "직업"),
      skill("예지", "지혜 판정 1d(지혜+20). 성공 시 GM에게 질문", "직업"),
      skill("점 보기", "지능 판정 1d(지능+20). 길이 행운인지 불행인지 파악", "직업"),
      skill("별의 인도", "지혜 판정. 성공 시 아군 1명 다음 판정 재굴림", "직업"),
    ],
  },
  "폭탄마": {
    stats: statMap({ 힘: 1, 체력: 1, 민첩: 1 }),
    desc: "힘 +1, 체력 +1, 민첩 +1.",
    skills: [
      skill("폭탄 제조", "물체를 폭탄으로 만든다. 힘 판정", "직업"),
      skill("특성 폭탄", "물체 특성이 담긴 폭탄 제작. 체력 판정", "직업"),
      skill("원격 폭탄", "제작한 폭탄을 원할 때 터트린다", "직업"),
      skill("연쇄 폭발", "가까운 폭탄을 함께 폭발시킨다. 힘 또는 지능 판정", "직업"),
    ],
  },
};

function num(v, d = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
}
function bool(v) {
  return v === true || v === "true" || v === "예";
}
function arr(v) {
  if (!v) return [];
  if (Array.isArray(v)) return v;
  try { return Array.from(v); } catch { return []; }
}
function esc(v) {
  return String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
function dice(sides) {
  return Math.floor(Math.random() * Math.max(1, Math.floor(sides))) + 1;
}
function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}
function nowText() {
  return new Date().toLocaleString("ko-KR", { hour12: false });
}

function nextLevelExp(level) {
  const lv = clamp(Math.floor(num(level, 1)), 1, 98);
  if (lv <= 1) return 100;
  return 100 + lv * 40 + lv * lv * 10;
}
function expToGainLevels(fromLevel, gainLevels) {
  let lv = clamp(Math.floor(num(fromLevel, 1)), 1, 99);
  const count = clamp(Math.floor(num(gainLevels, 1)), 1, 5);
  let total = 0;
  for (let i = 0; i < count && lv < 99; i++) {
    total += nextLevelExp(lv);
    lv += 1;
  }
  return total;
}
function adventurerGrade(level) {
  const lv = clamp(Math.floor(num(level, 1)), 1, 99);
  return ADVENTURER_GRADES.find(g => lv >= g.최소레벨 && lv <= g.최대레벨) ?? ADVENTURER_GRADES[0];
}
function missionRiskDef(risk) {
  const r = clamp(Math.floor(num(risk, 1)), 1, 5);
  return MISSION_RISKS.find(x => x.위험도 === r) ?? MISSION_RISKS[0];
}
function missionExp(level, risk) {
  const r = missionRiskDef(risk);
  return expToGainLevels(level, r.목표상승);
}
function applyExperiencePatch(amountRaw) {
  const amount = Math.max(0, Math.floor(num(amountRaw, 0)));
  let level = clamp(Math.floor(num(state.레벨, 1)), 1, 99);
  let exp = Math.max(0, Math.floor(num(state.경험치, 0))) + amount;
  let gained = 0;
  while (level < 99) {
    const need = nextLevelExp(level);
    if (exp < need) break;
    exp -= need;
    level += 1;
    gained += 1;
  }
  if (level >= 99) exp = Math.max(0, exp);
  const grade = adventurerGrade(level);
  const beforeGrade = adventurerGrade(state.레벨);
  const gradeChanged = beforeGrade.등급 !== grade.등급;
  const result = `경험치 +${amount} / 레벨 ${state.레벨} → ${level}${gained ? ` (${gained}레벨 상승)` : ""} / 경험치 ${exp} / 다음 필요 ${level < 99 ? nextLevelExp(level) : "최대 레벨"} / 모험가 등급 ${beforeGrade.등급} → ${grade.등급}${gradeChanged ? " 등급 상승" : ""}`;
  return {
    레벨: level,
    경험치: exp,
    누적경험치: Math.max(0, num(state.누적경험치, 0)) + amount,
    모험가등급: grade.등급,
    스탯코인: Math.max(0, num(state.스탯코인, 0)) + gained,
    경험치결과: result,
    최근결과: result,
    로그: [],
    효과로그: [],
  };
}

function raceDef() { return RACES[state.종족] ?? RACES["인간"]; }
function jobDef() { return JOBS[state.직업] ?? JOBS["검사"]; }

let state = {
  시트버전: cur.시트버전 ?? "NewTRPG_PlayerSheet_v0.4.1_item_ability_xp",
  이름: cur.이름 ?? cur.file.name,
  구분: cur.구분 ?? "플레이어",
  시트지속성: cur.시트지속성 ?? cur.구분 ?? "플레이어",
  시나리오: cur.시나리오 ?? "임시 시나리오",
  턴: num(cur.턴, 1),
  레벨: num(cur.레벨, 1),
  경험치: num(cur.경험치, 0),
  누적경험치: num(cur.누적경험치 ?? cur.총경험치, 0),
  모험가등급: cur.모험가등급 ?? adventurerGrade(num(cur.레벨, 1)).등급,
  경험치결과: cur.경험치결과 ?? "경험치 처리 대기",
  최근임무경험치계산: cur.최근임무경험치계산 ?? "임무 경험치 계산 대기",
  스탯코인: num(cur.스탯코인, 6),
  코인: num(cur.코인, 0),
  종족: cur.종족 ?? "인간",
  직접종족보정스탯: cur.직접종족보정스탯 ?? "힘",
  직업: cur.직업 ?? "검사",
  만트라: "",
  만트라설명: "",
  직업패시브2배: false,
  만다라종류: cur.만다라종류 ?? "없음",
  만다라명: cur.만다라명 ?? "",
  만다라발동중: bool(cur.만다라발동중),
  현재HP: num(cur.현재HP, 10),
  수동제거스탯: arr(cur.수동제거스탯 ?? cur.제거스탯),
  최대HP보정: num(cur.최대HP보정, 0),
  물리공격보정: num(cur.물리공격보정, 0),
  정신공격보정: num(cur.정신공격보정, 0),
  피해감소보정: num(cur.피해감소보정, 0),
  판정난이도보정: num(cur.판정난이도보정, 0),
  용린사용중: bool(cur.용린사용중),
  최근결과: cur.최근결과 ?? "대기 중",
  스킬결과: cur.스킬결과 ?? "스킬 결과 대기",
  다이스표시: cur.다이스표시 ?? "대기",
  다이스상세: cur.다이스상세 ?? "판정 전",
  다이스결과타입: cur.다이스결과타입 ?? "대기",
  상대다이스내표시: cur.상대다이스내표시 ?? "대기",
  상대다이스상대표시: cur.상대다이스상대표시 ?? "대기",
  상대다이스상세: cur.상대다이스상세 ?? "상대 판정 전",
  상대다이스결과타입: cur.상대다이스결과타입 ?? "대기",
  스탯코인대기스탯: cur.스탯코인대기스탯 ?? "",
  스탯코인대기굴림: num(cur.스탯코인대기굴림, 0),
  스탯코인다이스표시: cur.스탯코인다이스표시 ?? "대기",
  스탯코인다이스상세: cur.스탯코인다이스상세 ?? "스탯 코인 굴림 전",
  스탯코인다이스결과타입: cur.스탯코인다이스결과타입 ?? "대기",
  보유스킬: arr(cur.보유스킬),
  상태이상: arr(cur.상태이상),
  지속효과: arr(cur.지속효과),
  효과로그: arr(cur.효과로그),
  장비목록: arr(cur.장비목록),
  아이템목록: arr(cur.아이템목록),
  축복사용턴: num(cur.축복사용턴, 0),
  성장기록: [],
  로그: [],
  효과로그: [],
  메모: cur.메모 ?? "",
  시나리오목록캐시: arr(cur.시나리오목록캐시),
  시나리오목록캐시갱신일시: cur.시나리오목록캐시갱신일시 ?? "",
  NPC목록캐시: arr(cur.NPC목록캐시),
  NPC목록캐시시나리오: cur.NPC목록캐시시나리오 ?? "",
  NPC목록캐시갱신일시: cur.NPC목록캐시갱신일시 ?? "",
  아이템목록캐시: arr(cur.아이템목록캐시),
  아이템목록캐시시나리오: cur.아이템목록캐시시나리오 ?? "",
  아이템목록캐시갱신일시: cur.아이템목록캐시갱신일시 ?? "",
};

for (const s of STAT_KEYS) {
  state[s] = num(cur[s], 1);
  for (const kind of ["아이템", "스킬", "임시"]) {
    state[`${s}${kind}`] = num(cur[`${s}${kind}`], 0);
  }
}

function baseStatMax(level = state.레벨) {
  return Math.min(100, Math.max(1, num(level, 1) + 20));
}
function jobMul() {
  return 1;
}
function activeMandalaType() {
  const forced = raceDef().forceMandala;
  return forced || state.만다라종류 || "없음";
}
function activeEvolutionDef() {
  const evo = EVOLUTIONS[state.종족];
  if (!evo) return null;
  if (state.종족 === "용인족") return bool(state.특수진화완료) ? evo : null;
  return activeMandalaType() === "진화" && num(state.레벨, 1) >= 70 ? evo : null;
}
function isEvolutionActive() {
  return !!activeEvolutionDef();
}
function baseStatForCalc(stat) {
  let base = num(state[stat], 1);
  const evo = activeEvolutionDef();
  if (evo?.equalizeBase) base = Math.max(...STAT_KEYS.map(s => num(state[s], 1)));
  if (evo?.doubleBaseCon && stat === "체력") base *= 2;
  return base;
}
function evolutionBonus(stat) {
  const evo = activeEvolutionDef();
  if (!evo) return 0;
  let v = num(evo.stats?.[stat], 0);
  if (evo.directStat && state.직접종족보정스탯 === stat) v += 10;
  return v;
}
function blessingBonus(stat) {
  if (state.종족 !== "천사") return 0;
  return Math.max(0, num(state.축복스택, 0));
}
function autoRaceBonus(stat) {
  const r = raceDef();
  let v = num(r.stats?.[stat], 0);
  if (r.directStat && state.직접종족보정스탯 === stat) v += 10;
  if (r.slimeTransfer && stat === "민첩") v += num(state.외모, 1);
  if (r.cyborgSplit && CORE_STAT_KEYS.includes(stat)) v += Math.floor(num(state.외모, 1) / 5);
  v += evolutionBonus(stat);
  v += blessingBonus(stat);
  return v;
}
function autoJobBonusRaw(stat) {
  const j = jobDef();
  return num(j.stats?.[stat], 0) * jobMul();
}
function activeEffectStatBonus(stat) {
  return arr(state.지속효과).reduce((sum, e) => {
    if (!e || (e.대상 && e.대상 !== "self")) return sum;
    return sum + num(e?.스탯변화?.[stat], 0);
  }, 0);
}
function activeEffectExtraBonuses() {
  const key = cacheKey(state.지속효과);
  if (__nrpgCache.activeEffectExtraKey === key && __nrpgCache.activeEffectExtra) return __nrpgCache.activeEffectExtra;
  const out = { maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0 };
  for (const e of arr(state.지속효과)) {
    if (!e || (e.대상 && e.대상 !== "self")) continue;
    const b = e.수치보정 ?? e.보정 ?? {};
    out.maxHP += num(b.maxHP ?? b.최대HP, 0);
    out.physical += num(b.physical ?? b.물리공격력, 0);
    out.mental += num(b.mental ?? b.정신공격력 ?? b.마법공격력, 0);
    out.reduction += num(b.reduction ?? b.피해감소, 0);
    out.difficulty += num(b.difficulty ?? b.판정난이도, 0);
  }
  __nrpgCache.activeEffectExtraKey = key;
  __nrpgCache.activeEffectExtra = out;
  return out;
}
function manualBonus(stat) {
  return num(state[`${stat}아이템`]) + num(state[`${stat}스킬`]) + num(state[`${stat}임시`]) + num(equipmentBonuses().stats?.[stat], 0) + num(ownedItemBonuses().stats?.[stat], 0) + activeEffectStatBonus(stat);
}
function removedStats() {
  const key = `${state.종족}|${cacheKey(state.수동제거스탯)}`;
  if (__nrpgCache.removedStatsKey === key && __nrpgCache.removedStats) return __nrpgCache.removedStats;
  const set = new Set(arr(state.수동제거스탯).filter(x => STAT_KEYS.includes(x)));
  for (const s of (raceDef().remove ?? [])) set.add(s);
  const out = Array.from(set);
  __nrpgCache.removedStatsKey = key;
  __nrpgCache.removedStats = out;
  return out;
}
function isRemoved(stat) {
  return removedStats().includes(stat);
}
function rawEffectiveWithoutBerserk(stat) {
  if (isRemoved(stat)) return null;
  return Math.max(1, baseStatForCalc(stat) + autoRaceBonus(stat) + autoJobBonusRaw(stat) + manualBonus(stat));
}
function berserkerPowerBonus() {
  if (!jobDef().berserker) return 0;
  const baseCon = rawEffectiveWithoutBerserk("체력") ?? 1;
  const tempMaxHP = Math.max(1, baseCon * 10 + num(state.최대HP보정, 0));
  const missing = Math.max(0, tempMaxHP - num(state.현재HP, tempMaxHP));
  return Math.floor(missing / 10);
}
function effectiveStat(stat) {
  if (isRemoved(stat)) return null;
  let value = rawEffectiveWithoutBerserk(stat);
  if (stat === "힘") value += berserkerPowerBonus();
  if (stat === "민첩" && yongrinActive()) value = Math.max(1, Math.floor(value / 2));
  return Math.max(1, value);
}
function calcBase() {
  const eff = Object.fromEntries(STAT_KEYS.map(s => [s, effectiveStat(s)]));
  const eq = equipmentBonuses();
  const owned = ownedItemBonuses();
  const ae = activeEffectExtraBonuses();
  const maxHP = Math.max(1, num(eff.체력, 1) * 10 + num(state.최대HP보정, 0) + num(eq.maxHP,0) + num(owned.maxHP,0) + num(ae.maxHP,0));
  let physical = Math.max(0, Math.floor((num(eff.힘, 1) + num(eff.체력, 1)) / 2));
  physical += num(jobDef().physicalBonus, 0) * jobMul();
  physical += num(state.물리공격보정, 0) + num(eq.physical,0) + num(owned.physical,0) + num(ae.physical,0);
  let mental = Math.max(0, Math.floor((num(eff.지능, 1) + num(eff.지혜, 1)) / 2));
  mental += num(state.정신공격보정, 0) + num(eq.mental,0) + num(owned.mental,0) + num(ae.mental,0);
  return { eff, maxHP, physical, mental, magic: mental, maxS: baseStatMax() };
}
function calc() {
  const d = calcBase();
  const eq = equipmentBonuses();
  const ae = activeEffectExtraBonuses();
  let reduction = num(state.피해감소보정, 0) + num(eq.reduction,0) + num(ownedItemBonuses().reduction,0) + num(ae.reduction,0);
  if (jobDef().tankReduction) reduction += d.physical * jobMul();
  const race = raceDef();
  const yongrinMul = yongrinActive() ? 0.5 : 1;
  return { ...d, reduction, physicalTakenMul: (race.physicalTakenMul ?? 1) * yongrinMul, magicTakenMul: (race.magicTakenMul ?? 1) * yongrinMul };
}
function skillIdentity(s) {
  return `${s?.이름 ?? s?.name ?? ""}::${s?.종류 ?? s?.type ?? ""}::${s?.레벨 ?? s?.획득레벨 ?? ""}`;
}
function autoEvolutionSkills() {
  const evo = activeEvolutionDef();
  if (!evo) return [];
  const out = [];
  if (num(state.레벨, 1) >= 70) out.push(...arr(evo.skills70));
  if (num(state.레벨, 1) >= 80) out.push(...arr(evo.skills80));
  if (num(state.레벨, 1) >= 90) out.push(...arr(evo.skills90));
  return out.map(s => ({ ...s, 자동스킬: true, 자동출처: `진화:${evo.name}` }));
}
function autoPassiveDisplaySkills() {
  const out = [];
  const evo = activeEvolutionDef();
  if (evo?.constantFlight) out.push(skill('상시 비행', '진화 패시브로 비행이 항상 적용된다.', '패시브', '진화'));
  if (activeMandalaType() === '변신' && bool(state.만다라발동중) && String(state.코스튬상시스킬 ?? '').trim()) {
    out.push(skill(`코스튬 패시브: ${String(state.코스튬상시스킬).trim()}`, `코스튬 ${state.코스튬이름 || ''} 착용 중 상시 적용되는 스킬.`, '패시브', '변신'));
  }
  return out.map(s => ({ ...s, 자동스킬: true, 자동출처: '패시브' }));
}
function ensureAutoSkills(list) {
  let next = [...arr(list)];
  const forced = raceDef().forcedSkill ? { ...raceDef().forcedSkill, 자동스킬: true, 자동출처: '종족필수' } : null;
  const autos = [forced, ...autoEvolutionSkills(), ...autoPassiveDisplaySkills()].filter(Boolean);
  for (const auto of autos) {
    if (!next.some(s => (s?.이름 ?? s?.name) === auto.이름 && String(s?.레벨 ?? '') === String(auto.레벨 ?? ''))) next.unshift(auto);
  }
  return next;
}
function normalize() {
  if (!RACES[state.종족]) state.종족 = "인간";
  if (!JOBS[state.직업]) state.직업 = "검사";
  if (!STAT_KEYS.includes(state.직접종족보정스탯)) state.직접종족보정스탯 = "힘";
  if (!SHEET_ATTRS.includes(state.시트지속성)) state.시트지속성 = "플레이어";
  const scenarios = scenarioList();
  state.시나리오 = String(state.시나리오 || scenarios[0] || "임시 시나리오").trim() || "임시 시나리오";
  if (!scenarios.includes(state.시나리오)) state.시나리오 = scenarios[0] || "임시 시나리오";
  state.턴 = Math.max(1, num(state.턴, 1));
  state.축복스택 = Math.max(0, num(state.축복스택, 0));
  state.축복사용턴 = Math.max(0, num(state.축복사용턴, 0));
  state.레벨 = Math.max(1, num(state.레벨, 1));
  state.경험치 = Math.max(0, num(state.경험치, 0));
  state.누적경험치 = Math.max(0, num(state.누적경험치, 0));
  state.모험가등급 = adventurerGrade(state.레벨).등급;
  state.스탯코인 = Math.max(0, num(state.스탯코인, 0));
  state.코인 = Math.max(0, num(state.코인, 0));
  if (!MANDALA_TYPES.includes(state.만다라종류)) state.만다라종류 = "없음";
  const maxS = baseStatMax();
  for (const s of STAT_KEYS) state[s] = clamp(num(state[s], 1), 1, maxS);
  state.수동제거스탯 = arr(state.수동제거스탯).filter(x => STAT_KEYS.includes(x));
  state.보유스킬 = ensureAutoSkills(arr(state.보유스킬).filter(Boolean));
  state.상태이상 = arr(state.상태이상).filter(Boolean);
  state.지속효과 = arr(state.지속효과).filter(Boolean);
  state.효과로그 = [];
  state.장비목록 = arr(state.장비목록).map(normalizeEquipEntry).filter(Boolean);
  state.아이템목록 = arr(state.아이템목록).filter(Boolean);
  state.로그 = [];
  state.성장기록 = [];
  const evo = activeEvolutionDef();
  if (evo?.immuneStatus) state.상태이상 = [];
  const d = calc();
  state.현재HP = clamp(num(state.현재HP, d.maxHP), 0, d.maxHP);
}
function withLog(message, patch = {}) {
  return { ...patch, 최근결과: message, 로그: [], 효과로그: [] };
}
async function save(patch = {}) {
  Object.assign(state, patch);
  resetNrpgCalcCache();
  normalize();
  await app.fileManager.processFrontMatter(file, fm => {
    for (const [key, value] of Object.entries(state)) fm[key] = value;
  });
  scheduleRender();
}
let __nrpgRenderQueued = false;
function scheduleRender() {
  if (__nrpgRenderQueued) return;
  __nrpgRenderQueued = true;
  const run = () => {
    __nrpgRenderQueued = false;
    render();
  };
  if (window?.requestIdleCallback) window.requestIdleCallback(run, { timeout: 250 });
  else setTimeout(run, 80);
}
function skillCounts() {
  const out = { 고유: 0, 종족: 0, 직업: 0 };
  for (const s of state.보유스킬) {
    const t = s?.종류 ?? s?.type ?? s?.kind ?? "";
    if (out[t] !== undefined) out[t]++;
  }
  return out;
}
function mandalaSuggestion() {
  const r = raceDef();
  if (r.forceMandala) return { type: r.forceMandala, text: `${state.종족}은 스킬 비율과 관계없이 ${r.forceMandala} 만다라.` };
  const c = skillCounts();
  const max = Math.max(c.고유, c.종족, c.직업);
  const winners = Object.entries(c).filter(([, v]) => v === max && v > 0).map(([k]) => k);
  if (!winners.length) return { type: "없음", text: "아직 판정할 스킬이 없다." };
  if (winners.length > 1) return { type: "선택", text: `동률: ${winners.join(" / ")} 중 선택.` };
  return { type: winners[0] === "종족" ? "진화" : winners[0] === "직업" ? "영역" : "변신", text: `${winners[0]}스킬이 가장 많다.` };
}
function warnings() {
  const list = [];
  if (state.종족 === "인간" && state.보유스킬.some(s => (s?.종류 ?? s?.type) === "종족")) list.push("인간은 종족스킬이 없는 종족입니다. 종족스킬을 제거하거나 종류를 바꿔야 합니다.");
  if (DIRECT_RACES.includes(state.종족)) list.push(`${state.종족}은 선택 형태에 맞춰 종족스킬을 직접 제작합니다. 공통 추가 스킬은 없습니다.`);
  if (state.종족 === "슬라임") list.push("슬라임은 외모가 제거되고 기본 외모 수치가 민첩에 자동 합산됩니다.");
  if (state.종족 === "사이보그") list.push("사이보그는 외모가 제거되고 기본 외모/5가 힘·민첩·체력·지능·지혜에 자동 합산됩니다.");
  if (jobDef().berserker) list.push(`광전사 효과 적용 중: HP 감소치/10 만큼 힘 +${berserkerPowerBonus()}.`);
  return list;
}
function adjustedDifficulty(raw) {
  return Math.max(1, num(raw, 1) + num(state.판정난이도보정, 0) + num(raceDef().difficultyBonus, 0) + num(equipmentBonuses().difficulty,0) + num(ownedItemBonuses().difficulty,0) + num(activeEffectExtraBonuses().difficulty,0));
}
function skillKey(s) {
  return `${s.종류}|${s.이름}|${s.레벨 ?? ""}`;
}
function addableRaceSkills() {
  const owned = new Set(state.보유스킬.map(skillKey));
  return (raceDef().skills ?? []).filter(s => !owned.has(skillKey(s)));
}
function addableJobSkills() {
  const owned = new Set(state.보유스킬.map(skillKey));
  return (jobDef().skills ?? []).filter(s => !owned.has(skillKey(s)));
}
function itemTextList(list) {
  return arr(list).map(x => typeof x === "string" ? x : (x?.이름 ?? x?.name ?? JSON.stringify(x))).join("\n");
}
function card(label, value, sub = "") {
  return `<div class="nrpg-card"><div>${esc(label)}</div><b>${esc(value)}</b>${sub ? `<span>${esc(sub)}</span>` : ""}</div>`;
}
function bar(label, curValue, maxValue) {
  const pct = maxValue <= 0 ? 0 : clamp((curValue / maxValue) * 100, 0, 100);
  return `<div class="nrpg-bar"><div class="nrpg-bar-top"><span>${label}</span><b>${curValue} / ${maxValue}</b></div><i><u style="width:${pct}%"></u></i></div>`;
}
function selectOptions(list, selected) {
  return list.map(x => `<option value="${esc(x)}" ${x === selected ? "selected" : ""}>${esc(x)}</option>`).join("");
}
function scenarioList(load = false) {
  const fallback = [String(state.시나리오 || "임시 시나리오")];
  const cached = readStoredList("scenario", "global");
  if (cached.length && !load) {
    const list = cached.map(x => String(x.name ?? x.scenario ?? "").trim()).filter(Boolean);
    return Array.from(new Set([...fallback, ...list]));
  }
  if (!load) return fallback;
  try {
    const page = allPagesSearchNow().find(p => p?.file?.name === "시나리오_목록");
    const raw = page?.시나리오목록 ?? page?.목록 ?? page?.scenarios;
    const list = arr(raw).map(x => String(x ?? "").trim()).filter(Boolean);
    const unique = Array.from(new Set([...fallback, ...list]));
    writeStoredList("scenario", unique.map(name => ({ name })), "global");
    return unique.length ? unique : fallback;
  } catch (e) {
    return fallback;
  }
}
function scenarioOptions(selected = state.시나리오) {
  const list = scenarioList(false);
  const withCurrent = selected && !list.includes(selected) ? [selected, ...list] : list;
  return selectOptions(withCurrent, selected || withCurrent[0]);
}
function statSelect(id, selected = "힘") {
  return `<select id="${id}">${STAT_KEYS.map(s => `<option value="${s}" ${s === selected ? "selected" : ""}>${s} / 유효 ${effectiveStat(s) ?? "제거"}</option>`).join("")}</select>`;
}
function fmInput(label, field, type = "text") {
  const value = state[field] ?? "";
  return `<label><span>${esc(label)}</span><input data-fm="${esc(field)}" ${type === "number" ? "data-num='1'" : ""} type="${type}" value="${esc(value)}"></label>`;
}
function fmCheckbox(label, field) {
  return `<label class="nrpg-check"><input data-fm="${esc(field)}" type="checkbox" ${bool(state[field]) ? "checked" : ""}><span>${esc(label)}</span></label>`;
}
function autoEffectTable() {
  const d = calc();
  return STAT_KEYS.map(s => `
    <tr>
      <th>${s}${isRemoved(s) ? " <em>제거</em>" : ""}</th>
      <td><input data-fm="${s}" data-num="1" type="number" value="${state[s]}"></td>
      <td>${autoRaceBonus(s) >= 0 ? "+" : ""}${autoRaceBonus(s)}</td>
      <td>${autoJobBonusRaw(s) >= 0 ? "+" : ""}${autoJobBonusRaw(s)}</td>
      <td><input data-fm="${s}아이템" data-num="1" type="number" value="${state[`${s}아이템`]}"></td>
      <td><input data-fm="${s}스킬" data-num="1" type="number" value="${state[`${s}스킬`]}"></td>
      <td><input data-fm="${s}임시" data-num="1" type="number" value="${state[`${s}임시`]}"></td>
      <td><b>${d.eff[s] === null ? "제거" : d.eff[s]}</b></td>
    </tr>`).join("");
}
function advancedSummary(advanced) {
  if (!advanced || advanced.사용 !== true) return "";
  const parts = [];
  const auto = advanced.자동효과 ?? {};
  if (advanced.스택?.이름) parts.push(`개인 스택: ${advanced.스택.이름}${advanced.스택.최대 ? ` 최대 ${advanced.스택.최대}` : ""}`);
  if (advanced.스택단계효과) parts.push("스택 단계 효과 있음");
  if (advanced.결과굴림식) parts.push(`결과 굴림: ${advanced.결과굴림식}`);
  if (advanced.영구스탯변화?.스탯 && String(advanced.영구스탯변화?.수치 ?? "").trim()) parts.push(`영구 ${advanced.영구스탯변화.스탯} ${advanced.영구스탯변화.수치}`);
  if (String(auto.임시스탯 ?? "").trim()) parts.push("임시 스탯 변화");
  if (String(auto.수치보정 ?? "").trim()) parts.push("공격/방어/HP/난이도 보정");
  if (String(auto.회복량 ?? "").trim()) parts.push(`회복 ${auto.회복량}`);
  if (String(auto.피해량 ?? "").trim()) parts.push(`${auto.피해종류 ?? "고정"} 피해 ${auto.피해량}`);
  if (String(auto.상태부여 ?? "").trim()) parts.push(`상태: ${auto.상태부여}`);
  if (String(auto.코인변화 ?? "").trim()) parts.push(`코인 ${auto.코인변화}`);
  if (advanced.리스크) parts.push(`리스크: ${advanced.리스크}`);
  return parts.join(" / ");
}
function parseStackSteps(raw) {
  return String(raw ?? "").split("\n").map(line => line.trim()).filter(Boolean).map(line => {
    const m = line.match(/^(\d+)\s*[:=]\s*(.+)$/);
    return m ? { 단계: Number(m[1]), 효과: m[2].trim() } : { 단계: null, 효과: line };
  });
}
function parseResultTable(raw) {
  return String(raw ?? "").split("\n").map(line => line.trim()).filter(Boolean).map(line => {
    const m = line.match(/^([^:=]+)\s*[:=]\s*(.+)$/);
    if (!m) return { 조건: line, 효과: line };
    const key = m[1].trim();
    const effect = m[2].trim();
    return { 조건: key, 단계: /^\d+$/.test(key) ? Number(key) : null, 효과: effect };
  });
}
function splitEffectLines(raw) {
  return String(raw ?? "").split(/[\n,]+/).map(x => x.trim()).filter(Boolean);
}
function parseStatChangeMap(raw) {
  const map = statMap();
  const details = [];
  for (const line of splitEffectLines(raw)) {
    const m = line.match(/^(올스탯|전스탯|전체|힘|민첩|체력|지능|지혜|외모)\s*[:=]?\s*([+-]?\s*\d*d?\d+(?:[+-]\d+)?)$/i);
    if (!m) { details.push(`해석 실패: ${line}`); continue; }
    const key = m[1];
    const formula = m[2].replaceAll(" ", "");
    const roll = parseDiceFormula(formula);
    if (!roll.ok) { details.push(roll.detail); continue; }
    const targets = ["올스탯", "전스탯", "전체"].includes(key) ? STAT_KEYS : [key];
    for (const s of targets) map[s] += roll.total;
    details.push(`${targets.join("/")} ${roll.total >= 0 ? "+" : ""}${roll.total}${roll.detail !== String(roll.total) ? ` (${roll.detail})` : ""}`);
  }
  return { map, details, has: STAT_KEYS.some(s => map[s] !== 0) };
}
function parseExtraBonusMap(raw) {
  const out = { maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0 };
  const aliases = {
    "최대HP": "maxHP", "HP": "maxHP", "물리공격력": "physical", "물공": "physical",
    "정신공격력": "mental", "마법공격력": "mental", "마공": "mental", "피해감소": "reduction", "방어": "reduction",
    "판정난이도": "difficulty", "난이도": "difficulty"
  };
  const details = [];
  for (const line of splitEffectLines(raw)) {
    const m = line.match(/^(최대HP|HP|물리공격력|물공|정신공격력|마법공격력|마공|피해감소|방어|판정난이도|난이도)\s*[:=]?\s*([+-]?\s*\d*d?\d+(?:[+-]\d+)?)$/i);
    if (!m) { details.push(`해석 실패: ${line}`); continue; }
    const key = aliases[m[1]];
    const formula = m[2].replaceAll(" ", "");
    const roll = parseDiceFormula(formula);
    if (!roll.ok) { details.push(roll.detail); continue; }
    out[key] += roll.total;
    details.push(`${m[1]} ${roll.total >= 0 ? "+" : ""}${roll.total}${roll.detail !== String(roll.total) ? ` (${roll.detail})` : ""}`);
  }
  return { map: out, details, has: Object.values(out).some(v => v !== 0) };
}
function hpValueFromFormula(raw, maxHP = calc().maxHP) {
  const text = String(raw ?? "").trim().replaceAll(" ", "");
  if (!text) return { ok: true, total: 0, detail: "0" };
  const pct = text.match(/^([+-]?\d+)%$/);
  if (pct) {
    const v = Math.floor(maxHP * Number(pct[1]) / 100);
    return { ok: true, total: v, detail: `${text}=${v}` };
  }
  const maxPct = text.match(/^최대HP([+-]?\d+)%$/);
  if (maxPct) {
    const v = Math.floor(maxHP * Number(maxPct[1]) / 100);
    return { ok: true, total: v, detail: `${text}=${v}` };
  }
  return parseDiceFormula(text);
}
function activeEffectTextFromMaps(statMapObj, bonusObj) {
  const statText = STAT_KEYS.filter(s => num(statMapObj?.[s],0) !== 0).map(s => `${s}${num(statMapObj[s],0) >= 0 ? "+" : ""}${num(statMapObj[s],0)}`).join(", ");
  const bonusText = Object.entries({ 최대HP: bonusObj?.maxHP, 물리공격력: bonusObj?.physical, 정신공격력: bonusObj?.mental, 피해감소: bonusObj?.reduction, 판정난이도: bonusObj?.difficulty })
    .filter(([_,v]) => num(v,0) !== 0).map(([k,v]) => `${k}${num(v,0) >= 0 ? "+" : ""}${num(v,0)}`).join(", ");
  return [statText, bonusText].filter(Boolean).join(" / ") || "자동 효과";
}
function parseDiceFormula(raw) {
  const text = String(raw ?? "").trim().replaceAll(" ", "");
  if (!text) return { ok: true, total: 0, detail: "0", formula: "0", rolls: [] };
  if (/^[+-]?\d+$/.test(text)) return { ok: true, total: Number(text), detail: text, formula: text, rolls: [] };
  const m = text.match(/^([+-]?)(\d*)d(\d+)([+-]\d+)?$/i);
  if (!m) return { ok: false, total: 0, detail: `지원하지 않는 주사위식: ${text}`, formula: text, rolls: [] };
  const sign = m[1] === "-" ? -1 : 1;
  const count = Math.max(1, Number(m[2] || 1));
  const sides = Math.max(1, Number(m[3]));
  const mod = Number(m[4] || 0);
  const rolls = Array.from({ length: count }, () => dice(sides));
  const subtotal = rolls.reduce((a, b) => a + b, 0);
  const total = sign * subtotal + mod;
  const signText = sign < 0 ? "-" : "";
  const modText = mod ? `${mod > 0 ? "+" : ""}${mod}` : "";
  return { ok: true, total, detail: `${signText}${count}d${sides}${modText} = [${rolls.join(", ")}]${modText} → ${total}`, formula: text, rolls };
}
function tableEffectByRoll(table, roll) {
  const list = arr(table);
  for (const x of list) {
    const rule = String(x?.조건 ?? x?.단계 ?? "").trim();
    const effect = String(x?.효과 ?? "").trim();
    if (!effect) continue;
    if (!rule && num(x?.단계, NaN) === roll) return effect;
    if (/^\d+$/.test(rule) && Number(rule) === roll) return effect;
    const range = rule.match(/^(\d+)\s*[-~]\s*(\d+)$/);
    if (range) {
      const a = Number(range[1]), b = Number(range[2]);
      if (roll >= Math.min(a,b) && roll <= Math.max(a,b)) return effect;
    }
    const plus = rule.match(/^(\d+)\+$/);
    if (plus && roll >= Number(plus[1])) return effect;
    const minus = rule.match(/^<=?\s*(\d+)$/);
    if (minus && roll <= Number(minus[1])) return effect;
    if (rule === '짝수' && roll % 2 === 0) return effect;
    if (rule === '홀수' && roll % 2 === 1) return effect;
  }
  return "";
}
function safeJson(raw) {
  const s = String(raw ?? "").trim();
  if (!s) return null;
  try { return JSON.parse(s); } catch { return { 원문: s, 오류: "JSON 형식이 아니므로 원문으로 저장됨" }; }
}
function canUseSkillByMandala(skill) {
  const type = String(skill?.종류 ?? skill?.type ?? "");
  const level = num(skill?.레벨 ?? skill?.획득레벨, 0);
  if (!(type === "만다라" && level >= 80)) return { ok: true, reason: "" };
  const mandala = activeMandalaType();
  if (mandala === "진화") return { ok: true, reason: "진화는 상시 적용" };
  if (["영역", "변신"].includes(mandala)) {
    return bool(state.만다라발동중)
      ? { ok: true, reason: `${mandala} 발동 중` }
      : { ok: false, reason: `${level}레벨 만다라 스킬은 ${mandala} 발동 중에만 사용할 수 있습니다.` };
  }
  return { ok: false, reason: "70레벨 만다라가 적용되지 않았습니다." };
}
function skillListHTML() {
  if (!state.보유스킬.length) return `<div class="nrpg-empty">등록된 스킬 없음</div>`;
  return state.보유스킬.map((s, i) => {
    const name = s?.이름 ?? s?.name ?? "이름 없음";
    const type = s?.종류 ?? s?.type ?? s?.kind ?? "기타";
    const level = s?.레벨 ?? s?.획득레벨 ?? "";
    const effect = s?.효과 ?? s?.effect ?? "";
    const kind = s?.효과분류 ?? s?.분류 ?? "특수";
    const target = s?.대상이름 ?? s?.대상 ?? "";
    const adv = advancedSummary(s?.고급설정);
    const forced = (state.종족 === "용인족" && name === "강제 용족화") || s?.자동스킬 === true;
    return `<div class="nrpg-list"><div><b>${esc(name)}</b><span>${esc(type)}${level ? ` / ${esc(level)}` : ""}<br>${esc(kind)}${target ? ` / 기본대상 ${esc(target)}` : ""}<br>${esc(effect)}${adv ? `<br><em>${esc(adv)}</em>` : ""}</span></div><div class="nrpg-btns"><button data-action="useSkill" data-index="${i}">사용</button><button data-action="deleteSkill" data-index="${i}" ${forced ? "disabled" : ""}>${forced ? "자동" : "삭제"}</button></div></div>`;
  }).join("");
}
function statusHTML() {
  if (!state.상태이상.length) return `<div class="nrpg-empty">상태이상 없음</div>`;
  return state.상태이상.map((s, i) => `<button class="nrpg-pill" data-action="deleteStatus" data-index="${i}">${esc(s)} ×</button>`).join("");
}
function logHTML() {
  return `<div class="nrpg-empty">로그는 저장하지 않습니다.</div>`;
}
function warningsHTML() {
  const list = warnings();
  if (!list.length) return "";
  return `<div class="nrpg-warn">${list.map(x => `<div>⚠ ${esc(x)}</div>`).join("")}</div>`;
}
function skillOptions(list) {
  if (!list.length) return `<option value="">추가할 스킬 없음</option>`;
  return list.map((s, i) => `<option value="${i}">${esc(s.이름)} · ${esc(s.효과)}</option>`).join("");
}
function difficultyOptions(selected = 60) {
  return DIFFICULTIES.map(d => `<option value="${d.value}" ${d.value === selected ? "selected" : ""}>${d.value} · ${d.name}</option>`).join("");
}
function yongrinActive() {
  return state.용린사용중 === true || arr(state.지속효과).some(e => (e?.이름 ?? e?.name) === "용린");
}
function damageMultiplierText() {
  const d = calc();
  const parts = [];
  if (d.physicalTakenMul !== 1) parts.push(`물리 피해 ×${d.physicalTakenMul}`);
  if (d.magicTakenMul !== 1) parts.push(`마법 피해 ×${d.magicTakenMul}`);
  if (yongrinActive()) parts.push("용린 사용 중: 받는 물리/마법 피해 1/2, 민첩 1/2");
  return parts.length ? parts.join(" / ") : "특수 피해 배율 없음";
}
function parseHpCost(raw, maxHP = calc().maxHP) {
  const text = String(raw ?? "").trim();
  if (!text) return { ok: true, cost: 0, detail: "HP 소모 없음" };
  if (/^[+-]?\d+(\.\d+)?%$/.test(text)) {
    const pct = Number(text.replace("%", ""));
    const cost = Math.max(0, Math.floor(maxHP * pct / 100));
    return { ok: true, cost, detail: `${text} = 최대 HP ${maxHP}의 ${pct}% → ${cost}` };
  }
  const roll = parseDiceFormula(text);
  if (!roll.ok) return { ok: false, cost: 0, detail: roll.detail };
  return { ok: true, cost: Math.max(0, Math.abs(roll.total)), detail: roll.detail };
}
function incomingDamageResult(rawAmount, kind = "물리") {
  const d = calc();
  const raw = Math.max(0, num(rawAmount, 0));
  let after = raw;
  const notes = [];
  if (kind === "물리") {
    const reduced = Math.max(0, raw - d.reduction);
    notes.push(`피해감소 ${d.reduction}: ${raw} → ${reduced}`);
    after = Math.floor(reduced * d.physicalTakenMul);
    notes.push(`물리 배율 ×${d.physicalTakenMul}: 최종 ${after}`);
  } else if (kind === "마법") {
    after = Math.floor(raw * d.magicTakenMul);
    notes.push(`마법 배율 ×${d.magicTakenMul}: ${raw} → ${after}`);
  } else if (kind === "고정") {
    notes.push("고정 피해: 피해감소와 배율을 적용하지 않음");
  } else if (kind === "순수") {
    notes.push("순수 피해: 모든 감소·배율·방어 효과 무시");
  }
  return { raw, kind, final: Math.max(0, after), detail: notes.join(" / ") };
}
function resetBlessingOnDamagePatch(patch, finalDamage) {
  if (finalDamage > 0 && state.종족 === "천사" && num(state.축복스택, 0) > 0) {
    patch.축복스택 = 0;
    patch.효과로그 = [...arr(patch.효과로그 ?? state.효과로그), `${nowText()} · 피해로 신의 축복 스택 초기화`].slice(-30);
  }
  return patch;
}
function equipmentGradeHTML() {
  return `<table class="nrpg-table"><thead><tr><th>등급</th><th>기준 가격</th><th>설명</th></tr></thead><tbody>${EQUIPMENT_GRADES.map(g => `<tr><td><b>${esc(g.등급)}</b></td><td>${esc(g.기준가격)}</td><td>${esc(g.설명)}</td></tr>`).join("")}</tbody></table>`;
}
function normalizeEquipEntry(entry) {
  if (!entry) return null;
  if (typeof entry === 'object') {
    return {
      이름: String(entry.이름 ?? entry.name ?? '').trim(),
      등급: String(entry.등급 ?? entry.grade ?? '일반').trim() || '일반',
      가격: Number(entry.가격 ?? entry.price ?? 0) || 0,
      효과: String(entry.효과 ?? entry.effect ?? '').trim(),
    };
  }
  const raw = String(entry).trim();
  if (!raw) return null;
  const parts = raw.split('|').map(x => x.trim());
  if (parts.length >= 4) return { 이름: parts[0], 등급: parts[1] || '일반', 가격: Number(parts[2]) || 0, 효과: parts.slice(3).join('|') };
  return { 이름: raw, 등급: '일반', 가격: 0, 효과: '' };
}
function equipmentBonuses() {
  const cache = cacheKey(state.장비목록);
  if (__nrpgCache.equipmentBonusesKey === cache && __nrpgCache.equipmentBonuses) return __nrpgCache.equipmentBonuses;
  const out = { stats: statMap(), maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0, items: [] };
  const keyMap = { '물리공격력': 'physical', '정신공격력': 'mental', '마법공격력': 'mental', '피해감소': 'reduction', '최대HP': 'maxHP', '판정난이도': 'difficulty' };
  for (const raw of arr(state.장비목록)) {
    const item = normalizeEquipEntry(raw);
    if (!item) continue;
    out.items.push(item);
    const effect = String(item.효과 || '').replaceAll('−','-');
    for (const stat of STAT_KEYS) {
      const re = new RegExp(`${stat}\\s*([+-])\\s*(\\d+)`, 'g');
      let m;
      while ((m = re.exec(effect)) !== null) out.stats[stat] += (m[1] === '-' ? -1 : 1) * Number(m[2]);
    }
    for (const [label, key] of Object.entries(keyMap)) {
      const re = new RegExp(`${label}\\s*([+-])\\s*(\\d+)`, 'g');
      let m;
      while ((m = re.exec(effect)) !== null) out[key] += (m[1] === '-' ? -1 : 1) * Number(m[2]);
    }
  }
  __nrpgCache.equipmentBonusesKey = cache;
  __nrpgCache.equipmentBonuses = out;
  return out;
}
function equipmentSummaryText() {
  const eq = equipmentBonuses();
  const bits = [];
  for (const st of STAT_KEYS) if (eq.stats[st]) bits.push(`${st} ${eq.stats[st] >= 0 ? '+' : ''}${eq.stats[st]}`);
  if (eq.maxHP) bits.push(`최대HP ${eq.maxHP >= 0 ? '+' : ''}${eq.maxHP}`);
  if (eq.physical) bits.push(`물공 ${eq.physical >= 0 ? '+' : ''}${eq.physical}`);
  if (eq.mental) bits.push(`정신/마법 ${eq.mental >= 0 ? '+' : ''}${eq.mental}`);
  if (eq.reduction) bits.push(`피해감소 ${eq.reduction >= 0 ? '+' : ''}${eq.reduction}`);
  if (eq.difficulty) bits.push(`판정난이도 ${eq.difficulty >= 0 ? '+' : ''}${eq.difficulty}`);
  return bits.length ? bits.join(' / ') : '자동 적용 장비 효과 없음';
}
function randomPickKey(obj) {
  const keys = Object.keys(obj);
  const index = dice(keys.length) - 1;
  return { keys, index, value: keys[index] };
}
function starterStatPatch() {
  const patch = { 스탯코인: 6, 현재HP: 10 };
  for (const st of STAT_KEYS) {
    patch[st] = 1;
    patch[`${st}임시`] = 0;
  }
  return patch;
}


function targetPages(load = false) {
  const scenario = String(state.시나리오 ?? "");
  const cached = readStoredList("npc", scenario);
  if (cached.length && !load) return cached.map(recordToPage).filter(Boolean);
  if (!load) return [];
  try {
    const pages = allPagesSearchNow()
      .filter(p => String(p.시나리오 ?? "") === scenario && String(p.시트지속성 ?? "") === "NPC")
      .sort(sortByName);
    const records = pages.map(pageRecord).filter(r => r.path);
    writeStoredList("npc", records, scenario);
    return records.map(recordToPage).filter(Boolean);
  } catch (e) {
    return [];
  }
}
function targetOptions(selected = "") {
  const pages = targetPages(false);
  if (!pages.length) return lazyOptionMessage("NPC 목록 불러오기 필요");
  return pages.map(p => {
    const name = String(p.이름 ?? p.file.name ?? "NPC");
    const value = String(p.file.path ?? name);
    return `<option value="${esc(value)}" ${value === selected || name === selected ? "selected" : ""}>${esc(name)}</option>`;
  }).join("");
}
function directPageByPath(value) {
  const path = String(value || "").trim();
  if (!path) return null;
  const fileObj = app.vault.getAbstractFileByPath(path);
  if (!fileObj) return null;
  const fm = app.metadataCache.getFileCache(fileObj)?.frontmatter ?? {};
  return { ...fm, file: { path, name: fileObj.basename } };
}
function targetNameByValue(value) {
  const pages = targetPages(false);
  const found = pages.find(p => String(p.file.path ?? "") === String(value) || String(p.이름 ?? p.file.name ?? "") === String(value));
  if (found) return String(found.이름 ?? found.file.name);
  const direct = directPageByPath(value);
  return direct ? String(direct.이름 ?? direct.file.name) : String(value || "대상 없음");
}
function targetPageByValue(value) {
  const pages = targetPages(false);
  return pages.find(p => String(p.file.path ?? "") === String(value) || String(p.이름 ?? p.file.name ?? "") === String(value)) ?? directPageByPath(value);
}
function targetFileByValue(value) {
  const path = String(value || "").trim();
  if (!path) return null;
  const directFile = app.vault.getAbstractFileByPath(path);
  if (directFile) return directFile;
  const page = targetPageByValue(value);
  if (!page?.file?.path) return null;
  return app.vault.getAbstractFileByPath(page.file.path) ?? null;
}
function targetLiveDataByValue(value) {
  if (!String(value || "").trim()) return null;
  const page = targetPageByValue(value);
  const fileObj = targetFileByValue(value);
  const fm = fileObj ? (app.metadataCache.getFileCache(fileObj)?.frontmatter ?? {}) : {};
  if (!page && !fileObj) return null;
  return { ...(page ?? {}), ...fm, file: page?.file ?? (fileObj ? { path: fileObj.path, name: fileObj.basename } : undefined) };
}
async function patchTargetFrontmatter(targetValue, updater) {
  const tf = targetFileByValue(targetValue);
  if (!tf) return false;
  await app.fileManager.processFrontMatter(tf, fm => updater(fm));
  return true;
}
async function addEffectToTargetFrontmatter(targetValue, effectObj) {
  return patchTargetFrontmatter(targetValue, fm => {
    const curEffects = Array.isArray(fm.지속효과) ? fm.지속효과 : [];
    const selfEffect = { ...effectObj, 대상: 'self', 대상이름: String(fm.이름 ?? targetNameByValue(targetValue) ?? '대상') };
    fm.지속효과 = [...curEffects, selfEffect];
    fm.효과로그 = [];
  });
}
async function setTargetEffectsFrontmatter(targetValue, effects, extraLogLine = '') {
  return patchTargetFrontmatter(targetValue, fm => {
    fm.지속효과 = effects;
    fm.효과로그 = [];
  });
}
async function tickScenarioNpcEffects() {
  const pages = targetPages(true);
  for (const page of pages) {
    const value = String(page?.file?.path ?? '');
    if (!value) continue;
    await patchTargetFrontmatter(value, fm => {
      const src = Array.isArray(fm.지속효과) ? fm.지속효과 : [];
      const kept = [];
      const expired = [];
      for (const e of src) {
        const turns = Math.max(1, Number(e?.남은턴 ?? 1) || 1);
        if (turns <= 1 || e?.한턴 === true) expired.push(e);
        else kept.push({ ...e, 남은턴: turns - 1 });
      }
      fm.지속효과 = kept;
      fm.효과로그 = [];
    });
  }
}
function actorEquipmentBonuses(actor) {
  const out = { stats: statMap(), maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0 };
  const keyMap = { '물리공격력': 'physical', '정신공격력': 'mental', '마법공격력': 'mental', '피해감소': 'reduction', '최대HP': 'maxHP', '판정난이도': 'difficulty' };
  for (const raw of arr(actor?.장비목록)) {
    const item = normalizeEquipEntry(raw);
    if (!item) continue;
    const effect = String(item.효과 || '').replaceAll('−','-');
    for (const stat of STAT_KEYS) {
      const re = new RegExp(`${stat}\s*([+-])\s*(\d+)`, 'g');
      let m;
      while ((m = re.exec(effect)) !== null) out.stats[stat] += (m[1] === '-' ? -1 : 1) * Number(m[2]);
    }
    for (const [label, key] of Object.entries(keyMap)) {
      const re = new RegExp(`${label}\s*([+-])\s*(\d+)`, 'g');
      let m;
      while ((m = re.exec(effect)) !== null) out[key] += (m[1] === '-' ? -1 : 1) * Number(m[2]);
    }
  }
  return out;
}
function actorRaceDef(actor) { return RACES[String(actor?.종족 ?? '인간')] ?? RACES['인간']; }
function actorJobDef(actor) { return JOBS[String(actor?.직업 ?? "검사")] ?? JOBS["검사"]; }
function actorJobMul(actor) { return 1; }
function actorActiveMandalaType(actor) {
  const race = actorRaceDef(actor);
  return race.forceMandala || String(actor?.만다라종류 ?? "없음");
}
function actorActiveEvolutionDef(actor) {
  const raceName = String(actor?.종족 ?? "인간");
  const evo = EVOLUTIONS[raceName];
  if (!evo) return null;
  if (raceName === "용인족") return bool(actor?.특수진화완료) ? evo : null;
  return actorActiveMandalaType(actor) === "진화" && num(actor?.레벨, 1) >= 70 ? evo : null;
}
function actorBaseStatForCalc(actor, stat) {
  let base = num(actor?.[stat], 1);
  const evo = actorActiveEvolutionDef(actor);
  if (evo?.equalizeBase) base = Math.max(...STAT_KEYS.map(s => num(actor?.[s], 1)));
  if (evo?.doubleBaseCon && stat === "체력") base *= 2;
  return base;
}
function actorEvolutionBonus(actor, stat) {
  const evo = actorActiveEvolutionDef(actor);
  if (!evo) return 0;
  let v = num(evo.stats?.[stat], 0);
  if (evo.directStat && String(actor?.직접종족보정스탯 ?? "힘") === stat) v += 10;
  return v;
}
function actorBlessingBonus(actor, stat) {
  if (String(actor?.종족 ?? "") !== "천사") return 0;
  return Math.max(0, num(actor?.축복스택, 0));
}
function actorAutoRaceBonus(actor, stat) {
  const r = actorRaceDef(actor);
  let v = num(r.stats?.[stat], 0);
  const direct = String(actor?.직접종족보정스탯 ?? "힘");
  if (r.directStat && direct === stat) v += 10;
  if (r.slimeTransfer && stat === "민첩") v += num(actor?.외모, 1);
  if (r.cyborgSplit && CORE_STAT_KEYS.includes(stat)) v += Math.floor(num(actor?.외모, 1) / 5);
  v += actorEvolutionBonus(actor, stat);
  v += actorBlessingBonus(actor, stat);
  return v;
}
function actorAutoJobBonus(actor, stat) {
  const j = actorJobDef(actor);
  return num(j.stats?.[stat], 0) * actorJobMul(actor);
}
function actorActiveEffectStatBonus(actor, stat) {
  return arr(actor?.지속효과).reduce((sum, e) => {
    if (!e || (e.대상 && e.대상 !== "self")) return sum;
    return sum + num(e?.스탯변화?.[stat], 0);
  }, 0);
}
function actorActiveEffectExtraBonuses(actor) {
  const out = { maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0 };
  for (const e of arr(actor?.지속효과)) {
    if (!e || (e.대상 && e.대상 !== "self")) continue;
    const b = e.수치보정 ?? e.보정 ?? {};
    out.maxHP += num(b.maxHP ?? b.최대HP, 0);
    out.physical += num(b.physical ?? b.물리공격력, 0);
    out.mental += num(b.mental ?? b.정신공격력 ?? b.마법공격력, 0);
    out.reduction += num(b.reduction ?? b.피해감소, 0);
    out.difficulty += num(b.difficulty ?? b.판정난이도, 0);
  }
  return out;
}
function actorManualBonus(actor, stat) {
  return num(actor?.[`${stat}아이템`], 0) + num(actor?.[`${stat}스킬`], 0) + num(actor?.[`${stat}임시`], 0) + num(actorEquipmentBonuses(actor).stats?.[stat], 0) + actorActiveEffectStatBonus(actor, stat);
}
function actorRemovedStats(actor) {
  const set = new Set(arr(actor?.수동제거스탯 ?? actor?.제거스탯).filter(x => STAT_KEYS.includes(x)));
  for (const s of (actorRaceDef(actor).remove ?? [])) set.add(s);
  return Array.from(set);
}
function actorIsRemoved(actor, stat) {
  return actorRemovedStats(actor).includes(stat);
}
function actorYongrinActive(actor) {
  return bool(actor?.용린사용중) || arr(actor?.지속효과).some(e => (e?.이름 ?? e?.name) === "용린");
}
function actorRawEffectiveWithoutBerserk(actor, stat) {
  if (actorIsRemoved(actor, stat)) return null;
  return Math.max(1, actorBaseStatForCalc(actor, stat) + actorAutoRaceBonus(actor, stat) + actorAutoJobBonus(actor, stat) + actorManualBonus(actor, stat));
}
function actorBerserkerPowerBonus(actor) {
  if (!actorJobDef(actor).berserker) return 0;
  const baseCon = actorRawEffectiveWithoutBerserk(actor, "체력") ?? 1;
  const tempMaxHP = Math.max(1, baseCon * 10 + num(actor?.최대HP보정, 0) + num(actorEquipmentBonuses(actor).maxHP,0));
  const currentHP = clamp(num(actor?.현재HP, tempMaxHP), 0, tempMaxHP);
  const missing = Math.max(0, tempMaxHP - currentHP);
  return Math.floor(missing / 10);
}
function actorEffectiveStat(actor, stat) {
  if (!actor || actorIsRemoved(actor, stat)) return null;
  let value = actorRawEffectiveWithoutBerserk(actor, stat);
  if (value === null) return null;
  if (stat === "힘") value += actorBerserkerPowerBonus(actor);
  if (stat === "민첩" && actorYongrinActive(actor)) value = Math.max(1, Math.floor(value / 2));
  return Math.max(1, value);
}
function targetStatSummaryHTML(value) {
  const target = targetLiveDataByValue(value);
  if (!target) return `<div class="nrpg-empty">상대를 선택하면 스탯이 여기에 표시됩니다.</div>`;
  return `<div class="nrpg-stat-mini">${STAT_KEYS.map(s => {
    const v = actorEffectiveStat(target, s);
    return `<span>${esc(s)} <b>${v === null ? "제거" : esc(v)}</b></span>`;
  }).join("")}</div>`;
}
function effectHTML() {
  if (!state.지속효과.length) return `<div class="nrpg-empty">적용 중인 지속효과 없음</div>`;
  return state.지속효과.map((e, i) => {
    const turns = num(e.남은턴, 1);
    return `<div class="nrpg-list"><div><b>${esc(e.이름 ?? "효과")}</b><span>${esc(e.분류 ?? "효과")} / 대상: ${esc(e.대상이름 ?? e.대상 ?? "미지정")} / 남은 턴: ${turns}<br>${esc(e.효과 ?? "")}</span></div><button data-action="deleteEffect" data-index="${i}">해제</button></div>`;
  }).join("");
}
function effectLogHTML() {
  return `<div class="nrpg-empty">효과 로그는 저장하지 않습니다.</div>`;
}
function diceClass() {
  const t = String(state.다이스결과타입 || "대기");
  if (t.includes("대성공")) return "crit";
  if (t.includes("대실패")) return "fumble";
  if (t.includes("성공")) return "success";
  if (t.includes("실패")) return "fail";
  return "idle";
}
function dicePanelHTML() {
  const cls = diceClass();
  const icon = cls === "crit" ? "✦ 대성공 ✦" : cls === "fumble" ? "☄ 대실패 ☄" : cls === "success" ? "◆ 성공 ◆" : cls === "fail" ? "◇ 실패 ◇" : "✧ 대기 ✧";
  const left = cls === "fumble" ? "☠" : cls === "fail" ? "◇" : cls === "success" ? "◆" : "✦";
  const right = cls === "fumble" ? "☠" : cls === "fail" ? "◇" : cls === "success" ? "◆" : "✦";
  return `<div id="nrpgDicePanel" class="nrpg-dice ${cls}"><div id="nrpgDiceBanner" class="nrpg-dice-banner">${icon}</div><div class="nrpg-dice-core"><span id="nrpgDiceLeft">${left}</span><b id="nrpgDiceNumber">${esc(state.다이스표시)}</b><span id="nrpgDiceRight">${right}</span></div><div id="nrpgDiceDetail" class="nrpg-dice-sub">${esc(state.다이스상세)}</div></div>`;
}
function statCoinDicePanelHTML() {
  const meta = diceVisualMeta(state.스탯코인다이스결과타입 || "대기");
  const hasPending = !!state.스탯코인대기스탯 && !!state.스탯코인대기굴림;
  const display = state.스탯코인다이스표시 && state.스탯코인다이스표시 !== "대기"
    ? state.스탯코인다이스표시
    : (hasPending ? String(state.스탯코인대기굴림) : "대기");
  const detail = state.스탯코인다이스상세 && state.스탯코인다이스상세 !== "스탯 코인 굴림 전"
    ? state.스탯코인다이스상세
    : (hasPending ? `${state.스탯코인대기스탯} 대기 굴림 ${state.스탯코인대기굴림}` : "스탯 코인 굴림 전");
  return `<div id="nrpgStatCoinDicePanel" class="nrpg-dice nrpg-statcoin-dice ${meta.cls}"><div id="nrpgStatCoinDiceBanner" class="nrpg-dice-banner">${meta.icon}</div><div class="nrpg-dice-core"><span id="nrpgStatCoinDiceLeft">${meta.left}</span><b id="nrpgStatCoinDiceNumber">${esc(display)}</b><span id="nrpgStatCoinDiceRight">${meta.right}</span></div><div id="nrpgStatCoinDiceDetail" class="nrpg-dice-sub">${esc(detail)}</div></div>`;
}

function setStatCoinDicePanel(display, detail, type = "대기", rolling = false) {
  const panel = root.querySelector("#nrpgStatCoinDicePanel");
  const banner = root.querySelector("#nrpgStatCoinDiceBanner");
  const numEl = root.querySelector("#nrpgStatCoinDiceNumber");
  const detailEl = root.querySelector("#nrpgStatCoinDiceDetail");
  const leftEl = root.querySelector("#nrpgStatCoinDiceLeft");
  const rightEl = root.querySelector("#nrpgStatCoinDiceRight");
  if (!panel || !numEl || !detailEl) return false;
  const meta = diceVisualMeta(type);
  panel.classList.remove("idle", "success", "fail", "crit", "fumble", "rolling", "settled");
  panel.classList.add(meta.cls);
  if (rolling) panel.classList.add("rolling");
  else panel.classList.add("settled");
  if (banner) banner.textContent = rolling ? "✧ 스탯이 구르는 중 ✧" : meta.icon;
  if (leftEl) leftEl.textContent = rolling ? "✧" : meta.left;
  if (rightEl) rightEl.textContent = rolling ? "✧" : meta.right;
  numEl.textContent = String(display ?? "");
  detailEl.textContent = String(detail ?? "");
  return true;
}

function animateStatCoinDiceResult(finalDisplay, detail, type = "대기", sides = 100) {
  if (!NRPG_DICE_ANIMATION) { setStatCoinDicePanel(finalDisplay, detail, type, false); return Promise.resolve(); }
  const ok = setStatCoinDicePanel(randomDiceDisplay(sides, "single"), "스탯 굴리는 중...", "대기", true);
  if (!ok) return Promise.resolve();
  const duration = 1450;
  let start = 0;
  let last = 0;
  return new Promise(resolve => {
    const step = ts => {
      if (!start) start = ts;
      const elapsed = ts - start;
      const progress = Math.min(1, elapsed / duration);
      const easedGap = 24 + Math.floor(progress * progress * 170);
      if (elapsed - last >= easedGap) {
        last = elapsed;
        setStatCoinDicePanel(randomDiceDisplay(sides, "single"), progress > 0.72 ? "스탯이 정해지는 중..." : "스탯 굴리는 중...", "대기", true);
      }
      if (elapsed < duration) requestAnimationFrame(step);
      else {
        setStatCoinDicePanel(finalDisplay, detail, type, false);
        resolve();
      }
    };
    requestAnimationFrame(step);
  });
}

let statCoinDiceRollingLock = false;
async function rollStatCoinAndSave({ finalDisplay, detail, type = "대기", sides = 100, patch = {} }) {
  if (statCoinDiceRollingLock) return;
  statCoinDiceRollingLock = true;
  try {
    await animateStatCoinDiceResult(finalDisplay, detail, type, sides);
    await save(withLog(detail, {
      ...patch,
      스탯코인다이스표시: String(finalDisplay),
      스탯코인다이스상세: detail,
      스탯코인다이스결과타입: type
    }));
  } finally {
    statCoinDiceRollingLock = false;
  }
}

function opposedDiceClass(side) {
  const t = String(state.상대다이스결과타입 || "대기");
  if (t.includes("승리")) return side === "my" ? "win" : "lose";
  if (t.includes("패배")) return side === "my" ? "lose" : "win";
  return "";
}
function opposedDicePanelHTML() {
  return `<div id="nrpgOpposedDice" class="nrpg-opposed-dice">
    <div id="nrpgOpposedMyBox" class="nrpg-od-box my ${opposedDiceClass("my")}">
      <div id="nrpgOpposedMyTitle" class="nrpg-od-title">내 주사위</div>
      <div id="nrpgOpposedMyNum" class="nrpg-od-num">${esc(state.상대다이스내표시)}</div>
      <div id="nrpgOpposedMySub" class="nrpg-od-sub">플레이어</div>
    </div>
    <div id="nrpgOpposedEnemyBox" class="nrpg-od-box enemy ${opposedDiceClass("enemy")}">
      <div id="nrpgOpposedEnemyTitle" class="nrpg-od-title">상대 주사위</div>
      <div id="nrpgOpposedEnemyNum" class="nrpg-od-num">${esc(state.상대다이스상대표시)}</div>
      <div id="nrpgOpposedEnemySub" class="nrpg-od-sub">NPC</div>
    </div>
    <div id="nrpgOpposedDetail" class="nrpg-opposed-detail">${esc(state.상대다이스상세)}</div>
  </div>`;
}
function setOpposedDicePanel(myDisplay, enemyDisplay, detail, type = "대기", rolling = false, myLabel = "내 주사위", enemyLabel = "상대 주사위") {
  const myBox = root.querySelector("#nrpgOpposedMyBox");
  const enemyBox = root.querySelector("#nrpgOpposedEnemyBox");
  const myNum = root.querySelector("#nrpgOpposedMyNum");
  const enemyNum = root.querySelector("#nrpgOpposedEnemyNum");
  const detailEl = root.querySelector("#nrpgOpposedDetail");
  const myTitle = root.querySelector("#nrpgOpposedMyTitle");
  const enemyTitle = root.querySelector("#nrpgOpposedEnemyTitle");
  if (!myBox || !enemyBox || !myNum || !enemyNum || !detailEl) return false;
  myBox.classList.remove("rolling", "settled", "win", "lose");
  enemyBox.classList.remove("rolling", "settled", "win", "lose");
  if (rolling) {
    myBox.classList.add("rolling");
    enemyBox.classList.add("rolling");
  } else {
    myBox.classList.add("settled");
    enemyBox.classList.add("settled");
    if (String(type).includes("승리")) { myBox.classList.add("win"); enemyBox.classList.add("lose"); }
    else if (String(type).includes("패배")) { myBox.classList.add("lose"); enemyBox.classList.add("win"); }
  }
  if (myTitle) myTitle.textContent = myLabel;
  if (enemyTitle) enemyTitle.textContent = enemyLabel;
  myNum.textContent = String(myDisplay ?? "");
  enemyNum.textContent = String(enemyDisplay ?? "");
  detailEl.textContent = String(detail ?? "");
  return true;
}
function animateOpposedDiceResult(myFinal, enemyFinal, detail, type, mySides, enemySides, myLabel, enemyLabel) {
  if (!NRPG_DICE_ANIMATION) { setOpposedDicePanel(myFinal, enemyFinal, detail, type, false, myLabel, enemyLabel); return Promise.resolve(); }
  const ok = setOpposedDicePanel(dice(mySides), dice(enemySides), "서로의 운명이 동시에 구르는 중...", "대기", true, myLabel, enemyLabel);
  if (!ok) return Promise.resolve();
  const duration = 980;
  const frameGap = 42;
  let start = 0;
  let last = 0;
  return new Promise(resolve => {
    const step = ts => {
      if (!start) start = ts;
      const elapsed = ts - start;
      if (elapsed - last >= frameGap) {
        last = elapsed;
        setOpposedDicePanel(dice(mySides), dice(enemySides), "서로의 운명이 동시에 구르는 중...", "대기", true, myLabel, enemyLabel);
      }
      if (elapsed < duration) requestAnimationFrame(step);
      else {
        setOpposedDicePanel(myFinal, enemyFinal, detail, type, false, myLabel, enemyLabel);
        resolve();
      }
    };
    requestAnimationFrame(step);
  });
}
async function rollOpposedAndSave({ myFinal, enemyFinal, detail, type, mySides, enemySides, myLabel, enemyLabel, patch = {} }) {
  if (diceRollingLock) return;
  diceRollingLock = true;
  try {
    await animateOpposedDiceResult(myFinal, enemyFinal, detail, type, mySides, enemySides, myLabel, enemyLabel);
    await save(withLog(detail, {
      ...patch,
      다이스표시: `${myFinal} : ${enemyFinal}`,
      다이스상세: detail,
      다이스결과타입: type.includes("승리") ? "성공" : type.includes("패배") ? "실패" : "대기",
      상대다이스내표시: String(myFinal),
      상대다이스상대표시: String(enemyFinal),
      상대다이스상세: detail,
      상대다이스결과타입: type,
    }));
  } finally {
    diceRollingLock = false;
  }
}
function diceVisualMeta(type = "대기") {
  const t = String(type || "대기");
  if (t.includes("대성공")) return { cls: "crit", icon: "✦ 대성공 ✦", left: "✦", right: "✦" };
  if (t.includes("대실패")) return { cls: "fumble", icon: "☄ 대실패 ☄", left: "☠", right: "☠" };
  if (t.includes("성공")) return { cls: "success", icon: "◆ 성공 ◆", left: "◆", right: "◆" };
  if (t.includes("실패")) return { cls: "fail", icon: "◇ 실패 ◇", left: "◇", right: "◇" };
  return { cls: "idle", icon: "✧ 굴리는 중 ✧", left: "✧", right: "✧" };
}
function setDicePanel(display, detail, type = "대기", rolling = false) {
  const panel = root.querySelector("#nrpgDicePanel");
  const banner = root.querySelector("#nrpgDiceBanner");
  const numEl = root.querySelector("#nrpgDiceNumber");
  const detailEl = root.querySelector("#nrpgDiceDetail");
  const leftEl = root.querySelector("#nrpgDiceLeft");
  const rightEl = root.querySelector("#nrpgDiceRight");
  if (!panel || !numEl || !detailEl) return false;
  const meta = diceVisualMeta(type);
  panel.classList.remove("idle", "success", "fail", "crit", "fumble", "rolling", "settled");
  panel.classList.add(meta.cls);
  if (rolling) panel.classList.add("rolling");
  else panel.classList.add("settled");
  if (banner) banner.textContent = rolling ? "✧ 운명이 구르는 중 ✧" : meta.icon;
  if (leftEl) leftEl.textContent = rolling ? "✧" : meta.left;
  if (rightEl) rightEl.textContent = rolling ? "✧" : meta.right;
  numEl.textContent = String(display ?? "");
  detailEl.textContent = String(detail ?? "");
  return true;
}
function randomDiceDisplay(sides = 100, pattern = "single") {
  if (pattern === "opposed" && Array.isArray(sides)) return `${dice(sides[0] ?? 100)} : ${dice(sides[1] ?? 100)}`;
  if (pattern === "text") {
    const marks = ["✦", "◆", "◇", "☄", "?", "!"];
    return marks[Math.floor(Math.random() * marks.length)];
  }
  return String(dice(Array.isArray(sides) ? sides[0] : sides));
}
function animateDiceResult(finalDisplay, detail, type = "대기", sides = 100, pattern = "single") {
  if (!NRPG_DICE_ANIMATION) { setDicePanel(finalDisplay, detail, type, false); return Promise.resolve(); }
  const ok = setDicePanel(randomDiceDisplay(sides, pattern), "굴리는 중...", "대기", true);
  if (!ok) return Promise.resolve();
  const duration = 1450;
  let start = 0;
  let last = 0;
  return new Promise(resolve => {
    const step = ts => {
      if (!start) start = ts;
      const elapsed = ts - start;
      const progress = Math.min(1, elapsed / duration);
      // 초반에는 빠르게, 후반에는 점점 느리게 굴러가도록 간격을 늘린다.
      const easedGap = 24 + Math.floor(progress * progress * 170);
      if (elapsed - last >= easedGap) {
        last = elapsed;
        setDicePanel(randomDiceDisplay(sides, pattern), progress > 0.72 ? "운명이 굳어지는 중..." : "굴리는 중...", "대기", true);
      }
      if (elapsed < duration) requestAnimationFrame(step);
      else {
        setDicePanel(finalDisplay, detail, type, false);
        resolve();
      }
    };
    requestAnimationFrame(step);
  });
}
let diceRollingLock = false;
async function rollAndSave({ finalDisplay, detail, type = "대기", sides = 100, pattern = "single", patch = {} }) {
  if (diceRollingLock) return;
  diceRollingLock = true;
  try {
    await animateDiceResult(finalDisplay, detail, type, sides, pattern);
    await save(withLog(detail, { ...patch, 다이스표시: String(finalDisplay), 다이스상세: detail, 다이스결과타입: type }));
  } finally {
    diceRollingLock = false;
  }
}
function detailKey(detail, index) {
  const summary = detail.querySelector("summary")?.textContent?.trim() ?? `section-${index}`;
  const path = dv.current()?.file?.path ?? "current-file";
  return `nrpg-open-state-v0.2.7:${path}:${index}:${summary}`;
}
function setupDetailPersistence() {
  root.querySelectorAll("details.nrpg-section").forEach((detail, index) => {
    const key = detailKey(detail, index);
    const saved = localStorage.getItem(key);
    if (saved !== null) detail.open = saved === "1";
    detail.addEventListener("toggle", () => {
      localStorage.setItem(key, detail.open ? "1" : "0");
    });
  });
}
function oneTurnResetPatch() {
  const reset = {};
  for (const s of STAT_KEYS) reset[`${s}임시`] = 0;
  const expired = [];
  const kept = [];
  for (const e of state.지속효과) {
    const turns = Math.max(1, num(e.남은턴, 1));
    if (turns <= 1 || e.한턴 === true) expired.push(e);
    else kept.push({ ...e, 남은턴: turns - 1 });
  }
  const names = expired.map(e => `${e.이름 ?? '효과'}(${e.대상이름 ?? e.대상 ?? '대상'})`).join(', ');
  const extra = {};
  const extraLogs = [];
  if (expired.some(e => (e?.이름 ?? e?.name) === '용린')) extra.용린사용중 = false;
  const dragonOver = expired.find(e => (e?.이름 ?? e?.name) === '강제 용족화');
  if (dragonOver?.반동) {
    const nextStats = {};
    for (const s of STAT_KEYS) {
      const before = num(state[s], 1);
      const delta = num(dragonOver.반동?.[s], 0);
      nextStats[s] = clamp(before + delta, 1, baseStatMax());
      if (delta) extraLogs.push(`강제 용족화 반동 ${s} ${before} → ${nextStats[s]}`);
    }
    Object.assign(extra, nextStats);
    const allOne = STAT_KEYS.every(s => num(nextStats[s], num(state[s],1)) <= 1);
    if (allOne) {
      extra.특수진화완료 = true;
      extraLogs.push('모든 기본 스탯이 1이 되어 완전 용족화 발동');
    }
  }
  const evo = activeEvolutionDef();
  if (evo?.turnHealPercent) {
    const tempState = { ...state, ...extra };
    const effCon = actorEffectiveStat(tempState, '체력') ?? 1;
    const maxHp = Math.max(1, effCon * 10 + num(tempState.최대HP보정,0) + num(equipmentBonuses().maxHP,0));
    const heal = Math.max(1, Math.floor(maxHp * evo.turnHealPercent / 100));
    const baseHp = num(extra.현재HP, state.현재HP);
    const nextHP = clamp(baseHp + heal, 0, maxHp);
    extra.현재HP = nextHP;
    extraLogs.push(`진조 회복 ${heal}: HP ${baseHp} → ${nextHP}`);
  }
  const logLine = `${nowText()} · 턴 ${state.턴} 종료: ${expired.length ? names : '만료 효과 없음'} / 임시 스탯 보정 초기화${extraLogs.length ? ' / ' + extraLogs.join(' / ') : ''}`;
  return {
    ...reset,
    ...extra,
    턴: state.턴 + 1,
    지속효과: kept,
    효과로그: [...arr(state.효과로그), logLine].slice(-30),
  };
}
function addActiveEffect(name, kind, targetValue, effect, turns = 1) {
  const targetName = targetNameByValue(targetValue);
  const obj = { 이름: name, 분류: kind, 대상: targetValue, 대상이름: targetName, 효과: effect, 남은턴: Math.max(1, num(turns, 1)), 한턴: Math.max(1, num(turns, 1)) === 1, 시작턴: state.턴 };
  const logLine = `${nowText()} · ${kind} 효과 적용: ${name} → ${targetName} / ${obj.남은턴}턴`;
  return { 지속효과: [...state.지속효과, obj], 효과로그: [...arr(state.효과로그), logLine].slice(-30) };
}
function advancedUsePatch(skill, targetValue = "") {
  const adv = skill?.고급설정;
  if (!adv || adv.사용 !== true) return { patch: {}, logs: [], resultLines: [], targetOps: null };
  const logs = [];
  const resultLines = [];
  const patch = {};
  const nextSkill = JSON.parse(JSON.stringify(skill));
  const nextAdv = nextSkill.고급설정;
  const targetOps = { apply: false, statMap: null, bonusMap: null, heal: null, damage: null, damageKind: "고정", statuses: [], coin: null, effectName: "", turns: 1 };

  if (nextAdv?.스택?.이름) {
    const before = Math.max(0, num(nextAdv.스택.현재, nextAdv.스택.시작 ?? 0));
    const deltaRoll = parseDiceFormula(nextAdv.스택.사용시변화 ?? 0);
    const delta = deltaRoll.ok ? deltaRoll.total : 0;
    const max = Math.max(0, num(nextAdv.스택.최대, 0));
    let after = before + delta;
    if (max > 0) after = Math.min(max, after);
    after = Math.max(0, after);
    nextAdv.스택.현재 = after;
    const deltaText = deltaRoll.formula && deltaRoll.formula !== String(delta) ? ` (${deltaRoll.detail})` : "";
    logs.push(`${nextAdv.스택.이름} 스택 ${before} → ${after}${deltaText}`);
    resultLines.push(`개인 스택: ${nextAdv.스택.이름} ${before} → ${after}`);
    const step = arr(nextAdv.스택단계효과).find(x => num(x.단계, -999) === after);
    if (step?.효과) {
      logs.push(`현재 스택 효과: ${step.효과}`);
      resultLines.push(`스택 ${after} 효과: ${step.효과}`);
    }
  }

  const auto = nextAdv?.자동효과 ?? {};
  const autoTarget = String(auto.대상 ?? "self");
  const turns = Math.max(1, num(auto.지속턴, skill?.지속턴 ?? 1));
  const effectName = String(auto.지속효과명 ?? "").trim() || (skill?.이름 ?? "스킬 효과");
  const statParsed = parseStatChangeMap(auto.임시스탯);
  const bonusParsed = parseExtraBonusMap(auto.수치보정);
  const affectsSelf = autoTarget === "self" || autoTarget === "both" || !targetValue || targetValue === "self";
  const affectsTarget = (autoTarget === "target" || autoTarget === "both") && targetValue && targetValue !== "self";

  if ((statParsed.has || bonusParsed.has) && affectsSelf) {
    const obj = {
      이름: effectName,
      분류: "자동효과",
      대상: "self",
      대상이름: state.이름,
      효과: activeEffectTextFromMaps(statParsed.map, bonusParsed.map),
      남은턴: turns,
      한턴: turns === 1,
      시작턴: state.턴,
      스탯변화: statParsed.map,
      수치보정: bonusParsed.map,
    };
    patch.지속효과 = [...arr(patch.지속효과 ?? state.지속효과), obj];
    const line = `${nowText()} · 자동효과 적용: ${effectName} / ${obj.효과} / ${turns}턴`;
    patch.효과로그 = [...arr(patch.효과로그 ?? state.효과로그), line].slice(-30);
    logs.push(`자신 자동효과: ${obj.효과} / ${turns}턴`);
    resultLines.push(`자신 자동효과: ${obj.효과} / ${turns}턴`);
  }

  if ((statParsed.has || bonusParsed.has) && affectsTarget) {
    targetOps.apply = true;
    targetOps.statMap = statParsed.map;
    targetOps.bonusMap = bonusParsed.map;
    targetOps.effectName = effectName;
    targetOps.turns = turns;
  }

  const healText = String(auto.회복량 ?? "").trim();
  if (healText) {
    const heal = hpValueFromFormula(healText, calc().maxHP);
    if (heal.ok) {
      if (affectsSelf) {
        const before = num(patch.현재HP, state.현재HP);
        const after = clamp(before + heal.total, 0, calc().maxHP);
        patch.현재HP = after;
        logs.push(`자신 회복 ${heal.detail}: HP ${before} → ${after}`);
        resultLines.push(`자신 회복: ${heal.detail} / HP ${before} → ${after}`);
      }
      if (affectsTarget) { targetOps.apply = true; targetOps.heal = heal.total; }
    } else { logs.push(`회복량 해석 실패: ${heal.detail}`); resultLines.push(`회복량 해석 실패: ${heal.detail}`); }
  }

  const dmgText = String(auto.피해량 ?? "").trim();
  if (dmgText) {
    const dmg = hpValueFromFormula(dmgText, calc().maxHP);
    const dmgKind = String(auto.피해종류 ?? "고정");
    if (dmg.ok) {
      if (affectsSelf) {
        const before = num(patch.현재HP, state.현재HP);
        const after = clamp(before - Math.max(0, dmg.total), 0, calc().maxHP);
        patch.현재HP = after;
        logs.push(`자신 ${dmgKind} 피해 ${dmg.detail}: HP ${before} → ${after}`);
        resultLines.push(`자신 ${dmgKind} 피해: ${dmg.detail} / HP ${before} → ${after}`);
      }
      if (affectsTarget) { targetOps.apply = true; targetOps.damage = Math.max(0, dmg.total); targetOps.damageKind = dmgKind; }
    } else { logs.push(`피해량 해석 실패: ${dmg.detail}`); resultLines.push(`피해량 해석 실패: ${dmg.detail}`); }
  }

  const statusList = splitEffectLines(auto.상태부여);
  if (statusList.length) {
    if (affectsSelf) {
      patch.상태이상 = Array.from(new Set([...arr(patch.상태이상 ?? state.상태이상), ...statusList]));
      logs.push(`자신 상태 부여: ${statusList.join(", ")}`);
      resultLines.push(`자신 상태 부여: ${statusList.join(", ")}`);
    }
    if (affectsTarget) { targetOps.apply = true; targetOps.statuses = statusList; }
  }

  const coinText = String(auto.코인변화 ?? "").trim();
  if (coinText) {
    const coin = parseDiceFormula(coinText);
    if (coin.ok) {
      if (affectsSelf) {
        const before = num(patch.코인, state.코인);
        const after = Math.max(0, before + coin.total);
        patch.코인 = after;
        logs.push(`자신 코인 ${before} → ${after} (${coin.detail})`);
        resultLines.push(`자신 코인 변화: ${before} → ${after}`);
      }
      if (affectsTarget) { targetOps.apply = true; targetOps.coin = coin.total; }
    } else { logs.push(`코인 변화 해석 실패: ${coin.detail}`); resultLines.push(`코인 변화 해석 실패: ${coin.detail}`); }
  }

  if (String(nextAdv?.결과굴림식 ?? "").trim()) {
    const roll = parseDiceFormula(nextAdv.결과굴림식);
    if (roll.ok) {
      const effect = tableEffectByRoll(nextAdv.결과표, roll.total);
      logs.push(`결과 굴림 ${roll.detail}${effect ? ` / 결과 효과: ${effect}` : ""}`);
      resultLines.push(`결과 굴림: ${roll.detail}`);
      if (effect) resultLines.push(`결과 효과: ${effect}`);
    } else {
      logs.push(roll.detail);
      resultLines.push(roll.detail);
    }
  }
  const perm = nextAdv?.영구스탯변화;
  const permFormula = String(perm?.수치 ?? "").trim();
  if (perm?.사용시자동적용 && perm?.스탯 && permFormula && STAT_KEYS.includes(perm.스탯)) {
    const change = parseDiceFormula(permFormula);
    if (change.ok) {
      const before = num(state[perm.스탯], 1);
      const after = clamp(before + change.total, 1, baseStatMax());
      patch[perm.스탯] = after;
      logs.push(`영구 ${perm.스탯} ${before} → ${after} (${permFormula}${permFormula !== change.detail ? ` / ${change.detail}` : ""})`);
      resultLines.push(`영구 ${perm.스탯} 변화: ${before} → ${after}`);
    } else {
      logs.push(`영구 스탯 변화 실패: ${change.detail}`);
      resultLines.push(`영구 스탯 변화 실패: ${change.detail}`);
    }
  }
  if (nextAdv?.리스크) {
    logs.push(`리스크: ${nextAdv.리스크}`);
    resultLines.push(`리스크: ${nextAdv.리스크}`);
  }
  if (nextAdv?.GM메모) {
    logs.push(`GM 메모: ${nextAdv.GM메모}`);
    resultLines.push(`GM 메모: ${nextAdv.GM메모}`);
  }
  patch.__nextSkill = nextSkill;
  return { patch, logs, resultLines, targetOps: targetOps.apply ? targetOps : null };
}
async function applyAdvancedTargetOps(targetValue, ops) {
  const logs = [];
  const resultLines = [];
  if (!ops || !targetValue || targetValue === "self") return { logs, resultLines };
  const ok = await patchTargetFrontmatter(targetValue, fm => {
    const name = String(fm.이름 ?? targetNameByValue(targetValue) ?? "대상");
    const curEffects = Array.isArray(fm.지속효과) ? fm.지속효과 : [];
    const curStatus = Array.isArray(fm.상태이상) ? fm.상태이상 : [];
    const targetLogs = [];
    if (ops.statMap || ops.bonusMap) {
      const obj = {
        이름: ops.effectName || "외부 자동효과",
        분류: "자동효과",
        대상: "self",
        대상이름: name,
        효과: activeEffectTextFromMaps(ops.statMap, ops.bonusMap),
        남은턴: Math.max(1, num(ops.turns, 1)),
        한턴: Math.max(1, num(ops.turns, 1)) === 1,
        시작턴: num(fm.턴, state.턴),
        스탯변화: ops.statMap ?? statMap(),
        수치보정: ops.bonusMap ?? {},
      };
      fm.지속효과 = [...curEffects, obj];
      targetLogs.push(`외부 자동효과: ${obj.이름} / ${obj.효과} / ${obj.남은턴}턴`);
    }
    const maxHP = Math.max(1, num(fm.최대HP보정, 0) + Math.max(1, num(fm.체력, 1)) * 10 + num(ops.bonusMap?.maxHP, 0));
    if (ops.heal !== null && ops.heal !== undefined) {
      const before = clamp(num(fm.현재HP, maxHP), 0, maxHP);
      const after = clamp(before + Math.max(0, num(ops.heal, 0)), 0, maxHP);
      fm.현재HP = after;
      targetLogs.push(`외부 회복: HP ${before} → ${after}`);
    }
    if (ops.damage !== null && ops.damage !== undefined) {
      const before = clamp(num(fm.현재HP, maxHP), 0, maxHP);
      const after = clamp(before - Math.max(0, num(ops.damage, 0)), 0, maxHP);
      fm.현재HP = after;
      targetLogs.push(`외부 ${ops.damageKind ?? "고정"} 피해: HP ${before} → ${after}`);
    }
    if (ops.statuses?.length) {
      fm.상태이상 = Array.from(new Set([...curStatus, ...ops.statuses]));
      targetLogs.push(`외부 상태 부여: ${ops.statuses.join(", ")}`);
    }
    if (ops.coin !== null && ops.coin !== undefined) {
      const before = num(fm.코인, 0);
      const after = Math.max(0, before + num(ops.coin, 0));
      fm.코인 = after;
      targetLogs.push(`외부 코인 변화: ${before} → ${after}`);
    }
    fm.효과로그 = [];
    logs.push(...targetLogs.map(x => `${name}: ${x}`));
    resultLines.push(...targetLogs.map(x => `대상 ${name}: ${x}`));
  });
  if (!ok) {
    logs.push("대상 자동효과 적용 실패: 대상 문서를 찾지 못함");
    resultLines.push("대상 자동효과 적용 실패: 대상 문서를 찾지 못함");
  }
  return { logs, resultLines };
}

function targetLabel(value) {
  return String(value || "") === "self" ? (state.이름 || "자기 자신") : targetNameByValue(value);
}
function effectMatchesTarget(effect, targetValue) {
  const tv = String(targetValue || "");
  const effectTarget = String(effect?.대상 ?? "");
  const effectName = String(effect?.대상이름 ?? "");
  if (tv === "self") return effectTarget === "self" || effectName === String(state.이름 || "자기 자신");
  return effectTarget === tv || effectName === targetNameByValue(tv);
}
function consumeFairyBlessing(list, targetValue) {
  const src = arr(list);
  const kept = [];
  let used = null;
  for (const effect of src) {
    const name = String(effect?.이름 ?? effect?.name ?? "");
    if (!used && name === "요정의 축복" && effectMatchesTarget(effect, targetValue)) used = effect;
    else kept.push(effect);
  }
  if (!used) return { bonus: 0, effects: src, logLine: "", text: "" };
  const bonus = dice(6);
  const label = targetLabel(targetValue);
  const logLine = `${nowText()} · 요정의 축복 발동: ${label} 다음 판정 +${bonus}`;
  return { bonus, effects: kept, logLine, text: ` / 요정의 축복 +${bonus}` };
}

function consumeFairyCurse(list, targetValue) {
  const src = arr(list);
  const kept = [];
  let used = null;
  for (const effect of src) {
    const name = String(effect?.이름 ?? effect?.name ?? "");
    if (!used && name === "요정의 저주" && effectMatchesTarget(effect, targetValue)) used = effect;
    else kept.push(effect);
  }
  if (!used) return { penalty: 0, effects: src, logLine: "", text: "" };
  const penalty = dice(6);
  const label = targetLabel(targetValue);
  const logLine = `${nowText()} · 요정의 저주 발동: ${label} 다음 판정 -${penalty}`;
  return { penalty, effects: kept, logLine, text: ` / 요정의 저주 -${penalty}` };
}

function sheetItemValue(v, fallback = '') {
  if (v === undefined || v === null || v === '') return fallback;
  if (Array.isArray(v)) return v.map(x => sheetItemValue(x, '')).filter(Boolean).join(', ');
  if (typeof v === 'object') return sheetItemValue(v.path || v.name || v.이름 || v.display || JSON.stringify(v), fallback);
  return String(v);
}
function sheetScenarioFromPath(path) {
  const parts = String(path || '').split('/');
  const idx = parts.indexOf('시나리오');
  return idx >= 0 && parts.length > idx + 1 ? parts[idx + 1] : '';
}
function sheetItemType(page) {
  const raw = sheetItemValue(page?.유형 ?? page?.아이템유형 ?? page?.분류 ?? '아이템', '아이템');
  if (/장비|무기|방어구|갑옷|방패|악세|액세/i.test(raw)) return '장비';
  if (/소모|포션|약|폭탄|스크롤|탄약/i.test(raw)) return '소모품';
  if (/재료|광물|부품/i.test(raw)) return '재료';
  if (/퀘스트|열쇠|증표|단서/i.test(raw)) return '퀘스트';
  return raw || '아이템';
}
function itemCatalogPages(load = false) {
  const scenario = String(state.시나리오 ?? "");
  const cached = readStoredList("item", scenario);
  if (cached.length && !load) return cached.map(recordToPage).filter(Boolean);
  if (!load) return [];
  try {
    const pages = allPagesSearchNow()
      .filter(p => {
        const path = String(p?.file?.path ?? '');
        const parts = path.split('/');
        const kind = sheetItemValue(p?.종류 ?? p?.구분 ?? '');
        if (kind === '아이템목록') return false;
        const isItem = kind === '아이템' || parts.includes('아이템');
        if (!isItem) return false;
        const sc = sheetItemValue(p?.시나리오 ?? '', '') || sheetScenarioFromPath(path);
        return !sc || sc === scenario || scenario === '임시 시나리오';
      })
      .sort((a, b) => `${sheetItemValue(a.시나리오 ?? '', '')}/${sheetItemType(a)}/${sheetItemValue(a.이름 ?? a.file.name, a.file.name)}`.localeCompare(`${sheetItemValue(b.시나리오 ?? '', '')}/${sheetItemType(b)}/${sheetItemValue(b.이름 ?? b.file.name, b.file.name)}`, 'ko'));
    const records = pages.map(pageRecord).filter(r => r.path);
    writeStoredList("item", records, scenario);
    return records.map(recordToPage).filter(Boolean);
  } catch (e) { return []; }
}
function itemCatalogOptions(selected = '') {
  const items = itemCatalogPages(false);
  if (!items.length) return lazyOptionMessage("아이템 목록 불러오기 필요");
  return items.map(p => {
    const path = String(p.file.path);
    const name = sheetItemValue(p.이름 ?? p.file.name, p.file.name);
    const type = sheetItemType(p);
    const grade = sheetItemValue(p.등급 ?? '', '');
    const sc = sheetItemValue(p.시나리오 ?? '', '') || sheetScenarioFromPath(path) || '공용';
    return `<option value="${esc(path)}" ${path === selected ? 'selected' : ''}>${esc(name)} · ${esc(type)}${grade ? ' · ' + esc(grade) : ''} · ${esc(sc)}</option>`;
  }).join('');
}
function itemCatalogByValue(value) {
  const path = String(value || '');
  const fromList = itemCatalogPages(false).find(p => String(p.file.path) === path);
  if (fromList) return fromList;
  const fileObj = path ? app.vault.getAbstractFileByPath(path) : null;
  if (!fileObj) return null;
  const fm = app.metadataCache.getFileCache(fileObj)?.frontmatter ?? {};
  return { ...fm, file: { path: fileObj.path, name: fileObj.basename } };
}
function itemCatalogInventoryEntry(page) {
  if (!page) return '';
  return sheetItemValue(page.아이템등록문자열 ?? page.등록문자열 ?? page.이름 ?? page.file.name, page.file.name);
}
function itemCatalogEquipmentEntry(page) {
  if (!page) return '';
  const name = sheetItemValue(page.이름 ?? page.file.name, page.file.name);
  const grade = sheetItemValue(page.등급 ?? '일반', '일반');
  const price = sheetItemValue(page.가격 ?? 0, '0');
  const effect = sheetItemValue(page.효과 ?? page.사용효과 ?? page.해금효과 ?? '', '');
  return sheetItemValue(page.장비등록문자열 ?? '', '') || `${name}|${grade}|${price}|${effect}`;
}
function addUniqueLine(list, entry) {
  const next = arr(list).map(x => typeof x === 'string' ? x : (x?.이름 ?? x?.name ?? JSON.stringify(x))).filter(Boolean);
  if (entry && !next.includes(entry)) next.push(entry);
  return next;
}

function sheetListEntries(list) {
  return arr(list).map(x => typeof x === 'string' ? x : (x?.이름 ?? x?.name ?? JSON.stringify(x))).filter(Boolean);
}
function equipmentListManageHTML() {
  const list = sheetListEntries(state.장비목록);
  if (!list.length) return `<div class="nrpg-empty">장비목록이 비어 있습니다.</div>`;
  return list.map((raw, i) => {
    const item = normalizeEquipEntry(raw);
    const title = item?.이름 || raw;
    const sub = item ? `${item.등급 || '일반'} / 가격 ${item.가격 || 0}${item.효과 ? ` / ${item.효과}` : ''}` : raw;
    return `<div class="nrpg-list"><div><b>${esc(title)}</b><span>${esc(sub)}</span></div><button data-action="removeEquipmentItem" data-index="${i}" class="danger">장비 제거</button></div>`;
  }).join('');
}
function inventoryListManageHTML() {
  const list = sheetListEntries(state.아이템목록);
  if (!list.length) return `<div class="nrpg-empty">아이템목록이 비어 있습니다.</div>`;
  return list.map((raw, i) => `<div class="nrpg-list"><div><b>${esc(raw)}</b><span>아이템목록 ${i + 1}</span></div><button data-action="removeInventoryItem" data-index="${i}" class="danger">아이템 제거</button></div>`).join('');
}


function parseEffectBonusText(raw) {
  const out = { stats: statMap(), maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0 };
  const text = String(raw ?? "").replaceAll("−", "-");
  const keyMap = { "물리공격력": "physical", "물공": "physical", "정신공격력": "mental", "마법공격력": "mental", "마공": "mental", "피해감소": "reduction", "방어": "reduction", "최대HP": "maxHP", "HP": "maxHP", "판정난이도": "difficulty", "난이도": "difficulty" };
  for (const stat of STAT_KEYS) {
    const re = new RegExp(`${stat}\\s*([+-])\\s*(\\d+)`, "g");
    let m;
    while ((m = re.exec(text)) !== null) out.stats[stat] += (m[1] === "-" ? -1 : 1) * Number(m[2]);
  }
  for (const [label, key] of Object.entries(keyMap)) {
    const re = new RegExp(`${label}\\s*([+-])\\s*(\\d+)`, "g");
    let m;
    while ((m = re.exec(text)) !== null) out[key] += (m[1] === "-" ? -1 : 1) * Number(m[2]);
  }
  return out;
}
function mergeBonusMaps(base, add) {
  for (const s of STAT_KEYS) base.stats[s] += num(add?.stats?.[s], 0);
  base.maxHP += num(add?.maxHP, 0);
  base.physical += num(add?.physical, 0);
  base.mental += num(add?.mental, 0);
  base.reduction += num(add?.reduction, 0);
  base.difficulty += num(add?.difficulty, 0);
  return base;
}
function entryBaseName(raw) {
  if (!raw) return "";
  if (typeof raw === "object") return String(raw.이름 ?? raw.name ?? raw.path ?? "").trim();
  const s = String(raw).trim();
  if (s.includes("|")) return s.split("|")[0].trim();
  if (s.includes("·")) return s.split("·")[0].trim();
  return s.trim();
}
function itemPageName(page) {
  return sheetItemValue(page?.이름 ?? page?.file?.name ?? "", "").trim();
}
function itemPageMatchesEntry(page, raw, mode = "inventory") {
  const name = entryBaseName(raw);
  if (!name || !page) return false;
  const pName = itemPageName(page);
  const inv = sheetItemValue(page.아이템등록문자열 ?? page.등록문자열 ?? "", "");
  const eq = sheetItemValue(page.장비등록문자열 ?? "", "");
  const path = String(page?.file?.path ?? "");
  const rawText = typeof raw === "string" ? raw : JSON.stringify(raw ?? {});
  return name === pName || rawText === inv || rawText === eq || rawText === path || rawText.includes(pName);
}
function ownedItemPages() {
  const key = cacheKey([state.장비목록, state.아이템목록, state.아이템목록캐시, state.아이템목록캐시시나리오]);
  if (__nrpgCache.ownedItemPagesKey === key && __nrpgCache.ownedItemPages) return __nrpgCache.ownedItemPages;
  const pages = itemCatalogPages(false);
  const out = [];
  for (const raw of arr(state.장비목록)) {
    const found = pages.find(p => itemPageMatchesEntry(p, raw, "equipment"));
    if (found) out.push({ page: found, 보유구분: "장비", 원문: raw });
  }
  for (const raw of arr(state.아이템목록)) {
    const found = pages.find(p => itemPageMatchesEntry(p, raw, "inventory"));
    if (found) out.push({ page: found, 보유구분: "아이템", 원문: raw });
  }
  __nrpgCache.ownedItemPagesKey = key;
  __nrpgCache.ownedItemPages = out;
  return out;
}
function ownedItemBonuses() {
  const key = cacheKey([state.장비목록, state.아이템목록, state.아이템목록캐시, state.아이템목록캐시시나리오]);
  if (__nrpgCache.ownedItemBonusesKey === key && __nrpgCache.ownedItemBonuses) return __nrpgCache.ownedItemBonuses;
  const out = { stats: statMap(), maxHP: 0, physical: 0, mental: 0, reduction: 0, difficulty: 0, items: [] };
  for (const rec of ownedItemPages()) {
    const p = rec.page;
    if (!bool(p?.소유효과사용) && String(p?.능력유형 ?? "") !== "소유자동효과") continue;
    const effect = sheetItemValue(p?.소유효과 ?? p?.능력계산식 ?? p?.효과 ?? "", "");
    if (!effect || effect === "없음") continue;
    mergeBonusMaps(out, parseEffectBonusText(effect));
    out.items.push({ 이름: itemPageName(p), 구분: rec.보유구분, 효과: effect });
  }
  __nrpgCache.ownedItemBonusesKey = key;
  __nrpgCache.ownedItemBonuses = out;
  return out;
}
function itemAbilityRecords() {
  return ownedItemPages().map(rec => {
    const p = rec.page;
    const abilityName = sheetItemValue(p?.능력명 ?? p?.능력 ?? "", "");
    const hasAbility = bool(p?.능력보유) || !!abilityName || bool(p?.소유효과사용);
    if (!hasAbility) return null;
    return {
      보유구분: rec.보유구분,
      이름: itemPageName(p),
      능력명: abilityName || (bool(p?.소유효과사용) ? "소유 효과" : "이름 없는 능력"),
      능력유형: sheetItemValue(p?.능력유형 ?? (bool(p?.소유효과사용) ? "소유자동효과" : "기타"), "기타"),
      능력설명: sheetItemValue(p?.능력설명 ?? p?.설명 ?? "", ""),
      발동조건: sheetItemValue(p?.능력발동조건 ?? p?.사용조건 ?? (rec.보유구분 === "장비" ? "장비 중" : "소지 중"), ""),
      소모: sheetItemValue(p?.능력소모 ?? p?.소모자원 ?? "없음", "없음"),
      계산식: sheetItemValue(p?.능력계산식 ?? p?.소유효과 ?? p?.효과 ?? "", ""),
      상한: sheetItemValue(p?.능력상한 ?? "", ""),
      위험: sheetItemValue(p?.능력위험 ?? "", ""),
      실패결과: sheetItemValue(p?.실패결과 ?? "", ""),
    };
  }).filter(Boolean);
}
function ownedItemBonusSummaryText() {
  const b = ownedItemBonuses();
  const bits = [];
  for (const st of STAT_KEYS) if (b.stats[st]) bits.push(`${st} ${b.stats[st] >= 0 ? "+" : ""}${b.stats[st]}`);
  if (b.maxHP) bits.push(`최대HP ${b.maxHP >= 0 ? "+" : ""}${b.maxHP}`);
  if (b.physical) bits.push(`물공 ${b.physical >= 0 ? "+" : ""}${b.physical}`);
  if (b.mental) bits.push(`정신/마법 ${b.mental >= 0 ? "+" : ""}${b.mental}`);
  if (b.reduction) bits.push(`피해감소 ${b.reduction >= 0 ? "+" : ""}${b.reduction}`);
  if (b.difficulty) bits.push(`판정난이도 ${b.difficulty >= 0 ? "+" : ""}${b.difficulty}`);
  return bits.length ? bits.join(" / ") : "소유 자동효과 없음";
}
function itemAbilityHTML() {
  const list = itemAbilityRecords();
  if (!list.length) return `<div class="nrpg-empty">표시할 아이템/장비 능력이 없습니다. 아이템 노트를 불러오고, 노트 frontmatter에 능력보유/능력명/소유효과사용을 입력하세요.</div>`;
  return list.map((a, i) => `<div class="nrpg-list"><div><b>[${esc(a.보유구분)}] ${esc(a.이름)} · ${esc(a.능력명)}</b><span>${esc(a.능력유형)} / 조건: ${esc(a.발동조건)} / 소모: ${esc(a.소모)}<br>${esc(a.능력설명)}${a.계산식 ? `<br>계산식·효과: ${esc(a.계산식)}` : ""}${a.상한 ? `<br>상한: ${esc(a.상한)}` : ""}${a.위험 ? `<br>위험: ${esc(a.위험)}` : ""}${a.실패결과 ? `<br>실패: ${esc(a.실패결과)}` : ""}</span></div><button data-action="useItemAbility" data-index="${i}">능력 확인</button></div>`).join("");
}

function render() {
  resetNrpgCalcCache();
  normalize();
  const d = calc();
  const counts = skillCounts();
  const sug = mandalaSuggestion();
  const raceSkills = addableRaceSkills();
  const jobSkills = addableJobSkills();
  const defaultTargetValue = String(targetPages(false)[0]?.file?.path ?? "");
  root.innerHTML = `
<style>
.nrpg-root{--bg:#151515;--panel:#202020;--panel2:#2b2b2b;--line:#444;--text:#f1f1f1;--muted:#b8b8b8;background:var(--bg);color:var(--text);border:1px solid var(--line);border-radius:16px;padding:14px;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;line-height:1.45}.nrpg-root *{box-sizing:border-box}.nrpg-root input,.nrpg-root select,.nrpg-root textarea{width:100%;background:#101010;color:var(--text);border:1px solid var(--line);border-radius:9px;padding:8px;font-size:14px}.nrpg-root label span{display:block;color:var(--muted);font-size:12px;margin-bottom:4px}.nrpg-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.nrpg-grid2{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.nrpg-grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.nrpg-card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px;min-height:70px}.nrpg-card div{color:var(--muted);font-size:12px}.nrpg-card b{display:block;font-size:22px;margin-top:3px}.nrpg-card span{display:block;color:var(--muted);font-size:12px;margin-top:4px}.nrpg-btns{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.nrpg-root button{background:var(--panel2);color:var(--text);border:1px solid #666;border-radius:10px;padding:9px 11px;font-weight:800;cursor:pointer}.nrpg-root button:hover{filter:brightness(1.15)}.nrpg-root button:disabled{opacity:.45;cursor:not-allowed}.nrpg-root button.danger{border-color:#8a4a4a}.nrpg-top{border:1px solid #666;background:#111;border-radius:14px;padding:12px;margin-bottom:12px}.nrpg-section{margin-top:12px;background:#181818;border:1px solid #363636;border-radius:14px;padding:10px;content-visibility:auto;contain-intrinsic-size:420px}.nrpg-section>summary{cursor:pointer;font-size:18px;font-weight:900;padding:5px}.nrpg-table{width:100%;border-collapse:separate;border-spacing:0 6px}.nrpg-table th,.nrpg-table td{padding:4px;text-align:center}.nrpg-table th{color:var(--muted);font-size:12px}.nrpg-table td{background:#1f1f1f}.nrpg-table td:first-child,.nrpg-table th:first-child{text-align:left}.nrpg-table em{color:#ffce73;font-style:normal}.nrpg-bar{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px}.nrpg-bar-top{display:flex;justify-content:space-between;margin-bottom:8px}.nrpg-bar i{display:block;height:12px;background:#111;border-radius:999px;overflow:hidden}.nrpg-bar u{display:block;height:100%;background:#ddd;text-decoration:none}.nrpg-result{background:#101010;border:1px solid #555;border-radius:12px;padding:12px;white-space:pre-wrap;min-height:48px}.nrpg-empty{color:#999;background:#202020;border:1px solid #333;border-radius:10px;padding:10px}.nrpg-list{display:flex;justify-content:space-between;gap:10px;align-items:center;background:#202020;border:1px solid #444;border-radius:12px;padding:9px;margin:6px 0}.nrpg-list span{display:block;color:var(--muted);font-size:13px}.nrpg-pill{display:inline-block;margin:4px}.nrpg-check{display:flex!important;align-items:center;gap:8px;background:#202020;border:1px solid #444;border-radius:10px;padding:10px}.nrpg-check input{width:auto}.nrpg-check span{margin:0!important;color:var(--text)!important}.nrpg-warn{border:1px solid #9b7b35;background:#2b2414;color:#ffe3a0;border-radius:12px;padding:10px;margin:10px 0}.nrpg-log{max-height:190px;overflow:auto;background:#101010;border:1px solid #444;border-radius:12px;padding:10px;color:#ccc;font-size:13px}.nrpg-small{font-size:12px;color:var(--muted)}.nrpg-desc{background:#101010;border:1px solid #333;border-radius:12px;padding:10px;color:#ccc;font-size:13px;margin-top:8px}
.nrpg-advanced{display:none;margin-top:10px;border:1px dashed #666;background:#111;border-radius:12px;padding:10px}.nrpg-advanced.open{display:block}.nrpg-advanced-title{font-weight:900;color:#ffd36a;margin-bottom:8px}.nrpg-danger-zone{border:1px solid #8a4a4a;background:#1b1111;border-radius:14px;padding:12px;margin-top:12px}.nrpg-danger-zone summary{cursor:pointer;color:#ffb7b7;font-weight:900}.nrpg-stack-preview{background:#101010;border:1px solid #333;border-radius:10px;padding:8px;color:#ccc;font-size:12px;margin-top:6px;white-space:pre-wrap}.nrpg-skill-result{background:linear-gradient(135deg,#101820,#221a10);border:1px solid #6b5b2f;border-radius:14px;padding:12px;margin:10px 0;white-space:pre-wrap;line-height:1.55}.nrpg-skill-result b{color:#ffd36a}
.nrpg-dice{position:relative;overflow:hidden;background:radial-gradient(circle at 50% 0%,#3a3320,#101010 55%);border:1px solid #777;border-radius:16px;padding:18px;text-align:center;min-height:118px;box-shadow:0 0 16px rgba(255,255,255,.06) inset;contain:layout paint}.nrpg-dice:before{content:"";position:absolute;inset:-35%;background:conic-gradient(from 0deg,transparent,#ffffff22,transparent,#ffd36a33,transparent);opacity:0;pointer-events:none}.nrpg-dice.rolling:before{opacity:1;animation:nrpgSpin .72s linear}.nrpg-dice-core,.nrpg-dice-sub,.nrpg-dice-banner{position:relative;z-index:1}.nrpg-dice-banner{color:#ffd36a;font-weight:900;letter-spacing:.08em;margin-bottom:6px;text-shadow:0 0 8px rgba(255,211,106,.25)}.nrpg-dice-core{display:flex;align-items:center;justify-content:center;gap:14px}.nrpg-dice-core b{font-size:44px;line-height:1;text-shadow:0 0 12px rgba(255,255,255,.35);font-variant-numeric:tabular-nums}.nrpg-dice.rolling .nrpg-dice-core b{animation:nrpgShake .16s ease-in-out infinite}.nrpg-dice.settled .nrpg-dice-core b{animation:nrpgPop .28s ease}.nrpg-dice-core span{color:#ffd36a}.nrpg-dice.rolling .nrpg-dice-core span{animation:nrpgTwinkle .45s ease-in-out infinite}.nrpg-dice-sub{margin-top:10px;color:#ddd;white-space:pre-wrap}.nrpg-dice.success{border-color:#6fae7a}.nrpg-dice.fail{border-color:#a75c5c}.nrpg-dice.crit{border-color:#ffd36a;box-shadow:0 0 20px rgba(255,211,106,.18)}.nrpg-dice.fumble{border-color:#ff6b6b;box-shadow:0 0 20px rgba(255,80,80,.18)}.nrpg-statcoin-dice{min-height:92px;padding:12px}.nrpg-statcoin-dice .nrpg-dice-banner{font-size:12px;margin-bottom:4px}.nrpg-statcoin-dice .nrpg-dice-core b{font-size:34px}.nrpg-statcoin-dice .nrpg-dice-sub{font-size:12px;margin-top:6px}.nrpg-statcoin-dice.rolling{box-shadow:0 0 16px rgba(255,211,106,.16),0 0 16px rgba(255,255,255,.06) inset}@keyframes nrpgSpin{to{transform:rotate(360deg)}}@keyframes nrpgPop{0%{transform:scale(.72);opacity:.4}70%{transform:scale(1.08);opacity:1}100%{transform:scale(1)}}@keyframes nrpgShake{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}@keyframes nrpgTwinkle{0%,100%{opacity:.5;transform:scale(.95)}50%{opacity:1;transform:scale(1.12)}}
@media(max-width:760px){.nrpg-grid,.nrpg-grid2,.nrpg-grid3{grid-template-columns:1fr}.nrpg-table{font-size:12px}.nrpg-table input{padding:6px}}

.nrpg-opposed-dice{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px}
.nrpg-od-box{position:relative;overflow:hidden;background:linear-gradient(160deg,#202020,#0d0d0d);border:1px solid #666;border-radius:14px;padding:14px;text-align:center;min-height:112px;contain:layout paint}
.nrpg-od-box.my{border-color:#7f9cff}.nrpg-od-box.enemy{border-color:#ff8a7a}
.nrpg-od-title{font-size:13px;color:#bbb;font-weight:900;letter-spacing:.04em;margin-bottom:8px}
.nrpg-od-num{font-size:40px;font-weight:950;line-height:1;font-variant-numeric:tabular-nums;text-shadow:0 0 12px rgba(255,255,255,.25)}
.nrpg-od-sub{margin-top:8px;color:#ccc;font-size:13px;white-space:pre-wrap}
.nrpg-od-box.rolling .nrpg-od-num{animation:nrpgShake .14s ease-in-out infinite}
.nrpg-od-box.settled .nrpg-od-num{animation:nrpgPop .25s ease}
.nrpg-od-box.win{box-shadow:0 0 18px rgba(112,174,122,.22);border-color:#6fae7a}
.nrpg-od-box.lose{box-shadow:0 0 18px rgba(167,92,92,.18);border-color:#a75c5c}
.nrpg-opposed-detail{grid-column:1 / -1;background:#111;border:1px solid #555;border-radius:12px;padding:10px;color:#ddd;white-space:pre-wrap}
.nrpg-stat-mini{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.nrpg-stat-mini span{background:#161616;border:1px solid #444;border-radius:10px;padding:8px;font-size:13px;color:#bbb}.nrpg-stat-mini b{display:block;color:#fff;font-size:16px;margin-top:2px}
@media(max-width:720px){.nrpg-opposed-dice{grid-template-columns:1fr}.nrpg-stat-mini{grid-template-columns:repeat(2,1fr)}}

</style>

<div class="nrpg-top">
  <h2 style="margin:0 0 8px 0">빠른 수정 패널</h2>
  ${warningsHTML()}
  <div class="nrpg-grid">
    ${fmInput("이름", "이름")}
    ${fmInput("레벨", "레벨", "number")}
    ${fmInput("경험치", "경험치", "number")}
    ${fmInput("스탯 코인", "스탯코인", "number")}
    ${fmInput("코인", "코인", "number")}
    <label><span>시트지속성</span><select data-fm="시트지속성">${selectOptions(SHEET_ATTRS, state.시트지속성)}</select></label>
    <label><span>시나리오</span><select data-fm="시나리오">${scenarioOptions()}</select></label>
    <label><span>종족</span><select data-fm="종족">${selectOptions(Object.keys(RACES), state.종족)}</select></label>
    <label><span>직접 제작형 종족 보정 스탯</span><select data-fm="직접종족보정스탯">${selectOptions(STAT_KEYS, state.직접종족보정스탯)}</select></label>
    <label><span>직업</span><select data-fm="직업">${selectOptions(Object.keys(JOBS), state.직업)}</select></label>
    ${fmInput("현재 HP", "현재HP", "number")}
  </div>
  <div class="nrpg-grid2" style="margin-top:8px">
    ${fmInput("메모", "메모")}
    <div class="nrpg-desc">만트라는 제거되었습니다. 캐릭터 정체성은 종족과 직업으로 유지하고, 전투·탐색 능력은 종족/직업 스킬과 아이템 능력으로 처리합니다.</div>
  </div>
  <div class="nrpg-btns">
    <button data-action="saveTop">상단 수정사항 저장</button>
    <button data-action="loadScenarioList">시나리오 목록 불러오기</button>
    <button data-action="loadNpcList">NPC 목록 불러오기</button>
    <button data-action="refreshItemCatalog">아이템 목록 불러오기</button>
    <button data-action="refreshRender">화면 새로고침</button>
    <button data-action="levelUp">레벨 +1</button>
    <button data-action="levelDown">레벨 -1</button>
    <button data-action="fullHeal">HP 최대 회복</button>
    <button data-action="endTurn">턴 넘기기</button>
  </div>
  <div class="nrpg-grid" style="margin-top:8px">
    <label><span>피해량</span><input id="hpDamageAmount" type="number" min="0" value="0" placeholder="받은 피해량"></label>
    <label><span>피해 종류</span><select id="hpDamageType"><option value="물리">물리</option><option value="마법">마법</option><option value="고정">고정</option><option value="순수">순수</option></select></label>
    <button data-action="applyDamage">피해 자동 적용</button>
    <div class="nrpg-card"><div>현재 HP</div><b>${state.현재HP} / ${d.maxHP}</b><span>피해 배율·감소 자동 계산</span></div>
  </div>
  <div class="nrpg-skill-result"><b>피해 결과</b>
${esc(state.피해결과)}</div>
  <div class="nrpg-desc"><b>종족 효과</b>: ${esc(raceDef().desc)}<br><b>직업 효과</b>: ${esc(jobDef().desc)}<br><b>피해 특수</b>: ${esc(damageMultiplierText())}</div>
</div>

<div class="nrpg-grid">
  ${card("기본 스탯 최대치", d.maxS, "min(레벨+20, 100)")}
  ${card("최대 HP", d.maxHP, "체력 유효값 × 10")}
  ${card("물리 공격력", d.physical, "floor((힘+체력)/2)")}
  ${card("정신/마법 공격력", d.mental, "마법 공격력 = 정신 공격력")}
  ${card("피해 감소", d.reduction, jobDef().tankReduction ? "탱커 효과 자동 적용" : "수동 보정")}
  ${card("모험가 등급", adventurerGrade(state.레벨).등급, `${adventurerGrade(state.레벨).최소레벨}~${adventurerGrade(state.레벨).최대레벨}레벨 / ${adventurerGrade(state.레벨).설명}`)}
  ${card("경험치", `${state.경험치} / ${state.레벨 < 99 ? nextLevelExp(state.레벨) : "MAX"}`, `누적 ${state.누적경험치}`)}
  ${card("축복 스택", state.축복스택, state.종족 === "천사" ? `스택당 올스탯 +1 / 이번 턴 사용: ${num(state.축복사용턴,0)===num(state.턴,1)?"예":"아니오"}` : "천사 전용")}
  ${card("스킬 수", `고유 ${counts.고유} / 종족 ${counts.종족} / 직업 ${counts.직업}`)}
  ${card("현재 턴", state.턴, "턴 넘기기 시 한턴 효과 제거")}
  ${card("시나리오 NPC", targetPages(false).length, lazyStatus("npc", "NPC"))}
</div>
<div style="margin-top:8px">${bar("HP", state.현재HP, d.maxHP)}</div>


<details class="nrpg-section" open>
  <summary>경험치 / 모험가 등급 / 임무 보상</summary>
  <div class="nrpg-grid">
    ${card("현재 레벨", state.레벨, `다음 필요 경험치 ${state.레벨 < 99 ? nextLevelExp(state.레벨) : "최대 레벨"}`)}
    ${card("현재 경험치", `${state.경험치} / ${state.레벨 < 99 ? nextLevelExp(state.레벨) : "MAX"}`, `누적 ${state.누적경험치}`)}
    ${card("모험가 등급", adventurerGrade(state.레벨).등급, `${adventurerGrade(state.레벨).최소레벨}~${adventurerGrade(state.레벨).최대레벨}레벨`)}
    ${card("임무 제한", `${adventurerGrade(state.레벨).등급}등급 의뢰`, "파티는 최저 등급 기준")}
  </div>
  <div class="nrpg-grid3" style="margin-top:8px">
    <label><span>수동 지급 경험치</span><input id="xpAmount" type="number" min="0" value="100"></label>
    <button data-action="addExperience">경험치 지급</button>
    <div class="nrpg-desc">경험치는 레벨 차이 보정과 등급 배율 없이 그대로 적용됩니다.</div>
  </div>
  <hr>
  <div class="nrpg-grid3">
    <label><span>임무 기준 레벨</span><input id="missionLevel" type="number" min="1" max="99" value="${state.레벨}"></label>
    <label><span>위험도</span><select id="missionRisk">${MISSION_RISKS.map(r => `<option value="${r.위험도}">${r.위험도} · ${r.이름} · 약 ${r.목표상승}레벨</option>`).join("")}</select></label>
    <button data-action="calcMissionExp">임무 경험치 계산</button>
    <button data-action="addMissionExp">계산 후 지급</button>
  </div>
  <div class="nrpg-desc"><b>규칙</b>: 임무는 반복 불가. 모험가 등급은 수락 조건만 담당. 위험도 1~5는 기준 레벨에서 약 1~5레벨 상승하도록 경험치를 책정합니다.</div>
  <div class="nrpg-skill-result"><b>경험치 결과</b>
${esc(state.경험치결과)}

<b>최근 임무 경험치 계산</b>
${esc(state.최근임무경험치계산)}</div>
</details>

<details class="nrpg-section" open>
  <summary>시나리오 / 대상 목록</summary>
  <div class="nrpg-grid3">
    <label><span>진행 시나리오</span><select data-fm="시나리오">${scenarioOptions()}</select></label>
    <label><span>시트지속성</span><select data-fm="시트지속성">${selectOptions(SHEET_ATTRS, state.시트지속성)}</select></label>
    <button data-action="saveTop">시나리오 저장</button>
  </div>
  <div class="nrpg-desc"><b>저렉 Lazy 방식</b>: 이 영역은 시트를 열 때 자동 검색하지 않습니다. <b>시나리오 목록 불러오기</b> 또는 <b>NPC 목록 불러오기</b>를 눌렀을 때만 vault 전체를 검색합니다.<br><b>목록 상태</b>: ${esc(lazyStatus("scenario", "시나리오"))} / ${esc(lazyStatus("npc", "NPC"))}<br><code>시나리오_목록.md</code>의 <code>시나리오목록</code> 속성에 있는 시나리오가 드롭다운으로 표시됩니다. 대상 목록에는 같은 시나리오 값을 가진 <code>시트지속성: NPC</code> 문서만 표시됩니다.</div>
  <div class="nrpg-btns"><button data-action="loadScenarioList">시나리오 목록 불러오기</button><button data-action="loadNpcList">NPC 목록 불러오기</button><button data-action="clearNpcList" class="danger">NPC 목록 캐시 비우기</button></div>
  <div class="nrpg-grid2" style="margin-top:8px">
    <label><span>현재 시나리오 NPC 대상</span><select id="globalTarget" size="6">${targetOptions()}</select></label>
    <div class="nrpg-log">${targetPages(false).map(p => `• ${esc(p.이름 ?? p.file.name)} / ${esc(p.file.path)}`).join("<br>") || "NPC 목록을 불러오면 여기에 표시됩니다."}</div>
  </div>
</details>

<details class="nrpg-section" open>
  <summary>전투 턴 / 지속효과</summary>
  <div class="nrpg-grid3">
    ${card("현재 턴", state.턴, "턴 넘기기 시 한턴 효과 제거")}
    ${card("지속효과", state.지속효과.length, "버프/디버프 대상 포함")}
    <button data-action="endTurn">턴 넘기기</button>
  </div>
  <div class="nrpg-btns"><button data-action="blessingStack" ${state.종족 === "천사" ? "" : "disabled"}>신의 축복 스택 +1</button><button data-action="resetBlessing" ${state.종족 === "천사" ? "" : "disabled"}>축복 초기화</button></div>
  <div style="margin-top:8px">${effectHTML()}</div>
  <div class="nrpg-log" style="margin-top:8px">${effectLogHTML()}</div>
</details>

<details class="nrpg-section" open>
  <summary>스탯 / 자동 보정</summary>
  <table class="nrpg-table">
    <thead><tr><th>스탯</th><th>기본</th><th>종족 자동</th><th>직업 자동</th><th>아이템</th><th>스킬</th><th>임시</th><th>유효</th></tr></thead>
    <tbody>${autoEffectTable()}</tbody>
  </table>
  <div class="nrpg-grid3">
    ${fmInput("최대 HP 보정", "최대HP보정", "number")}
    ${fmInput("물리 공격 보정", "물리공격보정", "number")}
    ${fmInput("정신 공격 보정", "정신공격보정", "number")}
    ${fmInput("피해 감소 보정", "피해감소보정", "number")}
    ${fmInput("판정 난이도 보정", "판정난이도보정", "number")}
    <div class="nrpg-desc">직업 패시브 2배는 만트라 제거로 비활성화되었습니다.</div>
  </div>
  <div class="nrpg-grid2" style="margin-top:8px">
    <label><span>수동 제거 스탯</span><select id="manualRemoved" multiple size="6">${STAT_KEYS.map(s => `<option value="${s}" ${state.수동제거스탯.includes(s) ? "selected" : ""}>${s}</option>`).join("")}</select></label>
    <div class="nrpg-desc">슬라임/사이보그의 외모 제거는 자동입니다. 이 칸은 추가 예외가 필요할 때만 사용합니다.</div>
  </div>
  <div class="nrpg-btns"><button data-action="saveTop">스탯/보정 저장</button></div>
</details>

<details class="nrpg-section" open>
  <summary>판정 / 다이스</summary>
  ${dicePanelHTML()}
  <div class="nrpg-grid2" style="margin-top:8px">
    <label><span>사용 스탯</span>${statSelect("judgeStat")}</label>
    <label><span>난이도</span><select id="judgeDifficultyPreset">${difficultyOptions()}</select></label>
  </div>
  <div class="nrpg-btns"><button data-action="normalJudge">일반 판정</button></div>
  <div class="nrpg-small">난이도는 20 쉬움부터 200 신화적인까지 10단위 목록만 사용합니다. 인간의 난이도 -20, 수동 난이도 보정은 자동 적용됩니다.</div>
  <hr>
  <h4>상대 판정</h4>
  ${opposedDicePanelHTML()}
  <div class="nrpg-grid3" style="margin-top:8px">
    <label><span>내 스탯</span>${statSelect("oppMyStat")}</label>
    <label><span>상대 선택</span><select id="oppTarget">${targetOptions(defaultTargetValue)}</select></label>
    <label><span>상대 스탯</span><select id="oppEnemyStatKey">${selectOptions(STAT_KEYS, "힘")}</select></label>
  </div>
  <div class="nrpg-desc">상대 선택 목록에는 현재 시나리오에 속한 NPC만 표시됩니다. 상대 판정을 누르면 내 주사위와 상대 주사위가 분리된 칸에서 동시에 굴러갑니다.</div>
  <div id="oppTargetStatPreview" style="margin-top:8px">${targetStatSummaryHTML(defaultTargetValue)}</div>
  <div class="nrpg-btns"><button data-action="opposedJudge">상대 판정</button></div>

</details>

<details class="nrpg-section" open>
  <summary>스탯 코인</summary>
  <div class="nrpg-grid3">
    <label><span>선택 스탯</span><select id="coinStat">${selectOptions(STAT_KEYS, state.스탯코인대기스탯 || "힘")}</select></label>
    <button data-action="rollStatCoin">스탯 코인 사용 / 굴림</button>
    <div class="nrpg-card"><div>대기 굴림</div><b>${esc(state.스탯코인대기스탯 || "없음")} ${state.스탯코인대기굴림 ? state.스탯코인대기굴림 : ""}</b><span>대기 중인 값을 적용하거나 버릴 수 있음</span></div>
  </div>
  <div style="margin-top:8px">${statCoinDicePanelHTML()}</div>
  <div class="nrpg-btns"><button data-action="applyStatCoin">대기 굴림 적용</button><button data-action="discardStatCoin" class="danger">대기 굴림 버리기</button></div>
</details>

<details class="nrpg-section" open>
  <summary>종족 / 직업 스킬 선택</summary>
  <div class="nrpg-grid3">
    <label><span>만다라 종류</span><select data-fm="만다라종류">${selectOptions(MANDALA_TYPES, state.만다라종류)}</select></label>
    ${fmInput("만다라명", "만다라명")}
    ${fmCheckbox("만다라 발동 중", "만다라발동중")}
  </div>
  <div class="nrpg-grid2" style="margin-top:8px">
    ${fmInput("영역명", "영역명")}
    ${fmInput("변신명", "변신명")}
  </div>
  <div class="nrpg-grid2" style="margin-top:8px">
    <label><span>영역 설명 / 효과</span><textarea data-fm="영역설명" rows="3" placeholder="영역의 형태와 연출">${esc(state.영역설명)}</textarea></label>
    <label><span>영역 발동 조건 / 지속 시간</span><textarea data-fm="영역발동조건" rows="3" placeholder="예: 전투당 1회, 3턴 지속">${esc(state.영역발동조건)}</textarea></label>
  </div>
  <div class="nrpg-grid2" style="margin-top:8px">
    ${fmInput("코스튬 이름", "코스튬이름")}
    ${fmInput("코스튬 상시 스킬", "코스튬상시스킬")}
  </div>
  <label style="margin-top:8px"><span>코스튬 설명</span><textarea data-fm="코스튬설명" rows="2" placeholder="예: 천사옷, 비행 가능 / 가시 갑옷, 반사 효과">${esc(state.코스튬설명)}</textarea></label>
  <label class="nrpg-check" style="margin-top:8px"><input data-fm="특수진화완료" type="checkbox" ${state.특수진화완료 ? "checked" : ""}><span>용인족 특수진화 완료: 완전 용족화 적용</span></label>
  <div class="nrpg-desc"><b>진화 적용</b>: ${esc(activeEvolutionDef()?.desc ?? "현재 진화 패시브 미적용")}<br><b>80/90레벨</b>: 진화는 상시 사용, 영역·변신은 만다라 발동 중일 때만 사용됩니다.</div>
  <div class="nrpg-btns"><button data-action="saveTop">만다라 저장</button><button data-action="setSuggestedMandala">추천 만다라 적용</button></div>
  <hr>
  <div class="nrpg-grid2">
    <label><span>종족 스킬 목록</span><select id="raceSkillSelect">${skillOptions(raceSkills)}</select></label>
    <label><span>직업 스킬 목록</span><select id="jobSkillSelect">${skillOptions(jobSkills)}</select></label>
  </div>
  <div class="nrpg-btns"><button data-action="addRaceSkill">선택 종족스킬 추가</button><button data-action="addJobSkill">선택 직업스킬 추가</button></div>
  <div class="nrpg-small">종족/직업 기본 스킬은 기존 시트지 방식 그대로 여기에서 추가하고, 직접 만든 스킬은 아래의 ‘스킬 제작’ 영역에서 따로 등록합니다.</div>
</details>

<details class="nrpg-section">
  <summary>스킬 제작</summary>
  <div class="nrpg-desc"><b>상세 스킬 제작</b>: 기본 정보만 입력하면 설명형 스킬, 자동효과를 켜면 스탯 변화·회복·피해·상태이상·코인·지속효과까지 처리하는 스킬을 만들 수 있습니다.</div>
  <div class="nrpg-grid">
    <label><span>스킬명</span><input id="skillName" placeholder="예: 피의 격노 / 보호의 노래 / 독침"></label>
    <label><span>스킬 종류</span><select id="skillType">${selectOptions(SKILL_TYPES, "고유")}</select></label>
    <label><span>효과분류</span><select id="skillKind">${selectOptions(EFFECT_KINDS, "특수")}</select></label>
    <label><span>획득 레벨</span><input id="skillLevel" type="number" placeholder="예: 1 / 10 / 70"></label>
    <label><span>효과 요약</span><input id="skillEffect" placeholder="짧은 효과 요약. 목록과 결과창에 표시됩니다."></label>
    <label><span>기본 대상</span><select id="skillTarget">${targetOptions()}</select></label>
    <label><span>지속 턴</span><input id="skillTurns" type="number" value="1" min="1" placeholder="지속 턴"></label>
    <label><span>기본 HP 사용량</span><input id="skillHpCost" type="text" value="" placeholder="예: 10 / 1d6 / 10% / 비워두면 없음"></label>
  </div>
  <label class="nrpg-check" style="margin-top:8px"><input id="skillAdvancedToggle" type="checkbox"><span>상세 자동효과 사용</span></label>
  <div id="skillAdvancedPanel" class="nrpg-advanced">
    <div class="nrpg-advanced-title">상세 자동효과: 이 정도면 대부분의 스킬을 직접 만들 수 있는 확장 설정</div>
    <div class="nrpg-grid3">
      <label><span>자동효과 대상</span><select id="advAutoTarget"><option value="self">자기 자신</option><option value="target">스킬 사용 대상</option><option value="both">자신 + 대상 둘 다</option></select></label>
      <label><span>자동효과 이름</span><input id="advEffectName" placeholder="비우면 스킬명 사용"></label>
      <label><span>자동효과 지속 턴</span><input id="advAutoTurns" type="number" value="1" min="1"></label>
    </div>
    <div class="nrpg-grid2" style="margin-top:8px">
      <label><span>임시 스탯 변화</span><textarea id="advTempStats" rows="5" placeholder="예:\n힘 +1d6\n체력 +3\n민첩 -2\n올스탯 +1"></textarea></label>
      <label><span>전투 수치 보정</span><textarea id="advExtraBonuses" rows="5" placeholder="예:\n피해감소 +3\n최대HP +10\n물리공격력 +5\n마법공격력 +1d6\n판정난이도 -10"></textarea></label>
    </div>
    <div class="nrpg-grid3" style="margin-top:8px">
      <label><span>자동 회복량</span><input id="advHealAmount" placeholder="예: 10 / 1d6 / 10% / 최대HP10%"></label>
      <label><span>자동 피해량</span><input id="advDamageAmount" placeholder="예: 10 / 2d6+3 / 10%"></label>
      <label><span>피해 종류</span><select id="advDamageKind"><option value="고정">고정</option><option value="물리">물리</option><option value="마법">마법</option><option value="순수">순수</option></select></label>
      <label><span>상태이상 부여</span><input id="advStatusAdd" placeholder="예: 중독, 기절, 공포"></label>
      <label><span>코인 변화</span><input id="advCoinDelta" placeholder="예: -3 / +1d6"></label>
      <label><span>사용 조건 짧은 메모</span><input id="advShortCondition" placeholder="예: 피가 묻은 무기 필요"></label>
    </div>
    <hr>
    <div class="nrpg-advanced-title">스택 / 영구 변화 / 랜덤 결과</div>
    <div class="nrpg-grid3">
      <label><span>개인 스택 이름</span><input id="advStackName" placeholder="예: 마탄 탄환 / 분노 / 충전"></label>
      <label><span>시작 스택</span><input id="advStackStart" type="number" value="0"></label>
      <label><span>최대 스택</span><input id="advStackMax" type="number" value="0" placeholder="0이면 제한 없음"></label>
      <label><span>사용 시 스택 변화</span><input id="advStackDelta" type="text" value="0" placeholder="예: 1 / -1 / 1d6 / -1d4"></label>
      <label><span>영구 변화 스탯</span><select id="advPermanentStat"><option value="">없음</option>${STAT_KEYS.map(s => `<option value="${s}">${s}</option>`).join("")}</select></label>
      <label><span>영구 변화 수치</span><input id="advPermanentValue" type="text" value="0" placeholder="예: -3 / 1d6 / -3d5"></label>
    </div>
    <label class="nrpg-check" style="margin-top:8px"><input id="advPermanentOnUse" type="checkbox"><span>스킬 사용 시 위 영구 스탯 변화를 자동 적용</span></label>
    <label style="margin-top:8px"><span>스택 단계별 효과</span><textarea id="advStackSteps" rows="6" placeholder="예:\n1=약한 효과\n2=보통 효과\n3=강한 효과\n7=시전자 사망"></textarea></label>
    <div class="nrpg-grid2" style="margin-top:8px">
      <label><span>효과 결과 굴림식</span><input id="advResultRoll" placeholder="예: 1d7 / 1d6 / 2d6+3"></label>
      <label><span>결과표</span><textarea id="advResultTable" rows="4" placeholder="예:\n1=약한 효과\n2-3=보통 효과\n4+=강한 효과\n홀수=부작용"></textarea></label>
    </div>
    <div class="nrpg-grid2" style="margin-top:8px">
      <label><span>발동 조건 / 제한</span><textarea id="advCondition" rows="3" placeholder="예: 분노 스택이 1 이상일 때만 사용"></textarea></label>
      <label><span>리스크 / 대가</span><textarea id="advRisk" rows="3" placeholder="예: 실패 시 자신에게 1d6 순수 피해"></textarea></label>
    </div>
    <label style="margin-top:8px"><span>GM 처리 메모</span><textarea id="advGmNote" rows="3" placeholder="피해 배수, 범위, 판정 방식, 예외 처리"></textarea></label>
    <label style="margin-top:8px"><span>추가 고급 JSON 선택 입력</span><textarea id="advCustomJson" rows="4" placeholder='예: {"범위":"시야 내 단일 대상", "소모":"HP 10%", "쿨타임":"전투당 1회"}'></textarea></label>
    <div class="nrpg-stack-preview"><b>예시 1 · 강화 버프</b> 임시 스탯 변화에 <code>힘 +1d6</code>, 전투 수치 보정에 <code>피해감소 +3</code>, 지속 턴 2<br><b>예시 2 · 독 공격</b> 자동효과 대상 <code>스킬 사용 대상</code>, 자동 피해량 <code>1d6</code>, 상태이상 <code>중독</code>, 지속 턴 3<br><b>예시 3 · 회복 노래</b> 자동효과 대상 <code>스킬 사용 대상</code>, 자동 회복량 <code>10%</code>, 상태이상 <code>용기</code></div>
  </div>
  <div class="nrpg-small">자동효과는 지속효과로 저장되어 유효 스탯 계산에 반영됩니다. 대상이 NPC 문서라면 대상 문서 frontmatter에도 효과가 기록됩니다.</div>
  <div class="nrpg-btns"><button data-action="addSkill">직접 스킬 추가</button></div></details>

<details class="nrpg-section" open>
  <summary>스킬 목록 / 사용</summary>
  <div class="nrpg-desc">등록된 스킬을 확인하고 사용할 수 있는 영역입니다. 스킬 제작은 위의 ‘스킬 제작’ 영역에서 따로 진행합니다.</div>
  <div class="nrpg-grid3" style="margin-top:8px"><label><span>스킬 사용 대상</span><select id="skillUseTarget">${targetOptions()}</select></label><label><span>이번 사용 HP 소모 직접 입력</span><input id="skillHpOverride" type="text" placeholder="비우면 스킬 기본 HP 사용량 사용"></label><div class="nrpg-desc">버프/디버프 스킬은 이 대상에게 적용됩니다. HP 소모는 10, 1d6, 10% 형식 가능.</div></div>
  <div class="nrpg-skill-result"><b>스킬 결과</b>
${esc(state.스킬결과)}</div>
  ${skillListHTML()}
</details>


<details class="nrpg-section">
  <summary>흡혈 / 피해 회복 도구</summary>
  <div class="nrpg-grid3">
    <label><span>입힌 피해량</span><input id="dealtDamageAmount" type="number" min="0" value="0" placeholder="입힌 피해"></label>
    <button data-action="applyDealtDamage" ${state.종족 === "뱀파이어" ? "" : "disabled"}>뱀파이어 흡혈 회복</button>
    <div class="nrpg-card"><div>흡혈 결과</div><b>${state.종족 === "뱀파이어" ? "사용 가능" : "뱀파이어 전용"}</b><span>입힌 피해량만큼 HP 회복</span></div>
  </div>
  <div class="nrpg-skill-result"><b>흡혈 결과</b>
${esc(state.흡혈결과)}</div>
</details>

<details class="nrpg-section">
  <summary>흥정 / 특수 처리 도구</summary>
  <div class="nrpg-grid3">
    <label><span>거래 종류</span><select id="dealMode"><option value="buy">구매</option><option value="sell">판매</option></select></label>
    <label><span>현재 가격</span><input id="dealPrice" type="number" value="10"></label>
    <label><span>판정 결과</span><select id="dealSuccess"><option value="success">성공</option><option value="fail">실패</option></select></label>
  </div>
  <div class="nrpg-btns"><button data-action="haggle">흥정 계산</button></div>
  <div class="nrpg-small">흥정 변화량은 1d6 코인 고정. 구매 실패 시 가격 상승, 판매 실패 시 가격 하락.</div>
</details>

<details class="nrpg-section">
  <summary>장비 등급 기준</summary>
  ${equipmentGradeHTML()}<div class="nrpg-desc">장비 자동 효과 합계: ${esc(equipmentSummaryText())}</div>
  <div class="nrpg-desc">일반 등급은 3골드 정도의 아무 효과 없는 무기입니다. 레어 이상 장비의 가격과 효과는 GM이 시나리오 영향도에 따라 정합니다.</div>
</details>


<details class="nrpg-section" open>
  <summary>아이템 / 장비 능력과 소유 자동효과</summary>
  <div class="nrpg-grid3">
    ${card("보유 능력", itemAbilityRecords().length, "장비 능력 + 소유 아이템 능력")}
    ${card("소유 자동효과", ownedItemBonuses().items.length, ownedItemBonusSummaryText())}
    <button data-action="refreshItemCatalog">아이템 목록 불러오기/새로고침</button>
  </div>
  <div class="nrpg-desc">장비 능력은 장비 중일 때 사용하고, 소유형 아이템은 <code>소유효과사용: true</code> 또는 <code>능력유형: 소유자동효과</code>일 때 자동 보정됩니다. 예: <code>운 -20, 힘 +3, 민첩 +3, 체력 +3, 지능 +3, 지혜 +3</code></div>
  <div style="margin-top:8px">${itemAbilityHTML()}</div>
</details>

<details class="nrpg-section">
  <summary>상태 / 장비 / 아이템 / 메모</summary>
  <div class="nrpg-grid3"><input id="statusInput" placeholder="상태이상 입력"><button data-action="addStatus">상태 추가</button><button data-action="clearStatus" class="danger">상태 전체 제거</button></div>
  <div style="margin-top:8px">${statusHTML()}</div>
  <hr>
  <h4>아이템 노트에서 바로 추가</h4>
  <div class="nrpg-grid3">
    <label><span>아이템 노트 목록</span><select id="catalogItemSelect">${itemCatalogOptions()}</select></label>
    <label><span>추가 방식</span><select id="catalogItemMode"><option value="auto">자동 판단</option><option value="inventory">아이템목록</option><option value="equipment">장비목록</option></select></label>
    <button data-action="addCatalogItem">선택 아이템 추가</button>
  </div>
  <div class="nrpg-desc"><b>저렉 Lazy 방식</b>: 아이템 노트 목록도 시트를 열 때 자동 검색하지 않습니다. <b>아이템 목록 불러오기</b>를 눌렀을 때만 현재 시나리오의 <code>아이템</code> 폴더 또는 <code>종류: 아이템</code> 노트를 검색합니다.<br><b>목록 상태</b>: ${esc(lazyStatus("item", "아이템"))}<br>장비 유형은 <code>이름|등급|가격|효과</code> 형식으로 장비목록에 추가됩니다.</div>
  <div class="nrpg-btns"><button data-action="refreshItemCatalog">아이템 목록 불러오기/새로고침</button><button data-action="clearItemCatalog" class="danger">아이템 목록 캐시 비우기</button></div>
  <hr>
  <h4>현재 보유 장비 / 아이템 제거</h4>
  <div class="nrpg-grid2">
    <div>${equipmentListManageHTML()}</div>
    <div>${inventoryListManageHTML()}</div>
  </div>
  <hr>
  <h4>커스텀 아이템을 시트에 바로 추가</h4>
  <div class="nrpg-grid3">
    <input id="customItemName" placeholder="커스텀 아이템 이름">
    <select id="customItemMode"><option value="inventory">아이템목록</option><option value="equipment">장비목록</option></select>
    <input id="customItemGrade" placeholder="등급 또는 가격. 예: 일반|3">
    <input id="customItemEffect" placeholder="효과. 예: 힘 +1 / 1회용 폭발물">
    <button data-action="addCustomItemToList">커스텀 아이템 추가</button>
  </div>
  <div class="nrpg-small">이 기능은 JS Engine 시트 화면 안에서 작동합니다. 아이템 노트가 새로 생기면 이 시트를 다시 열거나 새로고침하면 목록에 표시됩니다.</div>
  <hr>
  <label><span>장비 목록</span><textarea id="equipText" rows="4" placeholder="한 줄에 하나씩 입력
예: 철검|일반|3|힘 +1
예: 수호 방패|레어|25|피해감소 +3, 최대HP +10">${esc(itemTextList(state.장비목록))}</textarea><div class="nrpg-small">자동 계산 형식: 이름|등급|가격|효과</div></label>
  <label><span>아이템 목록</span><textarea id="itemText" rows="4" placeholder="한 줄에 하나씩 입력">${esc(itemTextList(state.아이템목록))}</textarea></label>
  <div class="nrpg-btns"><button data-action="saveLists">장비/아이템 저장</button></div>
</details>

<details class="nrpg-section" open>
  <summary>최근 결과</summary>
  <div class="nrpg-result">${esc(state.최근결과)}</div>
  <div class="nrpg-small">이 버전은 frontmatter에 로그를 누적 저장하지 않습니다.</div>
</details>

<details class="nrpg-danger-zone">
  <summary>위험 작업: 시트지 초기화</summary>
  <div class="nrpg-desc">실수 클릭을 막기 위해 가장 아래의 접힌 영역으로 이동했습니다. 새 캐릭터를 만들 때만 사용하세요.</div>
  <div class="nrpg-btns"><button data-action="resetStarter" class="danger">초기 스탯 세팅: 모든 스탯 1 / 스탯코인 6</button></div>
</details>`;
  setupDetailPersistence();
}

function readFormPatch() {
  const patch = {};
  root.querySelectorAll("[data-fm]").forEach(el => {
    const key = el.dataset.fm;
    if (el.type === "checkbox") patch[key] = el.checked;
    else if (el.dataset.num === "1") patch[key] = num(el.value, 0);
    else patch[key] = el.value;
  });
  const manualRemoved = Array.from(root.querySelector("#manualRemoved")?.selectedOptions ?? []).map(o => o.value).filter(x => STAT_KEYS.includes(x));
  patch.수동제거스탯 = manualRemoved;
  return patch;
}
function selectedDifficulty() {
  return Math.max(20, num(root.querySelector("#judgeDifficultyPreset")?.value, 60));
}

root.addEventListener("click", async event => {
  const btn = event.target.closest("button[data-action]");
  if (!btn || !root.contains(btn)) return;
  event.preventDefault();
  const action = btn.dataset.action;
  if (diceRollingLock) return;

  if (action === "refreshRender") { render(); return; }
  if (action === "addExperience") {
    const amount = Math.max(0, Math.floor(num(root.querySelector("#xpAmount")?.value, 0)));
    if (!amount) { await save(withLog("경험치 지급 실패: 지급량을 입력해야 합니다.")); return; }
    await save(applyExperiencePatch(amount));
    return;
  }
  if (action === "calcMissionExp" || action === "addMissionExp") {
    const mlv = clamp(Math.floor(num(root.querySelector("#missionLevel")?.value, state.레벨)), 1, 99);
    const risk = clamp(Math.floor(num(root.querySelector("#missionRisk")?.value, 1)), 1, 5);
    const r = missionRiskDef(risk);
    const amount = missionExp(mlv, risk);
    const grade = adventurerGrade(mlv);
    const text = `임무 기준 레벨 ${mlv} / 임무 등급 ${grade.등급} / 위험도 ${risk}(${r.이름}) → 경험치 ${amount} / 목표 성장 약 ${r.목표상승}레벨`;
    if (action === "calcMissionExp") { await save(withLog(text, { 최근임무경험치계산: text })); return; }
    await save({ ...applyExperiencePatch(amount), 최근임무경험치계산: text });
    return;
  }
  if (action === "useItemAbility") {
    const i = num(btn.dataset.index, -1);
    const a = itemAbilityRecords()[i];
    if (!a) { await save(withLog("아이템 능력 확인 실패: 대상 없음")); return; }
    const text = `[${a.보유구분}] ${a.이름} · ${a.능력명}
유형: ${a.능력유형}
조건: ${a.발동조건}
소모: ${a.소모}
설명: ${a.능력설명 || "설명 없음"}
계산식·효과: ${a.계산식 || "없음"}
상한: ${a.상한 || "없음"}
위험: ${a.위험 || "없음"}
실패결과: ${a.실패결과 || "없음"}`;
    await save(withLog(text, { 스킬결과: text }));
    return;
  }
  if (action === "loadScenarioList") { const list = scenarioList(true); await save({ 최근결과: `시나리오 목록 ${list.length}개를 frontmatter 캐시에 저장했습니다.`, 로그: [], 효과로그: [] }); return; }
  if (action === "loadNpcList") { const list = targetPages(true); await save({ 최근결과: `NPC 목록 ${list.length}개를 frontmatter 캐시에 저장했습니다.`, 로그: [], 효과로그: [] }); return; }
  if (action === "clearNpcList") { clearStoredList("npc"); await save({ 최근결과: "NPC 목록 캐시를 비웠습니다.", 로그: [], 효과로그: [] }); return; }
  if (action === "saveTop") { await save(withLog("수정사항 저장", readFormPatch())); return; }
  if (action === "levelUp") { const nextLv = Math.min(99, state.레벨 + 1); await save(withLog("수동 레벨 +1 / 스탯코인 +1", { 레벨: nextLv, 모험가등급: adventurerGrade(nextLv).등급, 스탯코인: state.스탯코인 + 1, 성장기록: [] })); return; }
  if (action === "levelDown") { const nextLv = Math.max(1, state.레벨 - 1); await save(withLog("레벨 -1", { 레벨: nextLv, 모험가등급: adventurerGrade(nextLv).등급 })); return; }
  if (action === "resetStarter") {
    await save(withLog("플레이어 생성 초기 세팅 적용: 모든 기본 스탯 1 / 스탯코인 6", starterStatPatch()));
    return;
  }
  if (action === "fullHeal") { await save(withLog("HP 최대 회복", { 현재HP: calc().maxHP })); return; }
  if (action === "applyDamage" || action === "damageHP") {
    const amount = Math.max(0, num(root.querySelector("#hpDamageAmount")?.value, 0));
    const kind = root.querySelector("#hpDamageType")?.value || "물리";
    if (!amount) { await save(withLog("피해 적용 실패: 피해량을 입력해야 합니다.")); return; }
    const result = incomingDamageResult(amount, kind);
    const nextHP = clamp(state.현재HP - result.final, 0, calc().maxHP);
    let patch = { 현재HP: nextHP, 피해결과: `${kind} 피해 ${amount} → 최종 ${result.final}
${result.detail}
HP ${state.현재HP} → ${nextHP}`, 최근피해종류: kind };
    patch = resetBlessingOnDamagePatch(patch, result.final);
    await save(withLog(`피해 적용: ${kind} ${amount} → 최종 ${result.final} / HP ${state.현재HP} → ${nextHP}`, patch));
    return;
  }
  if (action === "blessingStack") {
    if (state.종족 !== "천사") { await save(withLog("신의 축복은 천사 전용입니다.")); return; }
    if (num(state.축복사용턴, 0) === num(state.턴, 1)) { await save(withLog("신의 축복은 턴당 1번만 쌓을 수 있습니다.")); return; }
    const next = Math.max(0, num(state.축복스택, 0)) + 1;
    await save(withLog(`신의 축복 스택 +1: ${state.축복스택} → ${next}`, { 축복스택: next, 축복사용턴: state.턴 })); return;
  }
  if (action === "resetBlessing") { await save(withLog("신의 축복 스택 초기화", { 축복스택: 0 })); return; }
  if (action === "applyDealtDamage") {
    const dealt = Math.max(0, num(root.querySelector("#dealtDamageAmount")?.value, 0));
    if (state.종족 !== "뱀파이어") { await save(withLog("흡혈 회복은 뱀파이어 전용입니다.")); return; }
    if (!dealt) { await save(withLog("흡혈 회복 실패: 입힌 피해량 필요")); return; }
    const d = calc();
    const nextHP = clamp(state.현재HP + dealt, 0, d.maxHP);
    await save(withLog(`뱀파이어 흡혈: 입힌 피해 ${dealt}만큼 회복 / HP ${state.현재HP} → ${nextHP}`, { 현재HP: nextHP, 흡혈결과: `입힌 피해 ${dealt}
HP ${state.현재HP} → ${nextHP}` })); return;
  }
  if (action === "endTurn") {
    await tickScenarioNpcEffects();
    const patch = oneTurnResetPatch();
    await save(withLog(`턴 ${state.턴} 종료 → 턴 ${state.턴 + 1}. 한턴 효과 제거 및 임시 보정 초기화`, patch));
    return;
  }

  if (action === "normalJudge") {
    const stat = root.querySelector("#judgeStat").value;
    const rawDiff = selectedDifficulty();
    const diff = adjustedDifficulty(rawDiff);
    const target = effectiveStat(stat);
    if (target === null) { await save(withLog(`${stat} 판정 불가: 제거된 스탯`, { 다이스표시: "판정 불가", 다이스상세: `${stat}은 제거된 스탯입니다.` })); return; }
    const blessing = consumeFairyBlessing(state.지속효과, "self");
    const curse = consumeFairyCurse(blessing.effects, "self");
    const actualTarget = Math.max(1, target + blessing.bonus - curse.penalty);
    const effectLogs = [blessing.logLine, curse.logLine].filter(Boolean);
    const effectPatch = effectLogs.length ? { 지속효과: curse.effects, 효과로그: [...arr(state.효과로그), ...effectLogs].slice(-30) } : {};
    if (actualTarget >= diff) {
      const text = `${stat} 일반 판정 자동 성공 / 유효 ${stat} ${target}${blessing.text}${curse.text} = ${actualTarget} ≥ 실제 난이도 ${diff} (원 난이도 ${rawDiff})`;
      await save(withLog(text, { ...effectPatch, 다이스표시: "자동 성공", 다이스상세: text, 다이스결과타입: "성공" })); return;
    }
    const roll = dice(diff);
    const success = roll <= actualTarget;
    const special = roll === 1 ? " / 대성공: 긍정적 부가효과" : roll === diff ? " / 대실패: 부정적 부가효과" : "";
    const text = `${stat} 일반 판정: 1d${diff}=${roll} ≤ 유효 ${target}${blessing.text}${curse.text} = ${actualTarget} / ${success ? "성공" : "실패"}${special} (원 난이도 ${rawDiff})`;
    await rollAndSave({ finalDisplay: String(roll), detail: text, type: roll === 1 ? "대성공" : roll === diff ? "대실패" : success ? "성공" : "실패", sides: diff, patch: effectPatch }); return;
  }
  if (action === "opposedJudge") {
    const myStat = root.querySelector("#oppMyStat")?.value ?? "힘";
    const enemyStat = root.querySelector("#oppEnemyStatKey")?.value ?? myStat;
    const targetValue = root.querySelector("#oppTarget")?.value ?? "";
    const target = targetLiveDataByValue(targetValue);
    if (!target) { await save(withLog("상대 판정 실패: 먼저 NPC 목록 불러오기를 누르거나 상대 파일 경로를 선택해야 합니다.", { 상대다이스상세: "NPC 대상 없음" })); return; }
    const my = effectiveStat(myStat);
    const enemy = actorEffectiveStat(target, enemyStat);
    const targetName = targetNameByValue(targetValue);
    if (my === null) { await save(withLog(`${myStat} 상대 판정 불가: 내 제거된 스탯`, { 다이스표시: "판정 불가", 다이스상세: `${myStat}은 제거된 스탯입니다.`, 상대다이스상세: `${myStat}은 제거된 스탯입니다.` })); return; }
    if (enemy === null) { await save(withLog(`${enemyStat} 상대 판정 불가: ${targetName}의 제거된 스탯`, { 다이스표시: "판정 불가", 다이스상세: `${targetName}의 ${enemyStat}은 제거된 스탯입니다.`, 상대다이스상세: `${targetName}의 ${enemyStat}은 제거된 스탯입니다.` })); return; }
    const myBlessing = consumeFairyBlessing(state.지속효과, 'self');
    const myCurse = consumeFairyCurse(myBlessing.effects, 'self');
    const targetEffectsNow = arr(target.지속효과);
    const enemyBlessing = consumeFairyBlessing(targetEffectsNow, 'self');
    const enemyCurse = consumeFairyCurse(enemyBlessing.effects, 'self');
    const myBaseRoll = dice(my);
    const enemyBaseRoll = dice(enemy);
    const myRoll = Math.max(1, myBaseRoll + myBlessing.bonus - myCurse.penalty);
    const enemyRoll = Math.max(1, enemyBaseRoll + enemyBlessing.bonus - enemyCurse.penalty);
    const effectLogs = [myBlessing.logLine, myCurse.logLine, enemyBlessing.logLine, enemyCurse.logLine].filter(Boolean);
    const cursePatch = effectLogs.length ? { 지속효과: myCurse.effects, 효과로그: [...arr(state.효과로그), ...effectLogs].slice(-30) } : { 지속효과: myCurse.effects };
    if (enemyBlessing.logLine || enemyCurse.logLine) {
      await setTargetEffectsFrontmatter(targetValue, enemyCurse.effects, [enemyBlessing.logLine, enemyCurse.logLine].filter(Boolean).join(' / '));
    }
    let result = "패배";
    if (myRoll > enemyRoll) result = "승리";
    else if (myRoll === enemyRoll) result = my > enemy ? "승리(동률, 내 유효 스탯 우세)" : my < enemy ? "패배(동률, 상대 유효 스탯 우세)" : "재판정 필요";
    const myModText = `${myBlessing.bonus ? `+${myBlessing.bonus}` : ""}${myCurse.penalty ? `-${myCurse.penalty}` : ""}`;
    const enemyModText = `${enemyBlessing.bonus ? `+${enemyBlessing.bonus}` : ""}${enemyCurse.penalty ? `-${enemyCurse.penalty}` : ""}`;
    const myRollText = myModText ? `${myBaseRoll}${myModText}=${myRoll}` : `${myRoll}`;
    const enemyRollText = enemyModText ? `${enemyBaseRoll}${enemyModText}=${enemyRoll}` : `${enemyRoll}`;
    const text = `상대 판정: 내 ${myStat} 1d${my}=${myRollText} / ${targetName} ${enemyStat} 1d${enemy}=${enemyRollText} / ${result}`;
    await rollOpposedAndSave({
      myFinal: myRoll,
      enemyFinal: enemyRoll,
      detail: text,
      type: result,
      mySides: my,
      enemySides: enemy,
      myLabel: `내 ${myStat} · 1d${my}`,
      enemyLabel: `${targetName} ${enemyStat} · 1d${enemy}`,
      patch: cursePatch,
    });
    return;
  }

  if (action === "rollStatCoin") {
    if (state.스탯코인 <= 0) { await save(withLog("스탯 코인 부족")); return; }
    const stat = root.querySelector("#coinStat").value;
    const roll = dice(baseStatMax());
    const text = `스탯 코인 사용: ${stat} 1d${baseStatMax()}=${roll}. 적용하거나 버릴 수 있음`;
    await rollStatCoinAndSave({ finalDisplay: String(roll), detail: text, type: "대기", sides: baseStatMax(), patch: { 스탯코인: state.스탯코인 - 1, 스탯코인대기스탯: stat, 스탯코인대기굴림: roll } }); return;
  }
  if (action === "applyStatCoin") {
    const stat = state.스탯코인대기스탯;
    const roll = num(state.스탯코인대기굴림, 0);
    if (!stat || !roll) { await save(withLog("적용할 스탯 코인 굴림 없음")); return; }
    await save(withLog(`스탯 코인 적용: ${stat} ${state[stat]} → ${roll}`, { [stat]: roll, 스탯코인대기스탯: "", 스탯코인대기굴림: 0, 스탯코인다이스표시: String(roll), 스탯코인다이스상세: `적용 완료: ${stat} ${state[stat]} → ${roll}`, 스탯코인다이스결과타입: "성공" })); return;
  }
  if (action === "discardStatCoin") { await save(withLog("스탯 코인 굴림 버림", { 스탯코인대기스탯: "", 스탯코인대기굴림: 0, 스탯코인다이스표시: "버림", 스탯코인다이스상세: "스탯 코인 굴림을 버렸습니다.", 스탯코인다이스결과타입: "실패" })); return; }
  if (action === "setSuggestedMandala") {
    const sug = mandalaSuggestion();
    if (!["진화", "영역", "변신"].includes(sug.type)) { await save(withLog(`추천 만다라 자동 적용 불가: ${sug.text}`)); return; }
    await save(withLog(`추천 만다라 적용: ${sug.type}`, { 만다라종류: sug.type })); return;
  }
  if (action === "addRaceSkill") {
    const i = num(root.querySelector("#raceSkillSelect")?.value, -1);
    const s = addableRaceSkills()[i];
    if (!s) { await save(withLog("추가할 종족스킬 없음")); return; }
    await save(withLog(`종족스킬 추가: ${s.이름}`, { 보유스킬: [...state.보유스킬, s] })); return;
  }
  if (action === "addJobSkill") {
    const i = num(root.querySelector("#jobSkillSelect")?.value, -1);
    const s = addableJobSkills()[i];
    if (!s) { await save(withLog("추가할 직업스킬 없음")); return; }
    await save(withLog(`직업스킬 추가: ${s.이름}`, { 보유스킬: [...state.보유스킬, s] })); return;
  }
  if (action === "addSkill") {
    const name = root.querySelector("#skillName").value.trim();
    if (!name) { await save(withLog("스킬 추가 실패: 이름 필요")); return; }
    const kind = root.querySelector("#skillKind")?.value ?? "특수";
    const target = root.querySelector("#skillTarget")?.value ?? "";
    if (["버프", "디버프"].includes(kind) && !target) { await save(withLog("스킬 추가 실패: 버프/디버프는 대상 지정 필요")); return; }
    const advancedOn = root.querySelector("#skillAdvancedToggle")?.checked === true;
    const advanced = advancedOn ? {
      사용: true,
      스택: {
        이름: root.querySelector("#advStackName")?.value?.trim() ?? "",
        현재: Math.max(0, num(root.querySelector("#advStackStart")?.value, 0)),
        시작: Math.max(0, num(root.querySelector("#advStackStart")?.value, 0)),
        최대: Math.max(0, num(root.querySelector("#advStackMax")?.value, 0)),
        사용시변화: String(root.querySelector("#advStackDelta")?.value ?? "0").trim() || "0",
      },
      스택단계효과: parseStackSteps(root.querySelector("#advStackSteps")?.value),
      영구스탯변화: {
        스탯: root.querySelector("#advPermanentStat")?.value ?? "",
        수치: root.querySelector("#advPermanentValue")?.value?.trim() ?? "0",
        사용시자동적용: root.querySelector("#advPermanentOnUse")?.checked === true,
      },
      결과굴림식: root.querySelector("#advResultRoll")?.value?.trim() ?? "",
      결과표: parseResultTable(root.querySelector("#advResultTable")?.value),
      발동조건: root.querySelector("#advCondition")?.value?.trim() || root.querySelector("#advShortCondition")?.value?.trim() || "",
      리스크: root.querySelector("#advRisk")?.value?.trim() ?? "",
      GM메모: root.querySelector("#advGmNote")?.value?.trim() ?? "",
      자동효과: {
        대상: root.querySelector("#advAutoTarget")?.value ?? "self",
        지속효과명: root.querySelector("#advEffectName")?.value?.trim() ?? "",
        지속턴: Math.max(1, num(root.querySelector("#advAutoTurns")?.value, root.querySelector("#skillTurns")?.value ?? 1)),
        임시스탯: root.querySelector("#advTempStats")?.value?.trim() ?? "",
        수치보정: root.querySelector("#advExtraBonuses")?.value?.trim() ?? "",
        회복량: root.querySelector("#advHealAmount")?.value?.trim() ?? "",
        피해량: root.querySelector("#advDamageAmount")?.value?.trim() ?? "",
        피해종류: root.querySelector("#advDamageKind")?.value ?? "고정",
        상태부여: root.querySelector("#advStatusAdd")?.value?.trim() ?? "",
        코인변화: root.querySelector("#advCoinDelta")?.value?.trim() ?? "",
      },
      추가JSON: safeJson(root.querySelector("#advCustomJson")?.value),
    } : null;
    const skillObj = { 이름: name, 종류: root.querySelector("#skillType").value, 효과분류: kind, 레벨: root.querySelector("#skillLevel").value || "", 효과: root.querySelector("#skillEffect").value || "", HP소모: root.querySelector("#skillHpCost")?.value?.trim() || "", 대상: target, 대상이름: targetNameByValue(target), 지속턴: Math.max(1, num(root.querySelector("#skillTurns")?.value, 1)), 고급설정: advanced };
    await save(withLog(`스킬 추가: ${name}${advancedOn ? " / 고급 설정 포함" : ""}`, { 보유스킬: [...state.보유스킬, skillObj] })); return;
  }
  if (action === "useSkill") {
    const i = num(btn.dataset.index, -1);
    const s = state.보유스킬[i];
    if (!s) { await save(withLog("사용할 스킬 없음")); return; }
    const name = s?.이름 ?? s?.name ?? "스킬";
    const kind = s?.효과분류 ?? s?.분류 ?? "특수";
    const effect = s?.효과 ?? s?.effect ?? "";
    const gate = canUseSkillByMandala(s);
    if (!gate.ok) { await save(withLog(`${name} 사용 실패: ${gate.reason}`, { 스킬결과: `${name} 사용 실패
- 사유: ${gate.reason}` })); return; }
    const hpCostRaw = String(root.querySelector("#skillHpOverride")?.value?.trim() || s?.HP소모 || "");
    const hpCost = parseHpCost(hpCostRaw);
    if (!hpCost.ok) { await save(withLog(`${name} 사용 실패: HP 소모식 오류`, { 스킬결과: `${name} 사용 실패
- HP 소모식 오류: ${hpCost.detail}` })); return; }
    const hpCostPatch = {};
    const hpCostLine = hpCost.cost > 0 ? `
- HP 소모: ${hpCost.detail} / ${state.현재HP} → ${Math.max(0, state.현재HP - hpCost.cost)}` : "";
    if (hpCost.cost > 0) {
      if (state.현재HP < hpCost.cost) { await save(withLog(`${name} 사용 실패: HP 부족`, { 스킬결과: `${name} 사용 실패
- 필요 HP: ${hpCost.cost}
- 현재 HP: ${state.현재HP}` })); return; }
      hpCostPatch.현재HP = Math.max(0, state.현재HP - hpCost.cost);
    }
    let target = root.querySelector("#skillUseTarget")?.value || s?.대상 || "";
    const advancedResult = advancedUsePatch(s, target);
    if (advancedResult.targetOps) {
      const targetAuto = await applyAdvancedTargetOps(target, advancedResult.targetOps);
      advancedResult.logs.push(...targetAuto.logs);
      advancedResult.resultLines.push(...targetAuto.resultLines);
    }
    let advancedPatch = { ...advancedResult.patch };
    const updatedSkill = advancedPatch.__nextSkill;
    delete advancedPatch.__nextSkill;
    if (updatedSkill) advancedPatch.보유스킬 = state.보유스킬.map((x, idx) => idx === i ? updatedSkill : x);
    const advancedLogText = advancedResult.logs.length ? ` / 고급: ${advancedResult.logs.join(" / ")}` : "";
    const skillResultText = `${name} 사용 결과
- 기본 효과: ${effect || "효과 수동 처리"}${hpCostLine}${advancedResult.resultLines.length ? `
- 고급 결과:
${advancedResult.resultLines.map(x => `  · ${x}`).join("\n")}` : ""}`;
    if (state.종족 === '용인족' && name === '강제 용족화') {
      const boost = {}; const rebound = {}; const lines = [];
      for (const st of STAT_KEYS) {
        const plus = parseDiceFormula('1d30');
        const minus = parseDiceFormula('-3d5');
        boost[`${st}임시`] = num(state[`${st}임시`], 0) + plus.total;
        rebound[st] = minus.total;
        lines.push(`${st}: +${plus.total} / 반동 ${minus.total}`);
      }
      const obj = { 이름: '강제 용족화', 분류: '버프', 대상: 'self', 대상이름: state.이름, 효과: '1턴 동안 올스탯 +1d30, 종료 시 영구적으로 올스탯 -3d5', 남은턴: 1, 한턴: true, 시작턴: state.턴, 반동: rebound };
      await save(withLog(`강제 용족화 사용${advancedLogText}`, { ...hpCostPatch, ...advancedPatch, ...boost, 지속효과: [...state.지속효과.filter(e => (e?.이름 ?? e?.name) !== '강제 용족화'), obj], 효과로그: [...arr(state.효과로그), `${nowText()} · 강제 용족화 적용 / 종료 시 반동 예정`].slice(-30), 스킬결과: `${skillResultText}
- 적용: 1턴 동안 올스탯 상승
${lines.map(x => `  · ${x}`).join("\n")}
- 종료 시 각 스탯에 영구 반동 적용` }));
      return;
    }
    if (state.종족 === "요정족" && name === "요정의 축복") {
      if (!target) { await save(withLog("요정의 축복 사용 실패: 대상 NPC를 지정해야 합니다.")); return; }
      const patch = addActiveEffect("요정의 축복", "버프", target, "대상의 다음 판정 +1d6", 1);
      const lastEffect = arr(patch.지속효과).slice(-1)[0];
      if (lastEffect) await addEffectToTargetFrontmatter(target, lastEffect);
      await save(withLog(`요정의 축복 사용: ${targetNameByValue(target)}의 다음 판정 +1d6${advancedLogText}`, { ...hpCostPatch, ...advancedPatch, ...patch, 스킬결과: `${skillResultText}\n- 대상: ${targetNameByValue(target)}\n- 적용: 다음 판정 +1d6` }));
      return;
    }
    if (state.종족 === "요정족" && name === "요정의 저주") {
      if (!target) { await save(withLog("요정의 저주 사용 실패: 대상 NPC를 지정해야 합니다.")); return; }
      const patch = addActiveEffect("요정의 저주", "디버프", target, "대상의 다음 판정 -1d6", 1);
      const lastEffect = arr(patch.지속효과).slice(-1)[0];
      if (lastEffect) await addEffectToTargetFrontmatter(target, lastEffect);
      await save(withLog(`요정의 저주 사용: ${targetNameByValue(target)}의 다음 판정 -1d6${advancedLogText}`, { ...hpCostPatch, ...advancedPatch, ...patch, 스킬결과: `${skillResultText}\n- 대상: ${targetNameByValue(target)}\n- 적용: 다음 판정 -1d6` }));
      return;
    }
    if (state.종족 === "용인족" && name === "용린") {
      const obj = { 이름: "용린", 분류: "버프", 대상: "self", 대상이름: state.이름, 효과: "받는 물리/마법 피해 1/2, 민첩 유효값 1/2", 남은턴: 1, 한턴: true, 시작턴: state.턴 };
      await save(withLog(`용린 사용: 이번 턴 동안 피해 1/2, 민첩 1/2 적용${advancedLogText}`, { ...hpCostPatch, ...advancedPatch, 용린사용중: true, 지속효과: [...state.지속효과.filter(e => (e?.이름 ?? e?.name) !== "용린"), obj], 효과로그: [...arr(state.효과로그), `${nowText()} · 용린 적용: 자기 자신 / 1턴`].slice(-30), 스킬결과: `${skillResultText}\n- 적용: 이번 턴 동안 피해 1/2, 민첩 1/2` }));
      return;
    }
    if (["버프", "디버프"].includes(kind)) {
      if (!target) { await save(withLog(`${name} 사용 실패: 버프/디버프는 시나리오 NPC 대상 지정 필요`)); return; }
      const patch = addActiveEffect(name, kind, target, effect, s?.지속턴 ?? 1);
      const lastEffect = arr(patch.지속효과).slice(-1)[0];
      if (target && target !== "self" && lastEffect) await addEffectToTargetFrontmatter(target, lastEffect);
      await save(withLog(`${name} 사용: ${targetNameByValue(target)}에게 ${kind} 적용${advancedLogText}`, { ...hpCostPatch, ...advancedPatch, ...patch, 스킬결과: `${skillResultText}\n- 대상: ${targetNameByValue(target)}\n- 적용: ${kind}` }));
      return;
    }
    await save(withLog(`${name} 사용: ${effect || "효과 수동 처리"}${advancedLogText}`, { ...hpCostPatch, ...advancedPatch, 스킬결과: skillResultText }));
    return;
  }

  if (action === "deleteSkill") {
    const i = num(btn.dataset.index, -1);
    const target = state.보유스킬[i];
    await save(withLog(`스킬 삭제: ${target?.이름 ?? target?.name ?? ""}`, { 보유스킬: state.보유스킬.filter((_, idx) => idx !== i) })); return;
  }
  if (action === "haggle") {
    const mode = root.querySelector("#dealMode").value;
    const price = Math.max(0, num(root.querySelector("#dealPrice").value, 0));
    const success = root.querySelector("#dealSuccess").value === "success";
    const change = dice(6);
    let next = mode === "buy" ? (success ? price - change : price + change) : (success ? price + change : price - change);
    next = Math.max(0, next);
    const text = `흥정 ${mode === "buy" ? "구매" : "판매"} ${success ? "성공" : "실패"}: 1d6=${change} / 가격 ${price} → ${next}`;
    await rollAndSave({ finalDisplay: String(change), detail: text, type: success ? "성공" : "실패", sides: 6 }); return;
  }
  if (action === "deleteEffect") {
    const i = num(btn.dataset.index, -1);
    const target = state.지속효과[i];
    const logLine = `${nowText()} · 효과 해제: ${target?.이름 ?? "효과"} / ${target?.대상이름 ?? target?.대상 ?? "대상"}`;
    await save(withLog(`효과 해제: ${target?.이름 ?? ""}`, { 지속효과: state.지속효과.filter((_, idx) => idx !== i), 효과로그: [...arr(state.효과로그), logLine].slice(-30) }));
    return;
  }

  if (action === "addStatus") {
    const status = root.querySelector("#statusInput").value.trim();
    if (!status) { await save(withLog("상태 추가 실패: 내용 필요")); return; }
    if (activeEvolutionDef()?.immuneStatus) { await save(withLog(`상태이상 무효: ${status} (사이버트론 패시브)`)); return; }
    await save(withLog(`상태 추가: ${status}`, { 상태이상: [...state.상태이상, status] })); return;
  }
  if (action === "deleteStatus") {
    const i = num(btn.dataset.index, -1);
    const target = state.상태이상[i];
    await save(withLog(`상태 제거: ${target ?? ""}`, { 상태이상: state.상태이상.filter((_, idx) => idx !== i) })); return;
  }
  if (action === "clearStatus") { await save(withLog("상태이상 전체 제거", { 상태이상: [] })); return; }
  if (action === "addCatalogItem") {
    const value = root.querySelector("#catalogItemSelect")?.value ?? "";
    const mode = root.querySelector("#catalogItemMode")?.value ?? "auto";
    const item = itemCatalogByValue(value);
    if (!item) { await save(withLog("아이템 추가 실패: 먼저 아이템 목록 불러오기를 눌러 주세요.")); return; }
    const type = sheetItemType(item);
    const toEquip = mode === "equipment" || (mode === "auto" && type === "장비");
    const name = sheetItemValue(item.이름 ?? item.file.name, item.file.name);
    const patch = toEquip
      ? { 장비목록: addUniqueLine(state.장비목록, itemCatalogEquipmentEntry(item)) }
      : { 아이템목록: addUniqueLine(state.아이템목록, itemCatalogInventoryEntry(item)) };
    await save(withLog(`아이템 노트에서 추가: ${name} → ${toEquip ? "장비목록" : "아이템목록"}`, patch));
    return;
  }
  if (action === "addCustomItemToList") {
    const name = String(root.querySelector("#customItemName")?.value ?? "").trim();
    const mode = root.querySelector("#customItemMode")?.value ?? "inventory";
    const gradeRaw = String(root.querySelector("#customItemGrade")?.value ?? "").trim();
    const effect = String(root.querySelector("#customItemEffect")?.value ?? "").trim();
    if (!name) { await save(withLog("커스텀 아이템 추가 실패: 이름 필요")); return; }
    if (mode === "equipment") {
      const parts = gradeRaw.split("|").map(x => x.trim());
      const grade = parts[0] || "일반";
      const price = parts[1] || "0";
      await save(withLog(`커스텀 장비 추가: ${name}`, { 장비목록: addUniqueLine(state.장비목록, `${name}|${grade}|${price}|${effect}`) }));
    } else {
      const entry = effect ? `${name} · ${effect}` : name;
      await save(withLog(`커스텀 아이템 추가: ${name}`, { 아이템목록: addUniqueLine(state.아이템목록, entry) }));
    }
    return;
  }
  if (action === "refreshItemCatalog") {
    const list = itemCatalogPages(true);
    await save({ 최근결과: `아이템 목록 ${list.length}개를 frontmatter 캐시에 저장했습니다.`, 로그: [], 효과로그: [] });
    return;
  }
  if (action === "clearItemCatalog") {
    clearStoredList("item");
    await save({ 최근결과: "아이템 목록 캐시를 비웠습니다.", 로그: [], 효과로그: [] });
    return;
  }
  if (action === "removeEquipmentItem") {
    const i = num(btn.dataset.index, -1);
    const list = sheetListEntries(state.장비목록);
    const target = list[i];
    if (i < 0 || i >= list.length) { await save(withLog("장비 제거 실패: 대상 없음")); return; }
    await save(withLog(`장비 제거: ${target}`, { 장비목록: list.filter((_, idx) => idx !== i) }));
    return;
  }
  if (action === "removeInventoryItem") {
    const i = num(btn.dataset.index, -1);
    const list = sheetListEntries(state.아이템목록);
    const target = list[i];
    if (i < 0 || i >= list.length) { await save(withLog("아이템 제거 실패: 대상 없음")); return; }
    await save(withLog(`아이템 제거: ${target}`, { 아이템목록: list.filter((_, idx) => idx !== i) }));
    return;
  }
  if (action === "saveLists") {
    const equips = (root.querySelector("#equipText")?.value ?? "").split("\n").map(x => x.trim()).filter(Boolean);
    const items = (root.querySelector("#itemText")?.value ?? "").split("\n").map(x => x.trim()).filter(Boolean);
    await save(withLog("장비/아이템 목록 저장", { 장비목록: equips, 아이템목록: items })); return;
  }
});

root.addEventListener("change", event => {
  const el = event.target;
  if (!el) return;
  if (el.id === "oppTarget") {
    const box = root.querySelector("#oppTargetStatPreview");
    if (box) box.innerHTML = targetStatSummaryHTML(el.value);
    return;
  }
  if (el.id === "skillAdvancedToggle") {
    const panel = root.querySelector("#skillAdvancedPanel");
    if (panel) panel.classList.toggle("open", el.checked === true);
    return;
  }
});

render();
```



---
