# TRPG Sheet Migrator v0.1.1

이미 만들어진 TRPG 시트의 내용을 유지한 채 `template.md`의 최신 시트 코드와 본문 구조를 적용하는 옵시디언 플러그인입니다.

## 변경점

- 백업 기능 제거
- 백업 폴더 생성 제거
- `template.md`를 플러그인 폴더에 넣으면 그 파일을 기준으로 업데이트
- 기존 frontmatter 값 유지
- 기존 스탯, HP, 종족, 직업, 보유스킬, 만다라 설정, 장비, 아이템, 로그 유지
- 기존 본문 메모 보존 가능
- template.md에 새로 생긴 frontmatter 필드는 없는 경우에만 추가

## 설치

압축을 풀어 아래 위치에 넣으세요.

```text
옵시디언 보관함/.obsidian/plugins/trpg-sheet-migrator/
```

폴더 안에는 아래 파일들이 있어야 합니다.

```text
manifest.json
main.js
styles.css
template.md
README.md
```

## 명령어

```text
TRPG 시트 업데이트 적용
TRPG 현재 시트만 업데이트 적용
```

일괄 적용 전에는 `후보 미리보기`로 대상 파일을 확인하는 것을 권장합니다.
